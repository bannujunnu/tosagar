"""
Baker Hughes Negotiation Engine - Main Simulation Script

This script runs a procurement negotiation simulation for Baker Hughes,
involving multiple agents negotiating for drilling equipment.
"""

import os
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from crewai import Crew

import sys
import os

# Add the project root to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Completely disable CrewAI telemetry and any other external connections
os.environ['CREWAI_DISABLE_TELEMETRY'] = 'true'
os.environ['LANGCHAIN_TRACING_V2'] = 'false'
os.environ['LANGCHAIN_ENDPOINT'] = ''
os.environ['OPENAI_TRACING'] = 'false'
# Disable any other potential telemetry
os.environ['TELEMETRY_ENABLED'] = 'false'

from agents.bh_agents import create_all_agents, create_azure_llm
from agents.bh_tasks import (
    create_procurement_task,
    create_supplier_task,
    create_strategist_task,
    create_evaluator_task
)

# Load environment variables
load_dotenv()

# Explicitly set OpenAI environment variables from Azure variables
os.environ['OPENAI_API_KEY'] = os.environ.get('AZURE_OPENAI_API_KEY', '')
os.environ['OPENAI_API_BASE'] = os.environ.get('AZURE_OPENAI_ENDPOINT', '')
os.environ['OPENAI_API_VERSION'] = os.environ.get('AZURE_OPENAI_API_VERSION', '2024-02-15-preview')
os.environ['OPENAI_API_TYPE'] = 'azure'


def run_negotiation_simulation():
    """
    Run the Baker Hughes procurement negotiation simulation.
    """
    print("Starting Baker Hughes drilling equipment procurement negotiation simulation...")
    
    # Print debugging information
    deployment_name = os.environ.get('AZURE_OPENAI_DEPLOYMENT', 'gpt-4')
    api_key = os.environ.get('AZURE_OPENAI_API_KEY')
    azure_endpoint = os.environ.get('AZURE_OPENAI_ENDPOINT')
    
    print(f"Using Azure OpenAI deployment: {deployment_name}")
    print(f"API Key (first 5 chars): {api_key[:5] if api_key else 'Not set'}")
    print(f"Endpoint: {azure_endpoint}")
    
    # Initialize Azure OpenAI LLM with the helper function
    try:
        print(f"Attempting to connect to Azure OpenAI with deployment: {deployment_name}")
        
        # Use the helper function from bh_agents.py
        llm = create_azure_llm()
        # Test the connection
        llm.invoke("Hello, this is a test message to verify the connection.")
        print("Successfully connected to Azure OpenAI!")
    except Exception as e:
        print(f"Error connecting to Azure OpenAI: {str(e)}")
        print("Please check if the deployment name is correct in your .env file.")
        print("Verify that you have created this deployment in your Azure OpenAI resource.")
        # Fallback to a mock LLM for testing if needed
        from langchain.llms.fake import FakeListLLM
        llm = FakeListLLM(responses=["This is a mock response for testing purposes."])
        print("Using mock LLM for testing.")
        raise e
    
    # Create all agents
    agents = create_all_agents(llm)
    
    # Create tasks
    tasks = []
    
    # Step 1: Procurement Officer initiates the negotiation
    procurement_task = create_procurement_task(agents["procurement"])
    tasks.append(procurement_task)
    
    # Step 2: Supplier Agents respond with their offers
    for i in range(1, 4):
        supplier_task = create_supplier_task(
            agents[f"supplier_{i}"], 
            supplier_num=i
        )
        tasks.append(supplier_task)
    
    # Step 3: Strategist suggests negotiation tactics
    strategist_task = create_strategist_task(agents["strategist"])
    tasks.append(strategist_task)
    
    # Step 4: Evaluator compares offers and provides recommendation
    evaluator_task = create_evaluator_task(agents["evaluator"])
    tasks.append(evaluator_task)
    
    # Create the crew with all agents and tasks
    crew = Crew(
        agents=list(agents.values()),
        tasks=tasks,
        verbose=True
    )
    
    # Run the negotiation simulation
    result = crew.kickoff()
    
    print("\n=== FINAL NEGOTIATION OUTCOME ===")
    print(result)
    return result


if __name__ == "__main__":
    run_negotiation_simulation()
