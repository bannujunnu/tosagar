"""
Baker Hughes Negotiation Engine - Streamlit Interface

This module provides a web interface for the Baker Hughes procurement negotiation simulation
using Streamlit.
"""

import streamlit as st
import os
import sys
import time
from pathlib import Path

# Add project root to path to enable imports
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from crewai import Crew,LLM


# Import the agent modules directly using relative imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

# Completely disable CrewAI telemetry and any other external connections
os.environ['CREWAI_DISABLE_TELEMETRY'] = 'true'
os.environ['LANGCHAIN_TRACING_V2'] = 'false'
os.environ['LANGCHAIN_ENDPOINT'] = ''
os.environ['OPENAI_TRACING'] = 'false'
# Disable any other potential telemetry
os.environ['TELEMETRY_ENABLED'] = 'false'

# Import the agent modules
from src.agents.bh_agents import create_all_agents, create_azure_llm
from src.agents.bh_tasks import (
    create_procurement_task,
    create_supplier_task,
    create_strategist_task,
    create_evaluator_task
)

# Load environment variables
load_dotenv()

# Explicitly set OpenAI environment variables from Azure variables
os.environ['OPENAI_API_KEY'] = os.environ.get('AZURE_OPENAI_API_KEY', '')
os.environ['OPENAI_API_BASE'] = os.environ.get('AZURE_OPENAI_ENDPOINT', '')
os.environ['OPENAI_API_VERSION'] = os.environ.get('AZURE_OPENAI_API_VERSION', '2024-02-15-preview')
os.environ['OPENAI_API_TYPE'] = 'azure'
os.environ['AZURE_API_KEY'] = os.environ.get('AZURE_OPENAI_API_KEY', '')
os.environ["AZURE_API_BASE"] = os.environ.get('AZURE_OPENAI_ENDPOINT', '')
os.environ["AZURE_API_VERSION"] = os.environ.get('AZURE_OPENAI_API_VERSION', '2024-02-15-preview')

# Page configuration
st.set_page_config(
    page_title="Baker Hughes Negotiation Engine",
    page_icon="🤝",
    layout="wide",
)


def run_negotiation():
    """Run the negotiation simulation using environment variables"""
    
    # Initialize progress tracking
    progress_bar = st.progress(0)
    status_text = st.empty()
    output_container = st.container()
    
    # Get Azure OpenAI configuration from environment variables
    api_key = os.environ.get('AZURE_OPENAI_API_KEY')
    azure_endpoint = os.environ.get('AZURE_OPENAI_ENDPOINT')
    api_version = os.environ.get('AZURE_OPENAI_API_VERSION', '2024-02-15-preview')
    deployment_name = os.environ.get('AZURE_OPENAI_DEPLOYMENT')
    
    # Print debugging information
    print(f"Using Azure OpenAI deployment: {deployment_name}")
    print(f"API Key (first 5 chars): {api_key[:5] if api_key else 'Not set'}")
    print(f"Endpoint: {azure_endpoint}")
    
    # Initialize Azure OpenAI LLM with explicit configuration
    try:
        print(f"Attempting to connect to Azure OpenAI with deployment: {deployment_name}")
        
        # Use the helper function from bh_agents.py for consistent configuration
        llm = create_azure_llm()
        print("connected to llm")
        # Test the connection
        llm.invoke("Hello, this is a test message to verify the connection.")
        print("Successfully connected to Azure OpenAI!")
    except Exception as e:
        print(f"Error connecting to Azure OpenAI: {str(e)}")
        st.error(f"Error connecting to Azure OpenAI: {str(e)}")
        # Fallback to a mock LLM for testing if needed
        from langchain_community.llms import FakeListLLM
        llm = FakeListLLM(responses=["This is a mock response for testing purposes."])
        print("Using mock LLM for testing.")
        raise e
    
    # Create all agents
    with output_container:
        with st.spinner("Creating negotiation agents..."):
            st.write("⚙️ Initializing agents...")
            agents = create_all_agents(llm)
            progress_bar.progress(10)
            status_text.text("Agents initialized")
    
    # Create tasks
    tasks = []
    
    # Step 1: Procurement Officer initiates the negotiation
    with output_container:
        with st.spinner("Procurement officer is preparing negotiation requirements..."):
            st.write("📝 Procurement officer is preparing the requirements...")
            procurement_task = create_procurement_task(agents["procurement"])
            tasks.append(procurement_task)
            progress_bar.progress(20)
            status_text.text("Procurement requirements ready")
    
    # Step 2: Supplier Agents respond with their offers
    for i in range(1, 4):
        with output_container:
            with st.spinner(f"Supplier {i} is preparing their offer..."):
                st.write(f"🏭 Supplier {i} is analyzing requirements and preparing an offer...")
                supplier_task = create_supplier_task(
                    agents[f"supplier_{i}"], 
                    supplier_num=i
                )
                tasks.append(supplier_task)
                progress_bar.progress(20 + 15*i)
                status_text.text(f"Supplier {i} offer received")
    
    # Step 3: Strategist suggests negotiation tactics
    with output_container:
        with st.spinner("Negotiation strategist is analyzing offers..."):
            st.write("🧠 Negotiation strategist is analyzing offers and developing tactics...")
            strategist_task = create_strategist_task(agents["strategist"])
            tasks.append(strategist_task)
            progress_bar.progress(70)
            status_text.text("Negotiation strategies developed")
    
    # Step 4: Evaluator compares offers and provides recommendation
    with output_container:
        with st.spinner("Evaluator is comparing all offers..."):
            st.write("⚖️ Evaluator is comparing offers and preparing final recommendation...")
            evaluator_task = create_evaluator_task(agents["evaluator"])
            tasks.append(evaluator_task)
            progress_bar.progress(85)
            status_text.text("Final evaluation in progress")
    
    # Create the crew with all agents and tasks
    crew = Crew(
        agents=list(agents.values()),
        tasks=tasks,
        verbose=True,
        llm=LLM(model=f'azure/gpt-4o')
    )
    
    # Run the negotiation simulation
    with output_container:
        with st.spinner("Running negotiation process..."):
            st.write("🤝 Negotiation process is running...")
            result = crew.kickoff()
            progress_bar.progress(100)
            status_text.text("Negotiation completed!")
    
    return result


def main():
    """Main function to run the Streamlit app"""
    
    st.title("🤝 Baker Hughes Procurement Negotiation Engine")
    st.subheader("AI-Powered Procurement Negotiation Simulation")
    
    st.markdown("""
    This application simulates a multi-agent negotiation scenario for Baker Hughes procurement. 
    The simulation involves negotiating with multiple suppliers for drilling equipment for an offshore oil rig project.
    """)
    
    # Display configuration from environment variables
    st.sidebar.title("⚙️ Configuration")
    st.sidebar.markdown("**Using configuration from environment file**")
    
    # Show deployment being used (without showing sensitive info)
    deployment_name = os.environ.get('AZURE_OPENAI_DEPLOYMENT', 'gpt-4o')
    st.sidebar.markdown(f"**Model Deployment**: {deployment_name}")
    
    # Show API version
    api_version = os.environ.get('AZURE_OPENAI_API_VERSION', '2024-02-15-preview')
    st.sidebar.markdown(f"**API Version**: {api_version}")
    
    # Scenario information
    st.sidebar.title("📋 Negotiation Scenario")
    st.sidebar.markdown("""
    **Project**: Offshore Oil Rig Equipment Procurement
    
    **Requirement**: 100 units of drilling equipment
    
    **Target Budget**: $280,000-$320,000
    
    **Timeline**: 8 weeks
    
    **Warranty**: Min. 2 years, pref. 3+ years
    """)
    
    # Agent descriptions
    st.sidebar.title("👥 Agents")
    agents_info = {
        "Procurement Officer": "Represents Baker Hughes interests",
        "Supplier 1": "Cost-effective, short warranty",
        "Supplier 2": "Premium quality, longer warranty",
        "Supplier 3": "Mid-range, flexible delivery",
        "Negotiation Strategist": "Suggests tactics",
        "Evaluator": "Provides final recommendation"
    }
    
    for agent, desc in agents_info.items():
        st.sidebar.markdown(f"**{agent}**: {desc}")
    
    # Main content area
    tab1, tab2 = st.tabs(["Run Simulation", "About"])
    
    with tab1:
        st.header("Run Negotiation Simulation")
        st.markdown("""
        Press the button below to start a new negotiation simulation. 
        The agents will interact and negotiate according to their goals and strategies.
        """)
        
        # Check if environment variables are set
        api_key = os.environ.get('AZURE_OPENAI_API_KEY')
        azure_endpoint = os.environ.get('AZURE_OPENAI_ENDPOINT')
        
        if not api_key or not azure_endpoint:
            st.warning("⚠️ Please set AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT in your environment file.")
        else:
            if st.button("🚀 Start Negotiation", type="primary"):
                with st.spinner("Initializing negotiation engine..."):
                    try:
                        # Run the negotiation using environment variables
                        result = run_negotiation()
                        
                        # Display result
                        st.success("✅ Negotiation completed successfully!")
                        
                        st.header("📊 Negotiation Results")
                        
                        # Create tabs for different parts of the negotiation
                        result_tabs = st.tabs(["Summary", "Supplier 1 Quotation", "Supplier 2 Quotation", "Supplier 3 Quotation", "Strategy", "Evaluation"])
                        
                        # Extract different parts of the result if possible
                        result_parts = result.split("# Agent:") if isinstance(result, str) else [result]
                        
                        with result_tabs[0]:
                            st.subheader("Negotiation Summary")
                            st.markdown(result_parts[0] if len(result_parts) > 0 else result)
                            st.markdown("---")
                            st.markdown("### Final Recommendation")
                            # Try to extract the final recommendation
                            if len(result_parts) > 5:
                                st.markdown(result_parts[5])
                            else:
                                st.markdown("See the Evaluation tab for the final recommendation.")
                        
                        # Display supplier quotations in separate tabs
                        for i in range(1, 4):
                            with result_tabs[i]:
                                st.subheader(f"Supplier {i} Quotation")
                                # Try to extract the supplier's part
                                if len(result_parts) > i:
                                    st.markdown(f"# Agent:{result_parts[i]}")
                                else:
                                    st.markdown(f"Supplier {i} quotation details will appear here when the negotiation is complete.")
                                
                                # Add a structured display of the quotation if we can parse it
                                try:
                                    if len(result_parts) > i:
                                        # Try to extract key information
                                        supplier_text = result_parts[i]
                                        
                                        # Create expandable sections for different aspects of the quotation
                                        with st.expander("Pricing Details", expanded=True):
                                            if "price" in supplier_text.lower() or "cost" in supplier_text.lower() or "$" in supplier_text:
                                                # Extract pricing information
                                                st.markdown("### Pricing Structure")
                                                st.markdown("The supplier has provided the following pricing information:")
                                                # Display in a more structured way if possible
                                            else:
                                                st.markdown("Pricing details not explicitly provided in the quotation.")
                                        
                                        with st.expander("Warranty & Support"):
                                            if "warranty" in supplier_text.lower() or "support" in supplier_text.lower() or "maintenance" in supplier_text.lower():
                                                st.markdown("### Warranty and Support Options")
                                            else:
                                                st.markdown("Warranty and support details not explicitly provided in the quotation.")
                                        
                                        with st.expander("Delivery Timeline"):
                                            if "delivery" in supplier_text.lower() or "timeline" in supplier_text.lower() or "schedule" in supplier_text.lower():
                                                st.markdown("### Delivery Information")
                                            else:
                                                st.markdown("Delivery timeline not explicitly provided in the quotation.")
                                except Exception as e:
                                    st.warning(f"Could not parse structured information from the quotation: {str(e)}")
                        
                        # Display negotiation strategy
                        with result_tabs[4]:
                            st.subheader("Negotiation Strategy")
                            if len(result_parts) > 4:
                                st.markdown(f"# Agent:{result_parts[4]}")
                            else:
                                st.markdown("Negotiation strategy will appear here when the negotiation is complete.")
                        
                        # Display evaluation
                        with result_tabs[5]:
                            st.subheader("Evaluation and Recommendation")
                            if len(result_parts) > 5:
                                st.markdown(f"# Agent:{result_parts[5]}")
                            else:
                                st.markdown("Evaluation and recommendation will appear here when the negotiation is complete.")
                        
                        # Also show the raw result in an expandable section
                        with st.expander("View Raw Negotiation Results"):
                            st.markdown(result)
                        
                    except Exception as e:
                        st.error(f"❌ An error occurred: {str(e)}")
    
    with tab2:
        st.header("About the Baker Hughes Negotiation Engine")
        st.markdown("""
        ### Overview
        The Baker Hughes Negotiation Engine simulates a procurement scenario within the energy, oil, and gas sector.
        It leverages AI agents to model realistic negotiation dynamics between a buyer and multiple suppliers.
        
        ### Key Features
        - **Multi-agent simulation**: Realistic representation of different stakeholders
        - **Strategic negotiation**: AI-powered negotiation tactics development
        - **Comprehensive evaluation**: Total Cost of Ownership (TCO) analysis
        - **Industry-specific parameters**: Focuses on energy sector requirements
        
        ### Use Cases
        - Training procurement professionals
        - Testing negotiation strategies
        - Supplier scenario planning
        - Procurement optimization
        """)


if __name__ == "__main__":
    main()
