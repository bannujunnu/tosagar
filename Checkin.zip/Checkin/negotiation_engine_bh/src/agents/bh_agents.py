"""
Baker Hughes Negotiation Agents Module

This module defines the agents involved in the drilling equipment negotiation process:
1. Procurement Officer (Buyer)
2. Supplier Agents (3 vendors)
3. Negotiation Strategist
4. Evaluator Agent
"""
import os
from langchain_openai import AzureChatOpenAI
from crewai import Agent, LLM

# Helper function to create properly configured Azure OpenAI LLM
def create_azure_llm():
    """Creates an Azure OpenAI LLM instance with proper configuration."""
    api_key = os.environ.get('AZURE_OPENAI_API_KEY')
    print(f"API Key: {api_key}")
    azure_endpoint = os.environ.get('AZURE_OPENAI_ENDPOINT')
    print(f"Endpoint: {azure_endpoint}")
    api_version = os.environ.get('AZURE_OPENAI_API_VERSION', '2024-02-15-preview')
    print(f"API Version: {api_version}")
    # Make sure the deployment name doesn't have the 'azure/' prefix
    deployment_name = os.environ.get('AZURE_OPENAI_DEPLOYMENT', 'gpt-4o')
    if deployment_name.startswith('azure/'):
        deployment_name = deployment_name.replace('azure/', '')
    print(f"Deployment: {deployment_name}")
    
    # Configure Azure OpenAI based on CrewAI community examples
    print(f"Setting up AzureChatOpenAI with deployment: {deployment_name}")
    
    os.environ['AZURE_API_KEY'] = api_key
    os.environ["AZURE_API_BASE"] = azure_endpoint
    os.environ["AZURE_API_VERSION"] = api_version
    
    # Following the pattern from CrewAI community for Azure OpenAI integration
    # This approach should work with CrewAI's internal handling
    azure_llm = AzureChatOpenAI(
        api_version=api_version,
        openai_api_version="2025-01-01-preview",
        azure_deployment=deployment_name,
        azure_endpoint=azure_endpoint,
        api_key=api_key,
        temperature=0.7
    )
    
    return azure_llm


def create_procurement_agent(llm):
    """Creates the Procurement Officer (Buyer) agent."""
    return Agent(
        role="Procurement Officer",
        goal="Negotiate the best deal for specialized drilling equipment with 3 suppliers.",
        backstory="Baker Hughes requires high-performance equipment for offshore drilling rigs. "
                 "Budget constraints apply but quality is critical for offshore operations. "
                 "Equipment reliability is essential due to the high cost of downtime in offshore operations.",
        llm=LLM(model=f'azure/gpt-4o'),
        verbose=True
    )


def create_supplier_agent_1(llm):
    """Creates the first supplier agent."""
    return Agent(
        role="Supplier Sales Manager - Vendor 1",
        goal="Sell drilling equipment at the best possible price, with limited warranty but lower cost.",
        backstory="You offer cost-effective equipment but with a limited warranty of 1 year. "
                 "Delivery time is standard at 8 weeks. Your equipment meets the basic offshore "
                 "requirements but has fewer advanced features. You can offer quantity discounts.",
        llm=LLM(model=f'azure/gpt-4o'),
        verbose=True
    )


def create_supplier_agent_2(llm):
    """Creates the second supplier agent."""
    return Agent(
        role="Supplier Sales Manager - Vendor 2",
        goal="Sell high-end drilling equipment with longer warranties and maintenance contracts.",
        backstory="You offer premium equipment with a 5-year warranty and support, but at a higher cost. "
                 "Your equipment has advanced features specifically designed for harsh offshore environments. "
                 "Delivery time is 10 weeks, but you offer comprehensive staff training and 24/7 technical support.",
        llm=LLM(model=f'azure/gpt-4o'),
        verbose=True
    )


def create_supplier_agent_3(llm):
    """Creates the third supplier agent."""
    return Agent(
        role="Supplier Sales Manager - Vendor 3",
        goal="Provide mid-range equipment that meets buyer's requirements but at a reasonable cost and delivery time.",
        backstory="Your equipment meets industry standards and has a moderate cost. "
                 "Delivery time is flexible at 6 weeks, and warranty is 3 years. "
                 "You have a good reputation for reliability and compliance with industry regulations. "
                 "You offer flexible payment terms and can customize some specifications.",
        llm=LLM(model=f'azure/gpt-4o'),
        verbose=True
    )


def create_negotiation_strategist(llm):
    """Creates the negotiation strategist agent."""
    return Agent(
        role="Negotiation Strategist",
        goal="Suggest negotiation tactics to get the best deal for Baker Hughes.",
        backstory="You have deep expertise in procurement strategy for oil and gas equipment and know how to "
                 "leverage delivery timelines and warranties. You understand the importance of total cost of "
                 "ownership (TCO) for offshore drilling equipment and have insights into supplier cost structures. "
                 "You specialize in developing win-win negotiation approaches that build long-term relationships "
                 "while securing favorable terms.",
        llm=LLM(model=f'azure/gpt-4o'),
        verbose=True
    )


def create_evaluator_agent(llm):
    """Creates the evaluator agent."""
    return Agent(
        role="Deal Evaluator",
        goal="Evaluate all offers based on total cost of ownership (TCO), warranty, delivery, and supplier reliability.",
        backstory="You assess offers based on price, warranty, delivery, and long-term costs. "
                 "Regulatory compliance is a key consideration for offshore drilling operations. "
                 "You have expertise in risk assessment and supplier evaluation for the energy sector. "
                 "You use a balanced scorecard approach that considers multiple factors beyond just price.",
        llm=LLM(model=f'azure/gpt-4o'),
        verbose=True
    )


def create_all_agents(llm):
    """Creates all agents for the negotiation process."""
    return {
        "procurement": create_procurement_agent(llm),
        "supplier_1": create_supplier_agent_1(llm),
        "supplier_2": create_supplier_agent_2(llm),
        "supplier_3": create_supplier_agent_3(llm),
        "strategist": create_negotiation_strategist(llm),
        "evaluator": create_evaluator_agent(llm)
    }
