"""
Baker Hughes Negotiation Tasks Module

This module defines the tasks involved in the drilling equipment negotiation process:
1. Procurement Officer initiates negotiation
2. Supplier Agents respond with offers
3. Negotiation Strategist suggests tactics
4. Evaluator compares offers and provides recommendations
"""

from crewai import Task


def create_procurement_task(procurement_agent):
    """Creates the task for the Procurement Officer to initiate negotiation."""
    return Task(
        description=(
            "Initiate negotiation for specialized drilling equipment needed for an offshore oil rig project. "
            "The target specifications are:\n"
            "- 100 units of high-pressure/high-temperature capable drilling pumps and valves\n"
            "- Target price range: $280,000-$320,000 total\n"
            "- Warranty requirement: minimum 2 years, preferred 3+ years\n"
            "- Delivery timeline: needed within 8 weeks maximum\n"
            "- Equipment must meet API Spec 16A and 16C standards for offshore operations\n"
            "- Include requirements for post-installation support and maintenance options\n\n"
            "Provide detailed requirements and invite all three suppliers to submit their best offers. "
            "Be specific about technical requirements, quantities, delivery timeframe, warranty expectations, "
            "and any flexibility in these parameters."
        ),
        agent=procurement_agent,
        expected_output=(
            "A comprehensive negotiation opening document that clearly states Baker Hughes' requirements, "
            "priorities, and constraints for the drilling equipment procurement."
        )
    )


def create_supplier_task(supplier_agent, supplier_num):
    """Creates the task for a Supplier Agent to respond with an offer."""
    return Task(
        description=(
            f"As Supplier {supplier_num}, respond to Baker Hughes' procurement request with your best offer. "
            "Your response should include:\n"
            "- Detailed pricing structure with unit and total costs\n"
            "- Available warranty options and their costs\n"
            "- Specific delivery timeframe and any expedite options\n"
            "- Technical specifications of your offered equipment\n"
            "- Compliance certifications with industry standards\n"
            "- Maintenance and support package options\n"
            "- Any value-added services you can provide\n"
            "- Payment terms and conditions\n\n"
            "Make your offer attractive but realistic, drawing on your company's strengths while addressing "
            "Baker Hughes' stated requirements. Highlight your competitive advantages."
        ),
        agent=supplier_agent,
        expected_output=(
            "A detailed commercial offer document that addresses all of Baker Hughes' requirements and "
            "highlights your company's unique value proposition for this procurement."
        )
    )


def create_strategist_task(strategist_agent, context=""):
    """Creates the task for the Negotiation Strategist."""
    return Task(
        description=(
            "Review all supplier offers and the procurement officer's requirements. Then develop a comprehensive "
            "negotiation strategy for Baker Hughes. Your task includes:\n"
            "- Analyzing strengths and weaknesses of each supplier's offer\n"
            "- Identifying opportunities for negotiation leverage\n"
            "- Recommending counter-offer strategies for each supplier\n"
            "- Suggesting bundling opportunities (equipment + maintenance + training)\n"
            "- Recommending areas where Baker Hughes might compromise\n"
            "- Prioritizing negotiation points by importance\n"
            "- Providing specific language for counter-offers\n\n"
            f"Context from previous negotiation steps:\n{context}\n\n"
            "Focus on achieving the best total cost of ownership, not just purchase price. "
            "Consider long-term strategic supplier relationship potential."
        ),
        agent=strategist_agent,
        expected_output=(
            "A detailed negotiation strategy document with specific recommendations for "
            "counter-offers to each supplier and prioritized negotiation points."
        )
    )


def create_evaluator_task(evaluator_agent, context=""):
    """Creates the task for the Evaluator Agent."""
    return Task(
        description=(
            "Evaluate all supplier offers and any counter-offers using a balanced scorecard approach. "
            "Your evaluation should include:\n"
            "- Price analysis (initial and total cost of ownership)\n"
            "- Technical specification compliance assessment\n"
            "- Warranty and service package comparison\n"
            "- Delivery timeline assessment and risk evaluation\n"
            "- Supplier reliability and track record evaluation\n"
            "- Regulatory compliance verification\n"
            "- Long-term partnership potential analysis\n\n"
            f"Context from previous negotiation steps:\n{context}\n\n"
            "Generate a weighted score for each supplier across all criteria. Provide a clear final recommendation "
            "on which supplier offers the best overall value for Baker Hughes' offshore drilling project, "
            "with justification for your choice."
        ),
        agent=evaluator_agent,
        expected_output=(
            "A comprehensive evaluation report with comparative analysis of all supplier offers, "
            "weighted scoring across all criteria, and a well-justified final recommendation."
        )
    )
