# Baker Hughes Negotiation Engine

A specialized AI-powered negotiation simulation system for Baker Hughes procurement activities in the energy, oil, and gas sector. The system simulates multi-agent negotiations for drilling equipment procurement, incorporating industry-specific considerations such as Total Cost of Ownership (TCO), regulatory compliance, and operational reliability.

## Overview

This project implements a multi-agent negotiation simulation for Baker Hughes' procurement processes, specifically focused on offshore drilling equipment. The system uses CrewAI and LangChain to simulate interactions between:

- **Procurement Officer (Buyer)**: Represents Baker Hughes' interests
- **Three Supplier Agents**: Each with different value propositions
  - Supplier 1: Cost-effective equipment with shorter warranties
  - Supplier 2: Premium equipment with longer warranties and support
  - Supplier 3: Mid-range equipment with flexible delivery timeframes
- **Negotiation Strategist**: Suggests negotiation tactics
- **Evaluator Agent**: Assesses all offers and provides recommendations

## Project Structure

```
negotiation_engine_bh/
│
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── bh_agents.py    # Agent definitions
│   │   └── bh_tasks.py     # Task definitions
│   │
│   ├── frontend/
│   │   ├── __init__.py
│   │   └── negotiation_app.py  # Streamlit interface
│   │
│   └── bh_negotiation_simulation.py  # Main simulation script
│
├── requirements.txt  # Project dependencies
└── README.md        # This file
```

## Installation

1. Clone the repository
2. Set up a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Set up your Azure OpenAI credentials in a `.env` file:
   ```
   AZURE_OPENAI_API_KEY=your_azure_api_key_here
   AZURE_OPENAI_ENDPOINT=https://your-resource-name.openai.azure.com/
   AZURE_OPENAI_API_VERSION=2023-12-01-preview
   ```

   Make sure you have created a deployment for GPT-4o in your Azure OpenAI resource.

## Usage

### Running the Simulation Script

To run the negotiation simulation directly from the command line:

```bash
python -m src.bh_negotiation_simulation
```

### Using the Streamlit Web Interface

For an interactive experience, run the Streamlit application:

```bash
streamlit run src/frontend/negotiation_app.py
```

The web interface will guide you through the negotiation process and display the results in a user-friendly format.

## Customization

You can customize the negotiation scenario by modifying the following files:

- `src/agents/bh_agents.py`: Adjust agent roles, goals, and backstories
- `src/agents/bh_tasks.py`: Modify negotiation tasks, requirements, and evaluation criteria

## Features

- **Industry-specific negotiation simulation**: Tailored for oil and gas equipment procurement
- **Multi-agent system**: Realistic representation of different stakeholders
- **Total Cost of Ownership analysis**: Beyond initial purchase price
- **Regulatory compliance consideration**: Critical for offshore operations
- **Interactive visualization**: Through Streamlit interface

## Requirements

- Python 3.8+
- Azure OpenAI resource with GPT-4o model deployment
- Azure OpenAI API key
- See requirements.txt for full dependencies

## License

Internal use for Baker Hughes only
