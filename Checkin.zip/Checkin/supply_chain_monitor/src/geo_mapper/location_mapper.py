from typing import Dict, List
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut
import folium

class LocationMapper:
    def __init__(self):
        self.geolocator = Nominatim(user_agent="supply_chain_monitor")
        
    def geocode_location(self, location: str) -> Dict:
        """Convert location name to coordinates."""
        try:
            location_data = self.geolocator.geocode(location)
            if location_data:
                return {
                    'name': location,
                    'latitude': location_data.latitude,
                    'longitude': location_data.longitude
                }
        except GeocoderTimedOut:
            return None
        return None

    def create_impact_map(self, impact_locations: List[Dict]) -> folium.Map:
        """Create an interactive map showing impact locations."""
        # Create base map centered on first location
        if not impact_locations:
            return folium.Map(location=[0, 0], zoom_start=2)
            
        center_lat = impact_locations[0]['latitude']
        center_lon = impact_locations[0]['longitude']
        m = folium.Map(location=[center_lat, center_lon], zoom_start=4)
        
        # Add markers for each impact location
        for loc in impact_locations:
            folium.Marker(
                location=[loc['latitude'], loc['longitude']],
                popup=f"Impact: {loc['impact_level']}\nType: {loc['impact_type']}",
                icon=folium.Icon(color=self._get_color_for_impact(loc['impact_level']))
            ).add_to(m)
            
        return m
    
    def _get_color_for_impact(self, impact_level: int) -> str:
        """Return color based on impact level."""
        colors = {
            1: 'green',
            2: 'lightgreen',
            3: 'orange',
            4: 'lightred',
            5: 'red'
        }
        return colors.get(impact_level, 'gray')