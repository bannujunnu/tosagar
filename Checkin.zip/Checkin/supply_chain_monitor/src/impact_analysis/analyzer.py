from typing import Dict, List
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain.chains import LLMChain
import json
import logging
import os
from langsmith import Client

logger = logging.getLogger(__name__)

class ImpactAnalyzer:
    def __init__(self, config: Dict):
        # Set up LangSmith
        if config.get('langsmith', {}).get('enable_tracing', False):
            os.environ["LANGCHAIN_TRACING_V2"] = "true"
            os.environ["LANGCHAIN_API_KEY"] = config['langsmith']['api_key']
            os.environ["LANGCHAIN_PROJECT"] = config['langsmith']['project_name']
            # Initialize LangSmith client
            self.langsmith_client = Client()
            logger.info("LangSmith tracing enabled")
        
        # Initialize Azure OpenAI
        self.llm = AzureChatOpenAI(
            openai_api_version=config['azure_openai_api_version'],
            azure_deployment=config['azure_openai_deployment'],
            azure_endpoint=config['azure_openai_endpoint'],
            api_key=config['azure_openai_api_key'],
            temperature=0.5,
            tags=["supply_chain_monitor", "impact_analysis"]
        )
        
        self.entity_extraction_template = """Extract named entities from the following text and return them in JSON format.

Text: {text}

Return the entities in this exact JSON format:
{{
    "entities": [
        {{
            "text": "string",
            "type": "string"
        }}
    ]
}}

Response should be ONLY the JSON object, no other text."""
        
        self.entity_extraction_prompt = PromptTemplate(
            input_variables=["text"],
            template=self.entity_extraction_template
        )
        
        self.entity_extraction_chain = LLMChain(
            llm=self.llm,
            prompt=self.entity_extraction_prompt,
            verbose=True
        )
        
        self.impact_template = """Analyze the potential supply chain impact caused to Amgen due to the following news article and return the analysis in JSON format.

Article: {news_content}

Return the analysis in this exact JSON format (all fields required, provide at least one location and a mitigation_recommendation):
{
    "affected_areas": {
        "labor": 0.5,
        "transportation": 0.3,
        "raw_materials": 0.8
    },
    "timeframe": "immediate",
    "affected_regions": ["North America", "Asia"],
    "key_entities": ["Company A", "Port B", "Material C"],
    "locations": ["Singapore", "Los Angeles", "Rotterdam"],
    "impact_summary": "Brief description of impact",
    "mitigation_recommendation": "Diversify suppliers and increase inventory buffers.",
    "confidence_score": 0.85,
    "severity": 4
}

Response should be ONLY the JSON object, no other text. If you are unsure, make a reasonable guess. All fields must be present."""
        
        self.impact_prompt = PromptTemplate(
            input_variables=["news_content"],
            template=self.impact_template
        )
        
        self.impact_chain = LLMChain(
            llm=self.llm,
            prompt=self.impact_prompt,
            verbose=True
        )
    
    def extract_entities(self, text: str) -> List[Dict]:
        """Extract named entities from text."""
        try:
            entity_extraction_text = self.entity_extraction_chain.run(text=text)
            try:
                entities = json.loads(entity_extraction_text)
                return entities.get('entities', [])
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing entity extraction JSON: {str(e)}")
                return []
        except Exception as e:
            logger.error(f"Error in entity extraction: {str(e)}")
            return []
    
    def analyze_impact(self, article: Dict) -> Dict:
        """Analyze the potential impact of a news article on supply chain."""
        try:
            logger.info(f"Extracting entities from article: {article['title']}")
            # Extract entities first
            entities = self.extract_entities(article['content'])
            logger.info(f"Extracted entities: {entities}")
            
            # Generate the analysis
            analysis_text = self.impact_chain.run(news_content=article['content'])
            logger.info(f"Impact analysis result: {analysis_text}")
            # DEBUG: Log the raw LLM response for troubleshooting
            print("RAW LLM RESPONSE:", analysis_text)
            logger.info(f"RAW LLM RESPONSE: {analysis_text}")
            # Parse the JSON response
            try:
                impact_analysis = json.loads(analysis_text)
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing impact analysis JSON: {str(e)} | Raw: {analysis_text}")
                impact_analysis = {
                    "affected_areas": {
                        "labor": 0.0,
                        "transportation": 0.0,
                        "raw_materials": 0.0
                    },
                    "timeframe": "unknown",
                    "affected_regions": [],
                    "key_entities": [],
                    "locations": ["Unknown"],
                    "impact_summary": "Error analyzing impact",
                    "mitigation_recommendation": "No specific recommendation provided. Please review manually.",
                    "confidence_score": 0.0,
                    "severity": 3
                }
            # --- Fill defaults if missing ---
            if not impact_analysis.get("locations"):
                impact_analysis["locations"] = ["Unknown"]
            if not impact_analysis.get("mitigation_recommendation"):
                impact_analysis["mitigation_recommendation"] = "No specific recommendation provided. Please review manually."
            if not impact_analysis.get("impact_summary"):
                impact_analysis["impact_summary"] = "No summary provided."
            if not impact_analysis.get("confidence_score"):
                impact_analysis["confidence_score"] = 0.5
            if not impact_analysis.get("severity"):
                impact_analysis["severity"] = 3
            
            return {
                'article_id': article.get('id', ''),
                'title': article.get('title', ''),
                'source': article.get('source', {}).get('name', 'unknown'),
                'published_at': article.get('publishedAt', ''),
                'entities': entities,
                'impact_analysis': impact_analysis
            }
            
        except Exception as e:
            logger.error(f"Error analyzing impact: {str(e)}")
            return {
                'article_id': article.get('id', ''),
                'title': article.get('title', ''),
                'source': article.get('source', {}).get('name', 'unknown'),
                'published_at': article.get('publishedAt', ''),
                'entities': [],
                'impact_analysis': {
                    "affected_areas": {
                        "labor": 0.0,
                        "transportation": 0.0,
                        "raw_materials": 0.0
                    },
                    "timeframe": "unknown",
                    "affected_regions": [],
                    "key_entities": [],
                    "locations": ["Unknown"],
                    "impact_summary": "Error analyzing impact",
                    "mitigation_recommendation": "No specific recommendation provided. Please review manually.",
                    "confidence_score": 0.0,
                    "severity": 3
                }
            }