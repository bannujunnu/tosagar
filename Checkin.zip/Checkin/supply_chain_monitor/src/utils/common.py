import yaml
import json
from typing import Dict, Any
from datetime import datetime
import logging

def load_config(config_path: str) -> Dict:
    """Load configuration from YAML file."""
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def setup_logging(log_path: str) -> None:
    """Setup logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_path),
            logging.StreamHandler()
        ]
    )

def save_to_json(data: Any, filepath: str) -> None:
    """Save data to JSON file."""
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2, default=str)

def load_from_json(filepath: str) -> Any:
    """Load data from JSON file."""
    with open(filepath, 'r') as f:
        return json.load(f)

def format_datetime(dt: datetime) -> str:
    """Format datetime to ISO format."""
    return dt.isoformat()

def parse_datetime(dt_str: str) -> datetime:
    """Parse ISO format datetime string."""
    return datetime.fromisoformat(dt_str)