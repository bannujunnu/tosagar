import streamlit as st
import yaml
from datetime import datetime, timedelta
import os
from pathlib import Path
from news_scraper.news_collector import NewsCollector
from impact_analysis.analyzer import ImpactAnalyzer
from severity_assessment.risk_calculator import RiskCalculator
from action_planner.plan_generator import ActionPlanGenerator
from geo_mapper.location_mapper import LocationMapper
from streamlit_folium import st_folium
import logging
from typing import Any

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Helper for colored severity
SEVERITY_COLORS = {
    1: ("Low", "", "#d4edda"),
    2: ("Moderate", "", "#fff3cd"),
    3: ("Medium", "", "#ffeeba"),
    4: ("High", "", "#f8d7da"),
    5: ("Critical", "", "#f5c6cb")
}

def format_severity(severity: Any) -> str:
    try:
        sev = int(severity)
        label, icon, color = SEVERITY_COLORS.get(sev, (str(severity), "", "#e2e3e5"))
        return f'<span style="background-color:{color};padding:0.3em 0.8em;border-radius:1em;font-weight:bold;">{icon} {label}</span>'
    except Exception:
        return f'<span style="background-color:#e2e3e5;padding:0.3em 0.8em;border-radius:1em;"> {severity}</span>'

class SupplyChainMonitor:
    def __init__(self):
        self.config = self._load_config()
        self.news_collector = NewsCollector(self.config)
        self.impact_analyzer = ImpactAnalyzer(self.config)
        self.risk_calculator = RiskCalculator(self.config)
        self.plan_generator = ActionPlanGenerator(self.config)

    def _load_config(self) -> dict:
        """Load configuration from settings.yaml."""
        config_path = Path(__file__).parent / 'config' / 'settings.yaml'
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Error loading config: {str(e)}")
            return {}

    def run_analysis(self, keywords: list, days_back: int) -> list:
        """Run the full supply chain risk analysis."""
        try:
            # Collect news
            articles = self.news_collector.collect_news(keywords, days_back)
            logger.info(f"Collected {len(articles)} articles")

            # Analyze impact and calculate risk for each article
            results = []
            for article in articles:
                logger.info(f"Processing article: {article['title']}")
                # Analyze impact
                impact_result = self.impact_analyzer.analyze_impact(article)
                logger.info(f"Impact analysis result: {impact_result}")
                
                # Calculate risk
                risk_result = self.risk_calculator.calculate_severity(
                    impact_result['impact_analysis']
                )
                impact_result['risk_assessment'] = risk_result
                
                # Generate action plan
                plan = self.plan_generator.generate_plan(
                    impact_result['impact_analysis'],
                    [],  # Historical actions - to be implemented
                    []   # Competitor actions - to be implemented
                )
                impact_result['action_plan'] = plan
                
                results.append(impact_result)
            
            return results
        except Exception as e:
            logger.error(f"Error in analysis: {str(e)}")
            return []

def main():
    st.title("Supply Chain Risk Monitor")
    
    # Load config for default values
    config = {}
    try:
        config_path = Path(__file__).parent / 'config' / 'settings.yaml'
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
    except Exception as e:
        st.error(f"Error loading config: {str(e)}")
    
    # Get default keywords from config
    default_keywords = config.get('news_settings', {}).get('keywords', [
        "Amgen supply chain disruption",
        "Amgen logistics delay",
        "Amgen manufacturing shortage",
        "Amgen transportation issue",
        "Amgen labor strike",
        "Amgen raw material shortage"
    ])
    
    # Get default days back from config
    default_days = config.get('news_settings', {}).get('days_back', 7)
    
    # Sidebar inputs
    st.sidebar.header("Analysis Parameters")
    
    # Keywords input with default values from config
    keywords_str = st.sidebar.text_area(
        "Keywords (one per line)",
        value="\n".join(default_keywords)
    )
    keywords = [k.strip() for k in keywords_str.split("\n") if k.strip()]
    
    # Days back input with default value from config
    days_back = st.sidebar.slider(
        "Days to Look Back",
        min_value=1,
        max_value=30,
        value=default_days
    )
    
    # Initialize monitor
    monitor = SupplyChainMonitor()
    
    # Persist results in session_state
    if 'impact_result' not in st.session_state:
        st.session_state['impact_result'] = None

    # Run analysis button
    if st.sidebar.button("Run Analysis"):
        with st.spinner("Analyzing supply chain risks..."):
            results = monitor.run_analysis(keywords, days_back)
            st.session_state['impact_result'] = results

    result = st.session_state.get('impact_result')

    # Render all sections regardless, with fallback messages
    if result:
        # Display results
        for idx, result_item in enumerate(result):
            with st.expander(f"{result_item['title']} ({result_item['source']})"):
                st.write(f"Published: {result_item['published_at']}")
                
                # --- Impact Summary Section ---
                impact = result_item.get('impact_analysis', {})
                st.write("DEBUG IMPACT:", impact)
                risk = result_item.get('risk_assessment', {})
                plan = result_item.get('action_plan', {})
                
                # Robust extraction
                impact_summary = (
                    impact.get('impact_summary') or
                    impact.get('summary') or
                    impact.get('description') or
                    'N/A'
                )
                locations_list = impact.get('locations') or impact.get('effected_locations') or []
                if isinstance(locations_list, str):
                    locations = locations_list
                elif isinstance(locations_list, list):
                    locations = ', '.join(locations_list)
                else:
                    locations = 'N/A'
                confidence = impact.get('confidence_score', 'N/A')
                severity = (
                    risk.get('severity') or
                    impact.get('severity') or
                    result_item.get('severity') or
                    'N/A'
                )
                
                # Display summary at top (always visible)
                st.markdown("**Impact Summary**")
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown(f"**Summary:** {impact_summary}")
                    st.markdown(f"**Effected Locations:** {locations}")
                with col2:
                    st.markdown(f"**Confidence Score:** {confidence}")
                    st.markdown(f"**Severity:** {format_severity(severity)}", unsafe_allow_html=True)
                
                # --- Impact Analysis Table ---
                st.markdown("**Impact Analysis Details**")
                if isinstance(impact, dict):
                    impact_type = impact.get('impact_type', 'N/A')
                    st.markdown(f"""
| Impact Type | Effected Locations | Impact Summary | Confidence |
|-------------|-------------------|---------------|------------|
| {impact_type} | {locations} | {impact_summary} | {confidence} |
""")
                else:
                    st.info("No impact analysis available.")
                
                # Risk Assessment Table
                st.markdown("**Risk Assessment**")
                if isinstance(risk, dict):
                    severity = risk.get('severity', 'N/A')
                    factors = ', '.join(risk.get('risk_factors', [])) if 'risk_factors' in risk else 'N/A'
                    recommendation = risk.get('recommendation', 'N/A')
                    st.markdown(f"Severity: {format_severity(severity)}", unsafe_allow_html=True)
                    st.markdown(f"**Risk Factors:** {factors}")
                    st.markdown(f"**Recommendation:** {recommendation}")
                else:
                    st.info("No risk assessment available.")
                
                # Action Plan Table
                st.markdown("**Action Plan**")
                if isinstance(plan, dict) and plan:
                    actions = plan.get('actions', [])
                    if isinstance(actions, list) and actions:
                        action_rows = []
                        for i, action in enumerate(actions, 1):
                            action_rows.append({
                                'Step': i,
                                'Action': action.get('action', action) if isinstance(action, dict) else action,
                                'Responsible': action.get('responsible', 'N/A') if isinstance(action, dict) else 'N/A',
                                'Due Date': action.get('due_date', 'N/A') if isinstance(action, dict) else 'N/A',
                                'Notes': action.get('notes', '') if isinstance(action, dict) else ''
                            })
                        st.table(action_rows)
                    else:
                        st.info("No action steps provided.")
                elif isinstance(plan, list):
                    action_rows = []
                    for i, action in enumerate(plan, 1):
                        action_rows.append({
                            'Step': i,
                            'Action': action,
                            'Responsible': 'N/A',
                            'Due Date': 'N/A',
                            'Notes': ''
                        })
                    st.table(action_rows)
                else:
                    st.info("No action plan available.")
                
                # --- Impact Location Mapping ---
                impact_locations = []
                impact_data = result_item.get('impact_analysis', {})
                if isinstance(impact_data, dict):
                    locations = impact_data.get('locations', [])
                    impact_type = impact_data.get('impact_type', 'Unknown')
                    impact_level = result_item.get('risk_assessment', {}).get('severity', 3)
                    if isinstance(locations, list):
                        mapper = LocationMapper()
                        for loc in locations:
                            geo = mapper.geocode_location(loc)
                            if geo:
                                geo['impact_level'] = impact_level
                                geo['impact_type'] = impact_type
                                impact_locations.append(geo)
                        if impact_locations:
                            folium_map = mapper.create_impact_map(impact_locations)
                            st_folium(folium_map, width=700, height=500)
                        else:
                            st.info("No mappable impact locations found.")
                else:
                    st.info("No impact location data available.")
    else:
        st.info("Run an analysis to see results.")

if __name__ == "__main__":
    main()