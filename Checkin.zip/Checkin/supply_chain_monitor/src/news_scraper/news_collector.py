from typing import Dict, List
from newsapi import NewsApiClient
import tweepy
import facebook
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class NewsCollector:
    def __init__(self, config: Dict):
        # Initialize NewsAPI (primary source)
        self.newsapi = NewsApiClient(api_key=config['newsapi_key'])
        
        # Initialize Twitter API (optional)
        self.twitter_api = None
        if config.get('twitter_api_key') and config.get('twitter_api_secret'):
            try:
                auth = tweepy.OAuthHandler(
                    config['twitter_api_key'],
                    config['twitter_api_secret']
                )
                self.twitter_api = tweepy.API(auth)
                self.twitter_api.verify_credentials()
                logger.info("Twitter API initialized successfully")
            except Exception as e:
                logger.warning(f"Twitter API initialization failed: {str(e)}")
        
        # Initialize Facebook SDK (optional)
        self.facebook_api = None
        if config.get('facebook_access_token'):
            try:
                self.facebook_api = facebook.GraphAPI(
                    access_token=config['facebook_access_token'],
                    version='3.1'  # Using an older version for better compatibility
                )
                logger.info("Facebook API initialized successfully")
            except Exception as e:
                logger.warning(f"Facebook API initialization failed: {str(e)}")
        
        # Store settings
        self.news_settings = config.get('news_settings', {})
        self.twitter_settings = config.get('twitter_settings', {})
        self.facebook_settings = config.get('facebook_settings', {})

    def collect_news(self, keywords: List[str] = None, days_back: int = None) -> List[Dict]:
        """Collect news from all configured sources."""
        try:
            # Use settings if parameters not provided
            if keywords is None:
                keywords = self.news_settings.get('keywords', [])
            if days_back is None:
                days_back = self.news_settings.get('days_back', 7)
            
            articles = []
            max_articles = self.news_settings.get('max_articles', 100)
            
            # Collect from NewsAPI (primary source)
            for keyword in keywords:
                try:
                    news_response = self.newsapi.get_everything(
                        q=keyword,
                        from_param=(datetime.now() - timedelta(days=days_back)).strftime('%Y-%m-%d'),
                        language='en',
                        sort_by='relevancy'
                    )
                    logger.info(f"NewsAPI response for keyword {keyword} is : {news_response}")
                    if news_response and 'articles' in news_response:
                        articles.extend(news_response['articles'])
                        logger.info(f"Collected {len(news_response['articles'])} articles for keyword: {keyword}")
                except Exception as e:
                    logger.error(f"Error collecting news for keyword {keyword}: {str(e)}")
            
            # Collect from Twitter if available
            if self.twitter_api:
                try:
                    max_tweets = self.twitter_settings.get('max_tweets', 100)
                    languages = self.twitter_settings.get('languages', ['en'])
                    
                    for keyword in keywords:
                        try:
                            tweets = self.twitter_api.search_tweets(
                                q=keyword,
                                lang=languages[0],
                                count=max_tweets,
                                tweet_mode='extended'
                            )
                            for tweet in tweets:
                                articles.append({
                                    'source': {'name': 'Twitter'},
                                    'title': f"Tweet from {tweet.user.name}",
                                    'description': tweet.full_text,
                                    'content': tweet.full_text,
                                    'url': f"https://twitter.com/i/web/status/{tweet.id}",
                                    'publishedAt': tweet.created_at.isoformat()
                                })
                            logger.info(f"Collected {len(tweets)} tweets for keyword: {keyword}")
                        except Exception as e:
                            logger.error(f"Error collecting tweets for keyword {keyword}: {str(e)}")
                except Exception as e:
                    logger.error(f"Error in Twitter collection: {str(e)}")
            
            # Collect from Facebook if available
            if self.facebook_api:
                try:
                    max_posts = self.facebook_settings.get('max_posts', 50)
                    logger.info(f"Collecting {max_posts} posts from Facebook")
                    
                    # Amgen's official Facebook page ID
                    amgen_page_id = '180797088632343'  # This is Amgen's public page ID
                    
                    try:
                        # Get posts directly from Amgen's page
                        logger.info(f"Fetching posts from Amgen's Facebook page")
                        posts = self.facebook_api.get_connections(
                            amgen_page_id,
                            'feed',  # Using feed instead of published_posts
                            fields='message,created_time,permalink_url,shares',
                            limit=max_posts
                        )
                        
                        for post in posts.get('data', []):
                            if post.get('message'):  # Only add posts with content
                                # Check if the post content is relevant to our keywords
                                message = post.get('message', '').lower()
                                if any(kw.lower() in message for kw in keywords):
                                    articles.append({
                                        'source': {'name': 'Facebook'},
                                        'title': 'Facebook Post from Amgen',
                                        'description': post.get('message', ''),
                                        'content': post.get('message', ''),
                                        'url': post.get('permalink_url', ''),
                                        'publishedAt': post.get('created_time', datetime.now().isoformat()),
                                        'shares': post.get('shares', {}).get('count', 0)
                                    })
                        
                        logger.info(f"Collected {len(posts.get('data', []))} Facebook posts from Amgen's page")
                            
                    except Exception as e:
                        logger.error(f"Error collecting posts from Amgen's Facebook page: {str(e)}")
                        
                except Exception as e:
                    logger.error(f"Error in Facebook collection: {str(e)}")
            
            # Deduplicate articles
            seen_urls = set()
            unique_articles = []
            for article in articles:
                if article['url'] not in seen_urls:
                    seen_urls.add(article['url'])
                    unique_articles.append(article)
            
            # Limit to max articles
            unique_articles = unique_articles[:max_articles]
            logger.info(f"Collected total of {len(unique_articles)} unique articles")
            
            return unique_articles
            
        except Exception as e:
            logger.error(f"Error in news collection: {str(e)}")
            return []

    def preprocess_articles(self, articles: List[Dict]) -> List[Dict]:
        """Clean and standardize collected articles."""
        processed = []
        for article in articles:
            processed.append({
                'source': article.get('source', {}).get('name', 'Unknown'),
                'title': article.get('title', ''),
                'content': article.get('description', ''),
                'published_date': article.get('publishedAt'),
                'url': article.get('url', ''),
                'processed_date': datetime.now().isoformat()
            })
        return processed