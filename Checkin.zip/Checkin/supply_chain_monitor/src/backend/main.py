import logging
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from agents.supervisor_agent import SupervisorAgent
from fastapi.encoders import jsonable_encoder

app = FastAPI()

# Enable CORS for all origins and methods (adjust origins for production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # You can restrict this to ["http://localhost:4200"] for Angular dev
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ensure log directory exists
os.makedirs(os.path.join(os.path.dirname(__file__), '../logs'), exist_ok=True)
log_path = os.path.join(os.path.dirname(__file__), '../logs/app.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s %(message)s',
    handlers=[logging.FileHandler(log_path), logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# Initialize supervisor agent
supervisor = SupervisorAgent()

class WorkflowRequest(BaseModel):
    query: str
    keywords: list[str] = []
    days_back: int = 7



@app.post("/run_workflow/")
def run_workflow(req: WorkflowRequest):
    logger.info(f"Workflow started with query: {req.query} and keywords: {req.keywords}")
    try:
        # Pass all fields to supervisor
        result = supervisor.run(
            query=req.query,
            keywords=req.keywords,
            days_back=req.days_back
        )
        logger.info(f"Workflow result: {result}")
        encoded_result = jsonable_encoder(result)        
        return encoded_result
    except Exception as e:
        logger.exception(f"Exception during workflow execution: {e}")
        return {"error": str(e)}
