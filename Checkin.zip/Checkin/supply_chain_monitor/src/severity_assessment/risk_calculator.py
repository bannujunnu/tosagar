from typing import Dict
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class RiskCalculator:
    def __init__(self, config: Dict):
        self.impact_weights = config.get('impact_weights', {
            'labor': 0.3,
            'transportation': 0.3,
            'raw_materials': 0.4
        })
        
    def calculate_severity(self, impact_analysis: Dict) -> Dict:
        """Calculate severity score based on impact analysis."""
        logger.info(f"Calculating severity for impact analysis: {impact_analysis}")
        try:
            base_score = self._calculate_base_score(impact_analysis)
            time_factor = self._calculate_time_factor(impact_analysis)
            geo_factor = self._calculate_geo_factor(impact_analysis)
            logger.info(f"Base score: {base_score}, Time factor: {time_factor}, Geo factor: {geo_factor}")
            
            final_score = base_score * time_factor * geo_factor
            final_score = min(final_score * 5.0, 5.0)  # Scale and cap at 5.0
            
            return {
                'severity_score': final_score,
                'components': {
                    'base_score': base_score,
                    'time_factor': time_factor,
                    'geo_factor': geo_factor
                },
                'risk_level': self._get_risk_level(final_score)
            }
        except Exception as e:
            logger.error(f"Error calculating severity: {str(e)}")
            return {
                'severity_score': 1.0,
                'components': {
                    'base_score': 0.2,
                    'time_factor': 1.0,
                    'geo_factor': 1.0
                },
                'risk_level': 'LOW'
            }
    
    def _calculate_base_score(self, impact_analysis: Dict) -> float:
        """Calculate base severity score."""
        try:
            score = 0.0
            affected_areas = impact_analysis.get('affected_areas', {})
            
            for impact_type, weight in self.impact_weights.items():
                impact_score = affected_areas.get(impact_type, 0)
                score += weight * float(impact_score)
            
            return max(min(score, 1.0), 0.0)  # Ensure score is between 0 and 1
        except Exception as e:
            logger.error(f"Error calculating base score: {str(e)}")
            return 0.2  # Default low score on error
    
    def _calculate_time_factor(self, impact_analysis: Dict) -> float:
        """Calculate time-based factor."""
        try:
            time_factors = {
                'immediate': 1.2,
                'short-term': 1.0,
                'long-term': 0.8
            }
            timeframe = impact_analysis.get('timeframe', 'short-term')
            return time_factors.get(timeframe, 1.0)
        except Exception as e:
            logger.error(f"Error calculating time factor: {str(e)}")
            return 1.0
    
    def _calculate_geo_factor(self, impact_analysis: Dict) -> float:
        """Calculate geography-based factor."""
        try:
            num_regions = len(impact_analysis.get('affected_regions', []))
            return min(1 + (num_regions * 0.1), 1.5)  # Cap at 1.5
        except Exception as e:
            logger.error(f"Error calculating geo factor: {str(e)}")
            return 1.0
    
    def _get_risk_level(self, score: float) -> str:
        """Convert numerical score to risk level."""
        if score >= 4.0:
            return 'CRITICAL'
        elif score >= 3.0:
            return 'HIGH'
        elif score >= 2.0:
            return 'MEDIUM'
        else:
            return 'LOW'