from typing import Dict, List
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain.chains import LLMChain
from datetime import datetime
import json
import logging
import os
from langsmith import Client

logger = logging.getLogger(__name__)

class ActionPlanGenerator:
    def __init__(self, config: Dict):
        # Set up LangSmith
        if config.get('langsmith', {}).get('enable_tracing', False):
            os.environ["LANGCHAIN_TRACING_V2"] = "true"
            os.environ["LANGCHAIN_API_KEY"] = config['langsmith']['api_key']
            os.environ["LANGCHAIN_PROJECT"] = config['langsmith']['project_name']
            # Initialize LangSmith client
            self.langsmith_client = Client()
            logger.info("LangSmith tracing enabled")
        
        # Initialize Azure OpenAI
        self.llm = AzureChatOpenAI(
            openai_api_version=config['azure_openai_api_version'],
            azure_deployment=config['azure_openai_deployment'],
            azure_endpoint=config['azure_openai_endpoint'],
            api_key=config['azure_openai_api_key'],
            temperature=0.3,
            tags=["supply_chain_monitor", "action_plan_generation"]
        )
        
        self.plan_template = """Generate an action plan based on the following supply chain impact analysis and historical data.

Impact Analysis: {impact_analysis}

Historical Actions: {historical_actions}

Competitor Actions: {competitor_actions}

Return the action plan in this exact JSON format:
{{
    "actions": [
        {{
            "priority": 1,
            "timeframe": "immediate",
            "action": "Detailed action description",
            "resources_needed": ["Resource 1", "Resource 2"],
            "stakeholders": ["Stakeholder 1", "Stakeholder 2"],
            "success_metrics": ["Metric 1", "Metric 2"]
        }}
    ],
    "estimated_completion_time": "2 weeks",
    "total_cost_estimate": "$50,000 - $75,000",
    "risk_mitigation_strategies": [
        "Strategy 1",
        "Strategy 2"
    ]
}}

Response should be ONLY the JSON object, no other text."""
        
        self.plan_prompt = PromptTemplate(
            input_variables=["impact_analysis", "historical_actions", "competitor_actions"],
            template=self.plan_template
        )
        
        self.plan_chain = LLMChain(
            llm=self.llm,
            prompt=self.plan_prompt,
            verbose=True
        )

    def generate_plan(self, 
                     impact_analysis: Dict,
                     historical_actions: List[Dict],
                     competitor_actions: List[Dict]) -> Dict:
        """Generate action plan based on impact analysis and historical data."""
        try:
            # Generate the plan
            plan_text = self.plan_chain.run(
                impact_analysis=json.dumps(impact_analysis, indent=2),
                historical_actions=json.dumps(historical_actions, indent=2),
                competitor_actions=json.dumps(competitor_actions, indent=2)
            )
            
            # Parse the JSON response
            try:
                plan_data = json.loads(plan_text)
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing plan JSON: {str(e)}")
                plan_data = {
                    "actions": [],
                    "estimated_completion_time": "unknown",
                    "total_cost_estimate": "unknown",
                    "risk_mitigation_strategies": []
                }
            
            return {
                'timestamp': datetime.now().isoformat(),
                'impact_id': impact_analysis.get('id'),
                'action_plan': plan_data,
                'severity_level': impact_analysis.get('severity', 'UNKNOWN'),
                'status': 'PROPOSED'
            }
            
        except Exception as e:
            logger.error(f"Error generating action plan: {str(e)}")
            return {
                'timestamp': datetime.now().isoformat(),
                'impact_id': impact_analysis.get('id'),
                'action_plan': {
                    "actions": [],
                    "estimated_completion_time": "unknown",
                    "total_cost_estimate": "unknown",
                    "risk_mitigation_strategies": []
                },
                'severity_level': 'UNKNOWN',
                'status': 'ERROR'
            }

    def prioritize_actions(self, plan: Dict) -> Dict:
        """Prioritize actions in the plan based on urgency and impact."""
        try:
            actions = plan.get('action_plan', {}).get('actions', [])
            
            # Sort actions by priority
            prioritized = sorted(
                actions,
                key=lambda x: (x.get('priority', 5), x.get('timeframe') != 'immediate'),
                reverse=True
            )
            
            plan['action_plan']['actions'] = prioritized
            return plan
        except Exception as e:
            logger.error(f"Error prioritizing actions: {str(e)}")
            return plan