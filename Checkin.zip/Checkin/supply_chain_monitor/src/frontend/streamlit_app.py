import streamlit as st
import requests
import yaml
from streamlit_folium import st_folium
import json
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import folium
import time
from geopy.geocoders import Nominatim

# Page configuration
st.set_page_config(
    page_title="Amgen Supply Chain Risk Monitor",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {color:#1E88E5; font-size:42px !important; font-weight:600 !important; margin-bottom:0px !important;}
    .sub-header {color:#424242; font-size:22px !important; font-weight:300 !important; margin-top:0px !important;}
    .card {padding:15px; border-radius:10px; margin-bottom:15px; background-color:white; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);}
    .news-card {border-left: 4px solid #1E88E5; padding-left:10px;}
    .risk-high {color:white; background-color:#FF5252; padding:2px 8px; border-radius:4px;}
    .risk-medium {color:white; background-color:#FFA726; padding:2px 8px; border-radius:4px;}
    .risk-low {color:white; background-color:#66BB6A; padding:2px 8px; border-radius:4px;}
    .metric-card {text-align:center; padding:20px; border-radius:10px;}
    .metric-value {font-size:36px; font-weight:bold;}
    .metric-label {font-size:14px; color:#616161;}
    .stTabs [data-baseweb="tab-list"] {gap: 24px;}
    .stTabs [data-baseweb="tab"] {height: 50px; white-space: pre-wrap;}
</style>
""", unsafe_allow_html=True)

# Header
st.markdown('<p class="main-header">Amgen Supply Chain Risk Monitoring</p>', unsafe_allow_html=True)
st.markdown('<p class="sub-header">Real-time insights for proactive supply chain management</p>', unsafe_allow_html=True)

# Load keywords from config
with open('../config/settings.yaml', 'r') as f:
    config = yaml.safe_load(f)
news_settings = config.get('news_settings', {})
keywords = news_settings.get('keywords', [])
default_days = news_settings.get('days_back', 7)

# Create a nice form with columns
st.markdown("### 🔎 Search Parameters")
with st.container():
    st.markdown('<div class="card">', unsafe_allow_html=True)
    col1, col2 = st.columns([3, 1])
    
    with col1:
        query = st.text_input('🔍 Enter your supply chain query:', placeholder="E.g., semiconductor shortage in Taiwan")
        
        # Add query to keywords list if it's not empty
        display_keywords = keywords.copy()
        default_selected = keywords.copy()
        
        if query and query.strip():
            # Add query to keywords if it's not already there
            if query not in display_keywords:
                display_keywords.append(query)
            # Make sure query is selected
            if query not in default_selected:
                default_selected.append(query)
                
        selected_keywords = st.multiselect('🏷️Select relevant keywords:', display_keywords, default=default_selected)
    
    with col2:
        days_back = st.slider('📅 Days to look back:', 1, 30, default_days)
        today = datetime.now().strftime("%Y-%m-%d")
        st.caption(f"Searching news from: {(datetime.now() - pd.Timedelta(days=days_back)).strftime('%Y-%m-%d')} to {today}")
    
    st.markdown('</div>', unsafe_allow_html=True)

# --- Workflow Button and Data Persistence ---
if 'result' not in st.session_state:
    st.session_state.result = None
if 'has_run' not in st.session_state:
    st.session_state.has_run = False

# Centered button with custom styling
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    run_clicked = st.button('Run Supply Chain Analysis', use_container_width=True, type="primary")



if run_clicked:
    # Create a more visually appealing progress section
    st.markdown("<div style='background-color:#f8f9fa; padding:15px; border-radius:10px; margin-bottom:20px;'>", unsafe_allow_html=True)
    
    progress_steps = [
        ("📰 Collecting news articles and market intelligence...", 0.18),
        ("📊 Analyzing supply chain impact and dependencies...", 0.36),
        ("🗺️ Mapping affected locations and facilities...", 0.54),
        ("📝 Generating strategic action plans...", 0.72),
        ("⚠️ Calculating risk severity and business impact...", 0.90),
        ("🚀 Finalizing comprehensive supply chain assessment...", 1.0),
    ]
    
    progress_bar = st.progress(0)
    status_placeholder = st.empty()
    
    # Animated progress updates
    for msg, prog in progress_steps:
        status_placeholder.info(msg)
        progress_bar.progress(prog)
        time.sleep(0.5)
    
    try:
        status_placeholder.info("🔄 Contacting AI agents and assembling results...")
        print(f"Selected Keywords in streamlit app  which are posted to backend are: {selected_keywords}")
        resp = requests.post(
            config['api_url'],
            json={'query': query, 'keywords': selected_keywords, 'days_back': days_back}
        )
        st.markdown("</div>", unsafe_allow_html=True)
        if resp.status_code == 200:
            st.session_state.result = resp.json()
            st.session_state.has_run = True
            status_placeholder.success("✅ Workflow completed!")
        else:
            st.session_state.result = None
            st.session_state.has_run = True
            status_placeholder.error("❌ Failed to run workflow.")
    except Exception as e:
        st.session_state.result = None
        st.session_state.has_run = True
        status_placeholder.error(f"❌ Error: {e}")
    progress_bar.empty()

# Only show results if workflow has been run and result exists
if st.session_state.has_run and st.session_state.result:
    result = st.session_state.result
    
    # Create a dashboard header with key metrics
    st.markdown("<hr>", unsafe_allow_html=True)
    st.markdown("## 📊 Supply Chain Risk Dashboard", unsafe_allow_html=True)
    
    # Extract data for metrics
    locations_data = result.get('locations', {}).get('locations', []) if result else []
    news_items = result.get('news', {}).get('news', []) if result else []
    risk_items = result.get('risk', []) if result else []
    
    # Calculate metrics
    num_locations = len(locations_data)
    num_news = len(news_items)
    high_risk_count = sum(1 for risk in risk_items if isinstance(risk, dict) and risk.get('severity', '').lower() == 'high')
    
    # Display metrics in cards
    metric_cols = st.columns(4)
    with metric_cols[0]:
        st.markdown("""
        <div style="background-color:#e3f2fd; padding:15px; border-radius:10px; text-align:center;">
            <div style="font-size:36px; font-weight:bold; color:#1976D2;">{}</div>
            <div style="font-size:14px; color:#424242;">Affected Locations</div>
        </div>
        """.format(num_locations), unsafe_allow_html=True)
    
    with metric_cols[1]:
        st.markdown("""
        <div style="background-color:#fff8e1; padding:15px; border-radius:10px; text-align:center;">
            <div style="font-size:36px; font-weight:bold; color:#FFA000;">{}</div>
            <div style="font-size:14px; color:#424242;">News Articles</div>
        </div>
        """.format(num_news), unsafe_allow_html=True)
    
    st.markdown("<hr>", unsafe_allow_html=True)
    
    # --- 1. Show the map at the top ---
    st.subheader("🗺️ Impacted Locations Map")
    map_html = result.get('locations', {}).get('impact_map_html') if result else None
    
    if map_html:
        with st.container():
            st.markdown('<div class="card" style="padding:0; overflow:hidden;">', unsafe_allow_html=True)
            st.components.v1.html(map_html, width=None, height=500, scrolling=False)
            st.markdown('</div>', unsafe_allow_html=True)
    else:
        st.info("No map data available.")

    # --- 2. Show location details with improved UI ---
    if locations_data:
        st.markdown("<hr>", unsafe_allow_html=True)
        st.subheader("🌐 Supply Chain Location Analysis")
        
        # Create a dropdown with better styling
        st.markdown('<div class="card">', unsafe_allow_html=True)
        location_names = [loc.get('name', f"Location {i+1}") for i, loc in enumerate(locations_data)]
        
        # Add location type and risk level indicators to dropdown
        location_display = []
        for i, loc in enumerate(locations_data):
            loc_name = loc.get('name', f"Location {i+1}")
            loc_type = loc.get('type', 'Facility')
            
            # Get risk level for this location
            risk_level = "Unknown"
            risk_color = "gray"
            if result.get('risk', []) and i < len(result.get('risk', [])):
                risk = result.get('risk', [])[i]
                if isinstance(risk, dict):
                    severity = risk.get('severity', '').lower()
                    if severity == 'high':
                        risk_level = "High Risk"
                        risk_color = "#FF5252"
                    elif severity == 'medium':
                        risk_level = "Medium Risk"
                        risk_color = "#FFA726"
                    elif severity == 'low':
                        risk_level = "Low Risk"
                        risk_color = "#66BB6A"
            
            location_display.append(f"{loc_name} ({loc_type}) - <span style='color:{risk_color};'>{risk_level}</span>")
        
        if 'selected_idx' not in st.session_state:
            st.session_state.selected_idx = 0
            
        # Create a more visually appealing dropdown
        selected_idx = st.selectbox(
            "📍 Select a location to analyze:",
            range(len(location_names)),
            format_func=lambda i: location_names[i],
            index=st.session_state.selected_idx,
            key='selected_idx'
        )
        selected_location = locations_data[selected_idx]
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Create tabs for different analysis sections
        st.markdown(f"### Analysis for: {selected_location.get('name', 'Unknown')}")
        
        # Create tabs for different types of information
        tabs = st.tabs(["🗺️ Location Info", "📰 News", "📊 Impact Analysis", "📝 Action Plan"])
        
        # Tab 1: Location Information
        with tabs[0]:
            col1, col2 = st.columns(2)
            
            # Function to get detailed address from coordinates
            @st.cache_data(ttl=3600)  # Cache for 1 hour
            def get_address_from_coords(lat, lng):
                try:
                    if not lat or not lng:
                        return None
                    
                    geolocator = Nominatim(user_agent="supply_chain_monitor")
                    location = geolocator.reverse(f"{lat}, {lng}", language="en")
                    if location and location.raw.get('address'):
                        return location.raw['address']
                    return None
                except Exception as e:
                    st.warning(f"Could not retrieve address details: {e}")
                    return None
            
            with col1:
                st.markdown("<div class='card'>", unsafe_allow_html=True)
                st.markdown("#### 📍 Location Details")
                
                # Get coordinates
                lat = selected_location.get('lat')
                lng = selected_location.get('lng')
                
                # Get detailed address if coordinates are available
                address_details = None
                if lat and lng:
                    with st.spinner("Fetching location details..."):
                        address_details = get_address_from_coords(lat, lng)
                
                # Format location details with enhanced address information
                location_info = {
                    "Name": selected_location.get('name', 'Unknown'),
                    "Type": selected_location.get('type', 'Facility'),
                    "Coordinates": f"{lat}, {lng}" if lat and lng else "Not available"
                }
                
                # Display basic info
                for k, v in location_info.items():
                    st.markdown(f"**{k}:** {v}")
                
                # Display address details if available
                if address_details:
                    st.markdown("<hr style='margin:10px 0'>", unsafe_allow_html=True)
                    st.markdown("**🏠 Detailed Address:**")
                    
                    # Create a more structured address display
                    address_components = [
                        ("Street", address_details.get('road', address_details.get('street', ''))),
                        ("House Number", address_details.get('house_number', '')),
                        ("Neighborhood", address_details.get('suburb', address_details.get('neighbourhood', ''))),
                        ("City", address_details.get('city', address_details.get('town', address_details.get('village', '')))),
                        ("County/District", address_details.get('county', address_details.get('district', ''))),
                        ("State/Province", address_details.get('state', address_details.get('province', ''))),
                        ("Postal Code", address_details.get('postcode', '')),
                        ("Country", address_details.get('country', ''))
                    ]
                    
                    # Only display components that have values
                    for label, value in address_components:
                        if value:
                            st.markdown(f"**{label}:** {value}")
                else:
                    # Use the address from the data if geocoding failed
                    if selected_location.get('address'):
                        st.markdown("<hr style='margin:10px 0'>", unsafe_allow_html=True)
                        st.markdown(f"**Address:** {selected_location.get('address')}")
                
                st.markdown("</div>", unsafe_allow_html=True)
            
            with col2:
                st.markdown("<div class='card'>", unsafe_allow_html=True)
                st.markdown("#### 🏭 Facility Details")
                
                # Additional details that might be in the location data
                facility_info = {k: v for k, v in selected_location.items() 
                               if k not in ['name', 'type', 'country', 'address', 'lat', 'lng']}
                
                if facility_info:
                    for k, v in facility_info.items():
                        st.markdown(f"**{k}:** {v}")
                else:
                    st.info("No additional facility details available.")
                st.markdown("</div>", unsafe_allow_html=True)
        
        # Tab 2: News
        with tabs[1]:
            st.markdown("<div class='card'>", unsafe_allow_html=True)
            news_items = result.get('news', {}).get('news', []) if result else []
            
            # Get location details for matching
            location_name = selected_location.get('name', '').lower()
            location_country = selected_location.get('country', '').lower()
            location_type = selected_location.get('type', '').lower()
            location_city = ''
            location_state = ''
            
            # Try to extract city and state from address if available
            if selected_location.get('address'):
                address_parts = selected_location.get('address', '').lower().split(',')
                if len(address_parts) > 1:
                    location_city = address_parts[0].strip()
                if len(address_parts) > 2:
                    location_state = address_parts[1].strip()
            
            # More comprehensive matching for news articles
            related_news = []
            for n in news_items:
                title = n.get('title', '').lower()
                content = n.get('content', '').lower()
                description = n.get('description', '').lower()
                full_text = title + ' ' + content + ' ' + description
                
                # Match by exact location name
                if location_name and (location_name in title or location_name in content):
                    related_news.append(n)
                    continue
                    
                # Match by country
                elif location_country and location_country in full_text:
                    related_news.append(n)
                    continue
                    
                # Match by city or state if available
                elif (location_city and location_city in full_text) or (location_state and location_state in full_text):
                    related_news.append(n)
                    continue
                    
                # Match by location type (factory, warehouse, etc.) if no other matches
                elif location_type and location_type in full_text:
                    related_news.append(n)
                    continue
                    
                # Match by industry keywords if available in the location data
                elif selected_location.get('industry') and selected_location.get('industry').lower() in full_text:
                    related_news.append(n)
                    continue
                    
                # Match by product keywords if available in the location data
                elif selected_location.get('products') and any(product.lower() in full_text for product in selected_location.get('products', [])):
                    related_news.append(n)
                    continue
            
            if related_news:
                # Display news count
                st.markdown(f"<p style='text-align:right; color:#757575; font-size:14px;'>{len(related_news)} articles found</p>", unsafe_allow_html=True)
                
                for i, n in enumerate(related_news):
                    # Extract article URL
                    article_url = n.get('url', '')
                    
                    # Create news card with enhanced styling
                    st.markdown(f"<div class='news-card' style='border-left: 4px solid #1E88E5; padding-left:15px; background-color:#f8f9fa; padding:15px; border-radius:8px;'>", unsafe_allow_html=True)
                    
                    # Title with clickable link if URL is available
                    if article_url:
                        st.markdown(f"#### [{n.get('title')}]({article_url})")
                    else:
                        st.markdown(f"#### {n.get('title')}")
                    
                    # Source and date with better formatting
                    published_date = n.get('publishedAt', '')
                    source = n.get('source', 'Unknown Source')
                    
                    st.markdown(f"<div style='display:flex; justify-content:space-between; margin-bottom:10px;'>"
                               f"<span style='color:#616161; font-size:13px;'>Source: <b>{source}</b></span>"
                               f"<span style='color:#616161; font-size:13px;'>Published: <b>{published_date}</b></span>"
                               f"</div>", unsafe_allow_html=True)
                    
                    # Content with truncation for long articles
                    content = n.get('content', '')
                    if len(content) > 500:
                        st.markdown(f"{content[:500]}...")
                        with st.expander("Read more"):
                            st.markdown(content)
                    else:
                        st.markdown(content)
                    
                    # Add link button if URL is available
                    if article_url:
                        st.markdown(f"<div style='text-align:right;'>"
                                   f"<a href='{article_url}' target='_blank' style='display:inline-block; padding:5px 15px; background-color:#1E88E5; color:white; text-decoration:none; border-radius:4px; font-size:13px;'>"
                                   f"Read Full Article 🔗</a></div>", unsafe_allow_html=True)
                    
                    st.markdown("</div>", unsafe_allow_html=True)
                    
                    if i < len(related_news) - 1:
                        st.markdown("<div style='height:15px;'></div>", unsafe_allow_html=True)
            else:
                # If no directly related news, show general supply chain news
                general_news = news_items[:5] if news_items else []
                if general_news:
                    st.markdown("<p style='color:#757575;'>No articles directly related to this location. Showing general supply chain news:</p>", unsafe_allow_html=True)
                    st.markdown(f"<p style='text-align:right; color:#757575; font-size:14px;'>{len(general_news)} articles found</p>", unsafe_allow_html=True)
                    
                    for i, n in enumerate(general_news):
                        # Extract article URL
                        article_url = n.get('url', '')
                        
                        # Create news card with enhanced styling
                        st.markdown(f"<div class='news-card' style='border-left: 4px solid #9E9E9E; padding-left:15px; background-color:#f8f9fa; padding:15px; border-radius:8px;'>", unsafe_allow_html=True)
                        
                        # Title with clickable link if URL is available
                        if article_url:
                            st.markdown(f"#### [{n.get('title')}]({article_url})")
                        else:
                            st.markdown(f"#### {n.get('title')}")
                        
                        # Source and date with better formatting
                        published_date = n.get('publishedAt', '')
                        source = n.get('source', 'Unknown Source')
                        
                        st.markdown(f"<div style='display:flex; justify-content:space-between; margin-bottom:10px;'>"
                                   f"<span style='color:#616161; font-size:13px;'>Source: <b>{source}</b></span>"
                                   f"<span style='color:#616161; font-size:13px;'>Published: <b>{published_date}</b></span>"
                                   f"</div>", unsafe_allow_html=True)
                        
                        # Content with truncation for long articles
                        content = n.get('content', '')
                        if len(content) > 500:
                            st.markdown(f"{content[:500]}...")
                            with st.expander("Read more"):
                                st.markdown(content)
                        else:
                            st.markdown(content)
                        
                        # Add link button if URL is available
                        if article_url:
                            st.markdown(f"<div style='text-align:right;'>"
                                       f"<a href='{article_url}' target='_blank' style='display:inline-block; padding:5px 15px; background-color:#9E9E9E; color:white; text-decoration:none; border-radius:4px; font-size:13px;'>"
                                       f"Read Full Article 🔗</a></div>", unsafe_allow_html=True)
                        
                        st.markdown("</div>", unsafe_allow_html=True)
                        
                        if i < len(general_news) - 1:
                            st.markdown("<div style='height:15px;'></div>", unsafe_allow_html=True)
                else:
                    st.info("No news articles available.")
            st.markdown("</div>", unsafe_allow_html=True)
        
        # Tab 3: Impact Analysis
        with tabs[2]:
            st.markdown("<div class='card'>", unsafe_allow_html=True)
            analysis_items = result.get('analysis', []) if result else []
            analysis_for_loc = [a for a in analysis_items if selected_location.get('name', '').lower() in json.dumps(a).lower()]
            
            if analysis_for_loc:
                analysis = analysis_for_loc[0]
                
                # Header with icon
                st.markdown("<div style='display:flex; align-items:center; margin-bottom:15px;'>"
                           "<span style='font-size:24px; margin-right:10px;'>📊</span>"
                           "<h3 style='margin:0; color:#1976D2;'>Impact Analysis</h3>"
                           "</div>", unsafe_allow_html=True)
                
                # Format the impact analysis according to the attachment layout
                impact_card = "<div style='background-color:white; border-radius:8px; padding:15px; margin-bottom:20px; box-shadow:0 1px 3px rgba(0,0,0,0.1); border:1px solid #e0e0e0;'>"
                
                # Areas Affected section
                areas_affected = {}
                if isinstance(analysis, dict):
                    # Try to extract areas affected from various possible fields
                    if 'areas_affected' in analysis:
                        areas_affected = analysis['areas_affected']
                    elif 'affected_areas' in analysis:
                        areas_affected = analysis['affected_areas']
                    elif 'impact_areas' in analysis:
                        areas_affected = analysis['impact_areas']
                    # Try to extract from categories if not found directly
                    else:
                        for key in analysis.keys():
                            if 'area' in key.lower() or 'sector' in key.lower() or 'impact' in key.lower():
                                if isinstance(analysis[key], dict):
                                    areas_affected = analysis[key]
                                    break
                
                # Add Areas Affected section
                impact_card += "<div style='margin-bottom:15px;'>"
                impact_card += "<div style='font-weight:bold; margin-bottom:5px;'>Areas Affected:</div>"
                impact_card += "<ul style='margin-top:0; margin-bottom:10px;'>"
                
                # Convert to proper format
                if isinstance(areas_affected, dict):
                    for k, v in areas_affected.items():
                        impact_card += f"<li>{k.title()}: {v}</li>"
                elif isinstance(areas_affected, list):
                    for area in areas_affected:
                        impact_card += f"<li>{area}</li>"
                elif isinstance(areas_affected, str):
                    impact_card += f"<li>{areas_affected}</li>"
                else:
                    impact_card += "<li>No specific areas affected listed</li>"
                
                impact_card += "</ul></div>"
                
                # Summary section
                summary = ""
                if isinstance(analysis, dict):
                    if 'impact_summary' in analysis:
                        summary = analysis['impact_summary']
                    elif 'summary' in analysis:
                        summary = analysis['summary']
                    elif 'description' in analysis:
                        summary = analysis['description']
                    elif 'overview' in analysis:
                        summary = analysis['overview']
                
                if summary:
                    impact_card += "<div style='margin-bottom:15px;'>"
                    impact_card += "<div style='font-weight:bold; margin-bottom:5px;'>Summary:</div>"
                    impact_card += f"<p style='margin:0;'>{summary}</p>"
                    impact_card += "</div>"
                
                # Recommendation section
                recommendation = ""
                if isinstance(analysis, dict):
                    if 'mitigation_recommendation' in analysis:
                        recommendation = analysis['mitigation_recommendation']
                    elif 'recommendation' in analysis:
                        recommendation = analysis['recommendation']
                    elif 'recommendations' in analysis:
                        recommendation = analysis['recommendations']
                    elif 'action' in analysis:
                        recommendation = analysis['action']
                    elif 'actions' in analysis:
                        recommendation = analysis['actions']
                    elif 'mitigation' in analysis:
                        recommendation = analysis['mitigation']
                
                if recommendation:
                    impact_card += "<div style='margin-bottom:15px;'>"
                    impact_card += "<div style='font-weight:bold; margin-bottom:5px;'>Recommendation:</div>"
                    impact_card += f"<p style='margin:0;'>{recommendation}</p>"
                    impact_card += "</div>"
                
                # Timeframe section
                timeframe = ""
                if isinstance(analysis, dict):
                    if 'timeframe' in analysis:
                        timeframe = analysis['timeframe']
                    elif 'timeline' in analysis:
                        timeframe = analysis['timeline']
                    elif 'duration' in analysis:
                        timeframe = analysis['duration']
                
                if timeframe:
                    impact_card += "<div style='margin-bottom:15px;'>"
                    impact_card += "<div style='font-weight:bold; margin-bottom:5px;'>Timeframe:</div>"
                    impact_card += f"<p style='margin:0;'>{timeframe}</p>"
                    impact_card += "</div>"
                
                # Confidence Score section
                confidence_score = ""
                if isinstance(analysis, dict):
                    if 'confidence_score' in analysis:
                        confidence_score = analysis['confidence_score']
                    elif 'confidence' in analysis:
                        confidence_score = analysis['confidence']
                    elif 'certainty' in analysis:
                        confidence_score = analysis['certainty']
                
                if confidence_score:
                    impact_card += "<div style='margin-bottom:15px;'>"
                    impact_card += "<div style='font-weight:bold; margin-bottom:5px;'>Confidence Score:</div>"
                    impact_card += f"<p style='margin:0;'>{confidence_score}</p>"
                    impact_card += "</div>"
                
                # Severity section
                severity = ""
                if isinstance(analysis, dict):
                    if 'severity' in analysis:
                        severity = analysis['severity']
                    elif 'impact_level' in analysis:
                        severity = analysis['impact_level']
                    elif 'risk_level' in analysis:
                        severity = analysis['risk_level']
                
                if severity:
                    impact_card += "<div style='margin-bottom:15px;'>"
                    impact_card += "<div style='font-weight:bold; margin-bottom:5px;'>Severity:</div>"
                    impact_card += f"<p style='margin:0;'>{severity}</p>"
                    impact_card += "</div>"
                
                # Key Entities section
                key_entities = []
                if isinstance(analysis, dict):
                    if 'key_entities' in analysis:
                        key_entities = analysis['key_entities']
                    elif 'entities' in analysis:
                        key_entities = analysis['entities']
                    elif 'companies' in analysis:
                        key_entities = analysis['companies']
                    elif 'organizations' in analysis:
                        key_entities = analysis['organizations']
                
                if key_entities:
                    impact_card += "<div style='margin-bottom:15px;'>"
                    impact_card += "<div style='font-weight:bold; margin-bottom:5px;'>Key Entities:</div>"
                    impact_card += "<ul style='margin-top:0; margin-bottom:10px;'>"
                    
                    # Handle different formats of key_entities
                    if isinstance(key_entities, list):
                        # If it's a list of strings
                        if all(isinstance(item, str) for item in key_entities):
                            for entity in key_entities:
                                impact_card += f"<li>{entity}</li>"
                        # If it's a list of dictionaries
                        elif all(isinstance(item, dict) for item in key_entities):
                            for entity in key_entities:
                                if 'name' in entity:
                                    impact_card += f"<li>{entity['name']}</li>"
                                elif 'text' in entity:
                                    impact_card += f"<li>{entity['text']}</li>"
                    elif isinstance(key_entities, str):
                        # Split by commas if it's a comma-separated string
                        entities = key_entities.split(',') if ',' in key_entities else [key_entities]
                        for entity in entities:
                            impact_card += f"<li>{entity.strip()}</li>"
                    
                    impact_card += "</ul></div>"
                
                # Affected Regions section
                affected_regions = []
                if isinstance(analysis, dict):
                    if 'affected_regions' in analysis:
                        affected_regions = analysis['affected_regions']
                    elif 'regions' in analysis:
                        affected_regions = analysis['regions']
                    elif 'locations' in analysis:
                        affected_regions = analysis['locations']
                    elif 'countries' in analysis:
                        affected_regions = analysis['countries']
                
                if affected_regions:
                    impact_card += "<div style='margin-bottom:15px;'>"
                    impact_card += "<div style='font-weight:bold; margin-bottom:5px;'>Affected Regions:</div>"
                    impact_card += "<ul style='margin-top:0; margin-bottom:10px;'>"
                    
                    # Handle different formats of affected_regions
                    if isinstance(affected_regions, list):
                        for region in affected_regions:
                            impact_card += f"<li>{region}</li>"
                    elif isinstance(affected_regions, str):
                        # Split by commas if it's a comma-separated string
                        regions = affected_regions.split(',') if ',' in affected_regions else [affected_regions]
                        for region in regions:
                            impact_card += f"<li>{region.strip()}</li>"
                    elif isinstance(affected_regions, dict):
                        for k, v in affected_regions.items():
                            impact_card += f"<li>{k}: {v}</li>"
                    
                    impact_card += "</ul></div>"
                
                # Close the impact card
                impact_card += "</div>"
                
                # Display the impact card
                st.markdown(impact_card, unsafe_allow_html=True)
                
                # Create tabs for different aspects of impact analysis if there's additional data
                impact_categories = []
                
                # Extract other categories from the analysis data that weren't displayed in the card
                if isinstance(analysis, dict):
                    for key in analysis.keys():
                        if key not in ['areas_affected', 'affected_areas', 'impact_areas', 'summary', 'description', 'overview', 'impact_summary',
                                      'recommendation', 'recommendations', 'action', 'actions', 'mitigation', 'mitigation_recommendation',
                                      'timeframe', 'timeline', 'duration', 'confidence_score', 'confidence', 'certainty', 'severity', 
                                      'impact_level', 'risk_level', 'key_entities', 'entities', 'companies', 'organizations', 
                                      'affected_regions', 'regions', 'locations', 'countries', 'published_at']:
                            impact_categories.append(key)
                
               
        # Tab 4: Action Plan
        with tabs[3]:
            st.markdown("<div class='card'>", unsafe_allow_html=True)
            plan_items = result.get('plan', []) if result else []
            
            if plan_items and len(plan_items) > selected_idx:
                plan = plan_items[selected_idx]
                
                # Header with icon
                st.markdown("<div style='display:flex; align-items:center; margin-bottom:15px;'>"
                           "<span style='font-size:24px; margin-right:10px;'>📝</span>"
                           "<h3 style='margin:0; color:#2E7D32;'>Strategic Action Plan</h3>"
                           "</div>", unsafe_allow_html=True)
                
                # Extract action items if they exist
                action_items = []
                priorities = []
                timelines = []
                owners = []
                
                # Try to extract structured data from the plan
                if isinstance(plan, dict):
                    # Check if we have an action_plan field with actions
                    if 'action_plan' in plan and isinstance(plan['action_plan'], dict) and 'actions' in plan['action_plan']:
                        action_items = plan['action_plan']['actions']
                    else:
                        # Look for common action plan fields
                        for key in plan.keys():
                            if 'action' in key.lower() or 'step' in key.lower() or 'task' in key.lower():
                                if isinstance(plan[key], list):
                                    action_items = plan[key]
                                elif isinstance(plan[key], dict):
                                    for k, v in plan[key].items():
                                        action_items.append({"name": k, "description": v})
                            elif 'priorit' in key.lower():
                                priorities = plan[key] if isinstance(plan[key], list) else [plan[key]]
                            elif 'timeline' in key.lower() or 'schedule' in key.lower() or 'deadline' in key.lower():
                                timelines = plan[key] if isinstance(plan[key], list) else [plan[key]]
                            elif 'owner' in key.lower() or 'responsible' in key.lower() or 'assignee' in key.lower():
                                owners = plan[key] if isinstance(plan[key], list) else [plan[key]]
                
                # Display action plan metadata first
                if isinstance(plan, dict) and isinstance(plan.get('action_plan'), dict):
                    action_plan = plan.get('action_plan', {})
                    
                    # Display estimated completion time and cost estimate if available
                    col1, col2 = st.columns(2)
                    with col1:
                        est_completion = action_plan.get('estimated_completion_time', 'Unknown')
                        st.markdown(f"<div style='background-color:#f5f5f5; padding:10px; border-radius:5px; margin-bottom:15px;'>"
                                   f"<span style='font-weight:bold;'>Estimated Completion Time:</span> {est_completion}"
                                   f"</div>", unsafe_allow_html=True)
                    
                    with col2:
                        cost_estimate = action_plan.get('total_cost_estimate', 'Unknown')
                        st.markdown(f"<div style='background-color:#f5f5f5; padding:10px; border-radius:5px; margin-bottom:15px;'>"
                                   f"<span style='font-weight:bold;'>Total Cost Estimate:</span> {cost_estimate}"
                                   f"</div>", unsafe_allow_html=True)
                    
                    # Display risk mitigation strategies if available
                    risk_strategies = action_plan.get('risk_mitigation_strategies', [])
                    if risk_strategies:
                        st.markdown("<div style='font-weight:bold; margin-top:15px; margin-bottom:10px;'>Risk Mitigation Strategies:</div>", unsafe_allow_html=True)
                        strategy_html = "<ul style='margin-top:0; margin-bottom:15px;'>"
                        for strategy in risk_strategies:
                            strategy_html += f"<li>{strategy}</li>"
                        strategy_html += "</ul>"
                        st.markdown(strategy_html, unsafe_allow_html=True)
                
                # If we found structured action items, display them in the format shown in the attachment
                if action_items:
                    st.markdown("<h4 style='margin-top:20px; margin-bottom:15px;'>Actions:</h4>", unsafe_allow_html=True)
                    
                    # Sort action items by priority if available (lower number = higher priority)
                    if all('priority' in item for item in action_items if isinstance(item, dict)):
                        action_items = sorted(action_items, key=lambda x: x.get('priority', 999) if isinstance(x, dict) else 999)
                    
                    # Process each action item
                    for i, item in enumerate(action_items):
                        # Determine the item's structure
                        if isinstance(item, dict):
                            item_name = item.get('name', f"Action {i+1}")
                            item_desc = item.get('description', "")
                            action_text = item.get('action', item_desc)
                            item_priority = item.get('priority', "medium")
                            item_timeline = item.get('timeline', "") or item.get('deadline', "") or item.get('timeframe', "")
                            item_owner = item.get('owner', "") or item.get('responsible', "") or item.get('assignee', "")
                            resources = item.get('resources_needed', []) or item.get('resources', [])
                            stakeholders = item.get('stakeholders', []) or item.get('stakeholder', [])
                            metrics = item.get('success_metrics', []) or item.get('metrics', []) or item.get('kpi', [])
                        else:
                            item_name = f"Action {i+1}"
                            item_desc = str(item)
                            action_text = item_desc
                            item_priority = "medium"
                            item_timeline = timelines[i] if i < len(timelines) else ""
                            item_owner = owners[i] if i < len(owners) else ""
                            resources = []
                            stakeholders = []
                            metrics = []
                        
                        # Convert priority to standardized format
                        if isinstance(item_priority, str):
                            item_priority = item_priority.lower()
                            if "high" in item_priority or "critical" in item_priority or "urgent" in item_priority or item_priority == "1":
                                priority = "high"
                                priority_color = "#c62828"
                                priority_icon = "🔴"
                                priority_display = "High"
                            elif "low" in item_priority or item_priority == "3":
                                priority = "low"
                                priority_color = "#2e7d32"
                                priority_icon = "🟢"
                                priority_display = "Low"
                            else:
                                priority = "medium"
                                priority_color = "#f57f17"
                                priority_icon = "🟠"
                                priority_display = "Medium"
                        elif isinstance(item_priority, int):
                            if item_priority == 1:
                                priority = "high"
                                priority_color = "#c62828"
                                priority_icon = "🔴"
                                priority_display = "High"
                            elif item_priority == 3:
                                priority = "low"
                                priority_color = "#2e7d32"
                                priority_icon = "🟢"
                                priority_display = "Low"
                            else:
                                priority = "medium"
                                priority_color = "#f57f17"
                                priority_icon = "🟠"
                                priority_display = "Medium"
                        else:
                            priority = "medium"
                            priority_color = "#f57f17"
                            priority_icon = "🟠"
                            priority_display = "Medium"
                        
                        # Create timeframe icon and color
                        if item_timeline:
                            if "immediate" in item_timeline.lower() or "urgent" in item_timeline.lower():
                                timeframe_icon = "🔥"
                                timeframe_color = "#c62828"
                            elif "short" in item_timeline.lower():
                                timeframe_icon = "⏱️"
                                timeframe_color = "#f57f17"
                            elif "medium" in item_timeline.lower():
                                timeframe_icon = "📅"
                                timeframe_color = "#1976D2"
                            else:
                                timeframe_icon = "🗓️"
                                timeframe_color = "#616161"
                        
                        # Create a card for this action item in the format shown in the attachment - all in one string
                        card_html = f"<div style='background-color:white; border-radius:8px; padding:15px; margin-bottom:20px; box-shadow:0 2px 5px rgba(0,0,0,0.1); border:1px solid #e0e0e0;'>"
                        card_html += f"<div style='display:flex;'>"
                        card_html += f"<div style='min-width:30px; height:30px; margin-right:15px; background-color:#1E88E5; color:white; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold;'>{i+1}</div>"
                        card_html += f"<div style='flex-grow:1;'>"
                        card_html += f"<div style='font-weight:bold; font-size:16px; margin-bottom:10px;'>{action_text}</div>"
                        card_html += f"<div style='margin-bottom:10px;'>"
                        card_html += f"<div style='font-weight:bold; margin-bottom:5px;'>Timeframe: {item_timeline}</div>"
                        card_html += "</div>"
                        
                        # Add resources section
                        card_html += "<div style='margin-bottom:10px;'>"
                        card_html += "<div style='font-weight:bold; margin-bottom:5px;'>Resources:</div>"
                        
                        # Add resources list
                        if resources:
                            if isinstance(resources, str):
                                resources = [resources]
                            card_html += "<ul style='margin-top:0; margin-bottom:10px;'>"
                            for resource in resources:
                                card_html += f"<li>{resource}</li>"
                            card_html += "</ul>"
                        else:
                            card_html += "<p>No specific resources listed</p>"
                        
                        # Add stakeholders section
                        card_html += "</div>"
                        card_html += "<div style='margin-bottom:10px;'>"
                        card_html += "<div style='font-weight:bold; margin-bottom:5px;'>Stakeholders:</div>"
                        
                        # Add stakeholders list
                        if stakeholders:
                            if isinstance(stakeholders, str):
                                stakeholders = [stakeholders]
                            card_html += "<ul style='margin-top:0; margin-bottom:10px;'>"
                            for stakeholder in stakeholders:
                                card_html += f"<li>{stakeholder}</li>"
                            card_html += "</ul>"
                        else:
                            card_html += "<p>No specific stakeholders listed</p>"
                        
                        # Add success metrics section
                        card_html += "</div>"
                        card_html += "<div>"
                        card_html += "<div style='font-weight:bold; margin-bottom:5px;'>Success Metrics:</div>"
                        
                        # Add success metrics list
                        if metrics:
                            if isinstance(metrics, str):
                                metrics = [metrics]
                            card_html += "<ul style='margin-top:0; margin-bottom:0;'>"
                            for metric in metrics:
                                card_html += f"<li>{metric}</li>"
                            card_html += "</ul>"
                        else:
                            card_html += "<p>No specific success metrics listed</p>"
                        
                        # Close all divs
                        card_html += "</div>"
                        card_html += "</div>"
                        card_html += "</div>"
                        card_html += "</div>"
                        
                        # Display the card (not in columns anymore)
                        st.markdown(card_html, unsafe_allow_html=True)
                
                # If we couldn't extract structured data, try to extract from action_plan.actions
                elif isinstance(plan, dict) and isinstance(plan.get('action_plan'), dict) and isinstance(plan['action_plan'].get('actions'), list):
                    action_items = plan['action_plan']['actions']
                    st.markdown("<h4 style='margin-top:20px; margin-bottom:15px;'>Actions:</h4>", unsafe_allow_html=True)
                    
                    # Sort action items by priority if available (lower number = higher priority)
                    if all('priority' in item for item in action_items if isinstance(item, dict)):
                        action_items = sorted(action_items, key=lambda x: x.get('priority', 999) if isinstance(x, dict) else 999)
                    
                    # Process each action item
                    for i, item in enumerate(action_items):
                        if isinstance(item, dict):
                            action_text = item.get('action', '')
                            item_timeline = item.get('timeframe', '')
                            resources = item.get('resources_needed', [])
                            stakeholders = item.get('stakeholders', [])
                            metrics = item.get('success_metrics', [])
                            
                            # Create a card for this action item in the format shown in the attachment - all in one string
                            card_html = f"<div style='background-color:white; border-radius:8px; padding:15px; margin-bottom:20px; box-shadow:0 2px 5px rgba(0,0,0,0.1); border:1px solid #e0e0e0;'>"
                            card_html += f"<div style='display:flex;'>"
                            card_html += f"<div style='min-width:30px; height:30px; margin-right:15px; background-color:#1E88E5; color:white; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold;'>{i+1}</div>"
                            card_html += f"<div style='flex-grow:1;'>"
                            card_html += f"<div style='font-weight:bold; font-size:16px; margin-bottom:10px;'>{action_text}</div>"
                            card_html += f"<div style='margin-bottom:10px;'>"
                            card_html += f"<div style='font-weight:bold; margin-bottom:5px;'>Timeframe: {item_timeline}</div>"
                            card_html += "</div>"
                            card_html += "<div style='margin-bottom:10px;'>"
                            card_html += "<div style='font-weight:bold; margin-bottom:5px;'>Resources:</div>"
                            
                            # Add resources list
                            if resources:
                                if isinstance(resources, str):
                                    resources = [resources]
                                card_html += "<ul style='margin-top:0; margin-bottom:10px;'>"
                                for resource in resources:
                                    card_html += f"<li>{resource}</li>"
                                card_html += "</ul>"
                            else:
                                card_html += "<p>No specific resources listed</p>"
                            
                            # Add stakeholders section
                            card_html += "</div>"
                            card_html += "<div style='margin-bottom:10px;'>"
                            card_html += "<div style='font-weight:bold; margin-bottom:5px;'>Stakeholders:</div>"
                            
                            # Add stakeholders list
                            if stakeholders:
                                if isinstance(stakeholders, str):
                                    stakeholders = [stakeholders]
                                card_html += "<ul style='margin-top:0; margin-bottom:10px;'>"
                                for stakeholder in stakeholders:
                                    card_html += f"<li>{stakeholder}</li>"
                                card_html += "</ul>"
                            else:
                                card_html += "<p>No specific stakeholders listed</p>"
                            
                            # Add success metrics section
                            card_html += "</div>"
                            card_html += "<div>"
                            card_html += "<div style='font-weight:bold; margin-bottom:5px;'>Success Metrics:</div>"
                            
                            # Add success metrics list
                            if metrics:
                                if isinstance(metrics, str):
                                    metrics = [metrics]
                                card_html += "<ul style='margin-top:0; margin-bottom:0;'>"
                                for metric in metrics:
                                    card_html += f"<li>{metric}</li>"
                                card_html += "</ul>"
                            else:
                                card_html += "<p>No specific success metrics listed</p>"
                            
                            # Close all divs
                            card_html += "</div>"
                            card_html += "</div>"
                            card_html += "</div>"
                            card_html += "</div>"
                            
                            # Display the card
                            st.markdown(card_html, unsafe_allow_html=True)
                # If we couldn't extract structured data, fall back to the original rendering
                else:
                    # Define a better card rendering function for action plans
                    def render_action_card(data, title=None):
                        with st.container():
                            if title:
                                st.markdown(f"<div style='background-color:#e8f5e9;padding:8px 12px;border-radius:6px;'><b>{title}</b></div>", unsafe_allow_html=True)
                            if isinstance(data, dict):
                                st.markdown("<div style='background-color:#f1f8f2;padding:12px 16px;border-radius:6px;margin-bottom:12px;'>", unsafe_allow_html=True)
                                for k, v in data.items():
                                    if isinstance(v, dict):
                                        st.markdown(f"<b>{k}:</b>", unsafe_allow_html=True)
                                        render_action_card(v)
                                    elif isinstance(v, list):
                                        st.markdown(f"<b>{k}:</b>", unsafe_allow_html=True)
                                        for i, subitem in enumerate(v):
                                            render_action_card(subitem, title=f"Action {i+1}")
                                    else:
                                        st.markdown(f"<b>{k}:</b> {v}", unsafe_allow_html=True)
                                st.markdown("</div>", unsafe_allow_html=True)
                            elif isinstance(data, list):
                                for i, item in enumerate(data):
                                    render_action_card(item, title=f"Action {i+1}")
                            else:
                                st.markdown(f"{data}")
                    
                    render_action_card(plan, "Action Plan")
            else:
                st.info("No action plan for this location.")
            st.markdown("</div>", unsafe_allow_html=True)
    else:
        st.info("No impacted locations found.")
elif st.session_state.has_run and not st.session_state.result:
    st.error('Failed to run workflow.')
