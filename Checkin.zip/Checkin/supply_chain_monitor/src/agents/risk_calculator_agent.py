from typing import Dict
from datetime import datetime
import logging
from crewai import Agent
from pydantic import PrivateAttr

logger = logging.getLogger(__name__)

class RiskCalculatorAgent(Agent):
    _impact_weights = PrivateAttr(default=None)
    
    def __init__(self, config: Dict, **kwargs):
        agent_config = {
            'role': 'Risk Calculator',
            'goal': 'Calculate and quantify supply chain risks based on impact analysis',
            'backstory': 'You are a risk assessment specialist who converts qualitative impact data into quantitative risk metrics.'
        }
        agent_config.update(kwargs)
        super().__init__(**agent_config)
        self._impact_weights = config.get('impact_weights', {
            'labor': 0.3,
            'transportation': 0.3,
            'raw_materials': 0.4
        })

    def run(self, location_data, **kwargs):
        # Calculate risk severity, skip non-dict entries
        results = [
            self.calculate_severity(impact_analysis)
            for impact_analysis in location_data
            if isinstance(impact_analysis, dict)
        ]
        # Log or handle non-dict entries
        non_dicts = [x for x in location_data if not isinstance(x, dict)]
        if non_dicts:
            logger.warning(f"Skipped non-dict impact_analysis entries: {non_dicts}")
        return results

    def calculate_severity(self, impact_analysis: Dict) -> Dict:
        """Calculate severity score based on impact analysis."""
        if not isinstance(impact_analysis, dict):
            logger.error("impact_analysis is not a dict in calculate_severity")
            return {
                'severity_score': 1.0,
                'components': {
                    'base_score': 0.2,
                    'time_factor': 1.0,
                    'geo_factor': 1.0
                },
                'risk_level': 'LOW'
            }
        logger.info(f"Calculating severity for impact analysis: {impact_analysis}")
        try:
            base_score = self._calculate_base_score(impact_analysis)
            logger.info(f"Calculated base score is: {base_score}")
            time_factor = self._calculate_time_factor(impact_analysis)
            logger.info(f"Calculated time factor is: {time_factor}")
            geo_factor = self._calculate_geo_factor(impact_analysis)
            logger.info(f"Calculated geo factor is: {geo_factor}")
            
            final_score = base_score * time_factor * geo_factor
            final_score = min(final_score * 5.0, 5.0)  # Scale and cap at 5.0
            logger.info(f"Calculated final score is: {final_score}")
            
            return {
                'severity_score': final_score,
                'components': {
                    'base_score': base_score,
                    'time_factor': time_factor,
                    'geo_factor': geo_factor
                },
                'risk_level': self._get_risk_level(final_score)
            }
        except Exception as e:
            logger.error(f"Error calculating severity: {str(e)}")
            return {
                'severity_score': 1.0,
                'components': {
                    'base_score': 0.2,
                    'time_factor': 1.0,
                    'geo_factor': 1.0
                },
                'risk_level': 'LOW'
            }
    
    def _calculate_base_score(self, impact_analysis: Dict) -> float:
        """Calculate base severity score."""
        if not isinstance(impact_analysis, dict):
            logger.error("impact_analysis is not a dict in _calculate_base_score")
            return 0.2
        try:
            score = 0.0
            affected_areas = impact_analysis.get('affected_areas', {})
            logger.info(f"Affected areas: {affected_areas}")
            
            for impact_type, weight in self._impact_weights.items():
                impact_score = affected_areas.get(impact_type, 0)
                logger.info(f"Impact score for {impact_type}: {impact_score}")
                score += weight * float(impact_score)
            
            return max(min(score, 1.0), 0.0)  # Ensure score is between 0 and 1
        except Exception as e:
            logger.error(f"Error calculating base score: {str(e)}")
            return 0.2  # Default low score on error
    
    def _calculate_time_factor(self, impact_analysis: Dict) -> float:
        """Calculate time-based factor."""
        if not isinstance(impact_analysis, dict):
            logger.error("impact_analysis is not a dict in _calculate_time_factor")
            return 1.0
        try:
            time_factors = {
                'immediate': 1.2,
                'short-term': 1.0,
                'long-term': 0.8
            }
            timeframe = impact_analysis.get('timeframe', 'short-term')
            logger.info(f"Timeframe: {timeframe}")
            return time_factors.get(timeframe, 1.0)
        except Exception as e:
            logger.error(f"Error calculating time factor: {str(e)}")
            return 1.0
    
    def _calculate_geo_factor(self, impact_analysis: Dict) -> float:
        """Calculate geography-based factor."""
        if not isinstance(impact_analysis, dict):
            logger.error("impact_analysis is not a dict in _calculate_geo_factor")
            return 1.0
        try:
            num_regions = len(impact_analysis.get('affected_regions', []))
            logger.info(f"Number of affected regions: {num_regions}")
            return min(1 + (num_regions * 0.1), 1.5)  # Cap at 1.5
        except Exception as e:
            logger.error(f"Error calculating geo factor: {str(e)}")
            return 1.0
    
    def _get_risk_level(self, score: float) -> str:
        """Convert numerical score to risk level."""
        if score >= 4.0:
            return 'CRITICAL'
        elif score >= 3.0:
            return 'HIGH'
        elif score >= 2.0:
            return 'MEDIUM'
        else:
            return 'LOW'
