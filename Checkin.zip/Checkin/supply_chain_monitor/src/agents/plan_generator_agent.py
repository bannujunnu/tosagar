from typing import Dict, List
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableSequence
from datetime import datetime
import json
import logging
import os
from langsmith import Client
from crewai import Agent
from pydantic import PrivateAttr

logger = logging.getLogger(__name__)

class PlanGeneratorAgent(Agent):
    _langsmith_client = PrivateAttr(default=None)
    _llm = PrivateAttr(default=None)
    _plan_template = PrivateAttr(default=None)
    _plan_prompt = PrivateAttr(default=None)
    _plan_chain = PrivateAttr(default=None)
    
    def __init__(self, config: Dict, **kwargs):
        agent_config = {
            'role': 'Action Plan Generator',
            'goal': 'Generate actionable plans to mitigate supply chain risks',
            'backstory': 'You are a strategic planning expert who develops comprehensive action plans to address supply chain disruptions.'
        }
        agent_config.update(kwargs)
        super().__init__(**agent_config)
        # Set up LangSmith
        if config.get('langsmith', {}).get('enable_tracing', False):
            os.environ["LANGCHAIN_TRACING_V2"] = "true"
            os.environ["LANGCHAIN_API_KEY"] = config['langsmith']['api_key']
            os.environ["LANGCHAIN_PROJECT"] = config['langsmith']['project_name']
            # Initialize LangSmith client
            self._langsmith_client = Client()
            logger.info("LangSmith tracing enabled")
        
        # Initialize Azure OpenAI
        self._llm = AzureChatOpenAI(
            openai_api_version=config['azure_openai_api_version'],
            azure_deployment=config['azure_openai_deployment'],
            azure_endpoint=config['azure_openai_endpoint'],
            api_key=config['azure_openai_api_key'],
            temperature=0.3,
            tags=["supply_chain_monitor", "action_plan_generation"]
        )
        
        self._plan_template = """Generate an action plan based on the following supply chain impact analysis and historical data using you vast experience of 25 years.

Impact Analysis: {impact_analysis}

Historical Actions: {historical_actions}

Competitor Actions: {competitor_actions}

Return the action plan in this exact JSON format:
{{
    "actions": [
        {{
            "priority": 1,
            "timeframe": "immediate",
            "action": "Detailed action description",
            "resources_needed": ["Resource 1", "Resource 2"],
            "stakeholders": ["Stakeholder 1", "Stakeholder 2"],
            "success_metrics": ["Metric 1", "Metric 2"]
        }}
    ],
    "estimated_completion_time": "2 weeks",
    "total_cost_estimate": "$50,000 - $75,000",
    "risk_mitigation_strategies": [
        "Strategy 1",
        "Strategy 2"
    ]
}}

Response should be ONLY the JSON object, no other text."""
        
        self._plan_prompt = PromptTemplate(
            input_variables=["impact_analysis", "historical_actions", "competitor_actions"],
            template=self._plan_template
        )
        
        self._plan_chain = self._plan_prompt | self._llm

    def run(self, risk_data, historical_actions=None, competitor_actions=None, **kwargs):
        historical_actions = historical_actions or []
        competitor_actions = competitor_actions or []
        # Generate action plan
        plans = [self.generate_plan(risk, historical_actions, competitor_actions) for risk in risk_data]
        # Prioritize actions
        prioritized_plans = [self.prioritize_actions(plan) for plan in plans]
        # Return action plan
        return prioritized_plans

    def generate_plan(self, 
                     impact_analysis: Dict,
                     historical_actions: List[Dict],
                     competitor_actions: List[Dict]) -> Dict:
        """Generate action plan based on impact analysis and historical data."""
        try:
            # Generate the plan
            logger.info("Impact Analysis in plan generation is: {impact_analysis}")
            ai_message = self._plan_chain.invoke({
                "impact_analysis": json.dumps(impact_analysis, indent=2),
                "historical_actions": json.dumps(historical_actions, indent=2),
                "competitor_actions": json.dumps(competitor_actions, indent=2)
            })
            plan_text = getattr(ai_message, "content", None) or getattr(ai_message, "text", None) or ai_message
            
            # Parse the JSON response
            try:
                def _extract_json_from_llm(text):
                    import re
                    match = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
                    if match:
                        return match.group(1).strip()
                    return text.strip()
                cleaned_text = _extract_json_from_llm(plan_text) if isinstance(plan_text, str) else plan_text
                plan_data = json.loads(cleaned_text) if isinstance(cleaned_text, str) else cleaned_text
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing plan JSON: {str(e)}")
                plan_data = {
                    "actions": [],
                    "estimated_completion_time": "unknown",
                    "total_cost_estimate": "unknown",
                    "risk_mitigation_strategies": []
                }
            
            return {
                'timestamp': datetime.now().isoformat(),
                'impact_id': impact_analysis.get('id'),
                'action_plan': plan_data,
                'severity_level': impact_analysis.get('severity', 'UNKNOWN'),
                'status': 'PROPOSED'
            }
            
        except Exception as e:
            logger.error(f"Error generating action plan: {str(e)}")
            return {
                'timestamp': datetime.now().isoformat(),
                'impact_id': impact_analysis.get('id'),
                'action_plan': {
                    "actions": [],
                    "estimated_completion_time": "unknown",
                    "total_cost_estimate": "unknown",
                    "risk_mitigation_strategies": []
                },
                'severity_level': 'UNKNOWN',
                'status': 'ERROR'
            }

    def prioritize_actions(self, plan: Dict) -> Dict:
        """Prioritize actions in the plan based on urgency and impact."""
        try:
            actions = plan.get('action_plan', {}).get('actions', [])
            
            # Sort actions by priority
            prioritized = sorted(
                actions,
                key=lambda x: (x.get('priority', 5), x.get('timeframe') != 'immediate'),
                reverse=True
            )
            
            plan['action_plan']['actions'] = prioritized
            return plan
        except Exception as e:
            logger.error(f"Error prioritizing actions: {str(e)}")
            return plan
