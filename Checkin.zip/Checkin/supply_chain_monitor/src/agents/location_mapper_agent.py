from typing import Dict, List
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut
import folium
from crewai import Agent
from pydantic import PrivateAttr
import logging
import time

logger = logging.getLogger(__name__)

class LocationMapperAgent(Agent):
    _geolocator = PrivateAttr(default=None)
    
    def __init__(self, config: Dict = None, **kwargs):
        agent_config = {
            'role': 'Location Mapper',
            'goal': 'Map supply chain events to geographical locations for visualization. If no geolocation is found, return California.',
            'backstory': 'You are a geospatial expert who translates supply chain impact data into actionable location-based insights.'
        }
        agent_config.update(kwargs)
        super().__init__(**agent_config)
        
        # Initialize geocoder with increased timeout
        self._geolocator = Nominatim(user_agent="supply_chain_monitor", timeout=10)
        
        # Cache for geocoded locations to avoid repeated API calls
        self._location_cache = {}

    def run(self, analysis_data, **kwargs):
        # Defensive: Only geocode valid location strings from impact_analysis dicts
        impact_locations = []
        logger.info(f"analysis_data in location mapper run is: {analysis_data}")
        for entry in analysis_data:
            # Accept dicts with 'impact_analysis' -> 'locations', or direct location strings
            locations = []
            impact_level = 3  # default
            impact_type = "unknown"
            if isinstance(entry, dict):
                # Try to extract locations from nested dict
                ia = entry.get('impact_analysis')
                if isinstance(ia, dict):
                    locations = ia.get('locations', [])
                    impact_level = ia.get('severity', 3)
                    impact_type = ia.get('impact_summary', "unknown")
                    mitigation_recommendation = ia.get('mitigation_recommendation', "unknown")
                elif isinstance(ia, list):
                    locations = ia
            elif isinstance(entry, str):
                locations = [entry]
            for location in locations:
                if isinstance(location, str) and location.strip():
                    try:
                        geo = self.geocode_location(location)
                        print(f"Geocoded location is : {geo}")
                        if geo:
                            geo['impact_level'] = impact_level
                            geo['impact_type'] = impact_type
                            geo['mitigation_recommendation'] = mitigation_recommendation
                            logger.info(f"mitigation_recommendation in geocoded data: {mitigation_recommendation}")
                            impact_locations.append(geo)
                    except Exception as e:
                        print(f"Geocoding failed for location '{location}': {e}")
                else:
                    print(f"Skipping invalid location: {location}")
        # Create impact map
        impact_map = self.create_impact_map(impact_locations)
        # Serialize folium.Map as HTML string for JSON response
        impact_map_html = impact_map.get_root().render() if impact_map else None
        # Return both location dicts and HTML for downstream agents/UI
        return {'locations': impact_locations, 'impact_map_html': impact_map_html}

    def geocode_location(self, location: str) -> Dict:
        """Convert location name to coordinates with retry mechanism."""
        # Defensive: skip invalid locations
        if not isinstance(location, str) or not location.strip():
            logger.info(f"Skipping invalid location: {location}")
            return None
            
        # Check cache first
        if location in self._location_cache:
            logger.info(f"Using cached location data for {location}")
            return self._location_cache[location]
        
        # Implement retry with exponential backoff
        max_retries = 3
        retry_delay = 2  # seconds
        
        for attempt in range(max_retries):
            try:
                logger.info(f"Geocoding attempt {attempt+1}/{max_retries} for location: {location}")
                location_data = self._geolocator.geocode(location)
                
                if location_data:
                    result = {
                        'name': location,
                        'latitude': location_data.latitude,
                        'longitude': location_data.longitude
                    }
                    # Cache the result
                    self._location_cache[location] = result
                    return result
                    
                logger.warning(f"No geocoding results found for location: {location}")
                return None
                
            except Exception as e:
                logger.warning(f"Error geocoding location {location} (attempt {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    # Wait before retrying with exponential backoff
                    wait_time = retry_delay * (2 ** attempt)
                    logger.info(f"Waiting {wait_time} seconds before retry...")
                    time.sleep(wait_time)
        
        logger.error(f"Failed to geocode location after {max_retries} attempts: {location}")
        return None

    def create_impact_map(self, impact_locations: List[Dict]) -> folium.Map:
        """Create an interactive map showing impact locations."""
        # Create base map centered on first location
        if not impact_locations:
            return folium.Map(location=[0, 0], zoom_start=2)
        
        center_lat = impact_locations[0]['latitude']
        center_lon = impact_locations[0]['longitude']
        m = folium.Map(location=[center_lat, center_lon], zoom_start=4)
        
        # Add markers for each impact location
        for loc in impact_locations:
            # Enrich popup with more details using HTML
            popup_html = f"""
            <b>Location:</b> {loc.get('name', 'Unknown')}<br>
            <b>Impact Level:</b> {loc.get('impact_level', 'N/A')}<br>           
            <b>Severity:</b> {loc.get('severity', loc.get('impact_level', 'N/A'))}<br>
            <b>Impact Summary:</b> {loc.get('impact_type', 'N/A')}<br>
            <b>Recommendation:</b> {loc.get('mitigation_recommendation', 'N/A')}<br>
            """
            folium.Marker(
                location=[loc['latitude'], loc['longitude']],
                popup=folium.Popup(popup_html, max_width=350),
                icon=folium.Icon(color=self._get_color_for_impact(loc.get('impact_level', 3)))
            ).add_to(m)
        
        return m
    
    def _get_color_for_impact(self, impact_level: int) -> str:
        """Return color based on impact level."""
        colors = {
            1: 'green',
            2: 'lightgreen',
            3: 'orange',
            4: 'lightred',
            5: 'red'
        }
        return colors.get(impact_level, 'gray')
