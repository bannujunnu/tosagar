from typing import Dict, List
from newsapi import NewsApiClient
import tweepy
import facebook
import logging
from datetime import datetime, timedelta
from newspaper import Article
from crewai import Agent
from pydantic import PrivateAttr

logger = logging.getLogger(__name__)

class NewsCollectorAgent(Agent):
    _newsapi: NewsApiClient = PrivateAttr()
    _twitter_api: tweepy.API = PrivateAttr(default=None)
    _facebook_api: facebook.GraphAPI = PrivateAttr(default=None)
    _news_settings: dict = PrivateAttr(default_factory=dict)
    _twitter_settings: dict = PrivateAttr(default_factory=dict)
    _facebook_settings: dict = PrivateAttr(default_factory=dict)
    _logger: logging.Logger = PrivateAttr(default=None)
    
    def __init__(self, config: Dict, **kwargs):
        agent_config = {
            'role': 'News Collector',
            'goal': 'Collect and aggregate news from various sources related to Amgen supply chain events',
            'backstory': """ You are a specialized agent responsible for monitoring news sources to identify events that might impact Amgen (Amgen Inc) supply chains regarding the below aspects.
             - Amgen supply chain disruption
             - Amgen logistics delay
             - Amgen manufacturing shortage
             - Amgen transportation issue
             - Amgen labor strike
             - Amgen raw material shortage
             - Amgen port congestion
             - Amgen warehouse capacity issues
             - Amgen inventory shortage
             - Amgen shipping delay
             - Amgen supplier bankruptcy
             - Amgen trade restrictions
             - Amgen supply chain problems
             - Amgen logistics issues
             - Amgen shipping issues
             - Amgen API manufacturing issues
             - Amgen warehouse issues
             - Amgen inventory issues
             - Amgen procurement issues            
            """
        }
        agent_config.update(kwargs)
        super().__init__(**agent_config)
        # Initialize logger
        self._logger = logging.getLogger(self.__class__.__name__)
        # Initialize NewsAPI (primary source)
        self._newsapi = NewsApiClient(api_key=config['newsapi_key'])
        self._logger.info("NewsAPI initialized successfully")
        
        # Initialize Twitter API (optional)
        self._twitter_api = None
        if config.get('twitter_api_key') and config.get('twitter_api_secret'):
            try:
                auth = tweepy.OAuthHandler(
                    config['twitter_api_key'],
                    config['twitter_api_secret']
                )
                self._twitter_api = tweepy.API(auth)
                self._twitter_api.verify_credentials()
                logger.info("Twitter API initialized successfully")
            except Exception as e:
                self._logger.warning(f"Twitter API initialization failed: {str(e)}")
        
        # Initialize Facebook SDK (optional)
        self._facebook_api = None
        if config.get('facebook_access_token'):
            try:
                self._facebook_api = facebook.GraphAPI(
                    access_token=config['facebook_access_token'],
                    version='3.1'  # Using an older version for better compatibility
                )
                logger.info("Facebook API initialized successfully")
            except Exception as e:
                self._logger.warning(f"Facebook API initialization failed: {str(e)}")
        
        # Store settings as PrivateAttr
        self._news_settings = config.get('news_settings', {})
        logger.info(f"self news settings are: {self._news_settings}")
        self._twitter_settings = config.get('twitter_settings', {})
        logger.info(f"self twitter settings are: {self._twitter_settings}")
        self._facebook_settings = config.get('facebook_settings', {})
        logger.info(f"self facebook settings are: {self._facebook_settings}")

    def run(self,keywords, days_back, **kwargs):
        # Collect news from APIs or social media
        articles = self.collect_news(keywords=keywords, days_back=days_back)
        # Return the collected articles
        return {'news': self.preprocess_articles(articles)}

    def collect_news(self, keywords: List[str] = None, days_back: int = None) -> List[Dict]:
        """Collect news from all configured sources."""
        try:
            # Use settings if parameters not provided
            if keywords is None:
                logger.info("Keywords not provided, colelcting them using settings")
                keywords = self._news_settings.get('keywords', [])
            if days_back is None:
                days_back = self._news_settings.get('days_back', 7)
            
            articles = []
            max_articles = self._news_settings.get('max_articles', 100)            
            self._logger.info(f"Keywords in news collector agent are: {keywords} and days back: {days_back}")
            
            # Collect from NewsAPI (primary source)
            for keyword in keywords:
                try:
                    news_response = self._newsapi.get_everything(
                        q=keyword,
                        from_param=(datetime.now() - timedelta(days=days_back)).strftime('%Y-%m-%d'),
                        language='en',
                        sort_by='relevancy'
                    )
                    logger.info(f"NewsAPI response for keyword {keyword} is : {news_response}")
                    if news_response and 'articles' in news_response:
                        # Pre-process all articles to remove truncated content pattern
                        for art in news_response['articles']:
                            # Remove the original content field to avoid using it as fallback
                            if 'content' in art and isinstance(art['content'], str) and '[+' in art['content'] and 'chars]' in art['content']:
                                # Delete the content field entirely to avoid using it as fallback
                                del art['content']
                        # For each article, scrape the full content from the url
                        for art in news_response['articles']:
                            url = art.get('url')
                            if url:
                                try:
                                    # First, log the original content to see if it has the truncation pattern
                                    if 'content' in art:
                                        logger.info(f"ORIGINAL content before scraping: {art['content'][:100]}...")
                                    
                                    # Attempt to scrape the full article
                                    news_article = Article(url)
                                    news_article.download()
                                    news_article.parse()
                                    full_text = news_article.text.strip()
                                    if full_text:
                                        logger.info(f"Using SCRAPED content for {url}")
                                        art['content'] = full_text                                        
                                    else:
                                        # fallback to description or title ONLY (never use original NewsAPI content)
                                        logger.info(f"Full text is taken from Else Block ")
                                        # Ensure we never use the original content field
                                        if 'content' in art:
                                            del art['content']
                                        art['content'] = art.get('description') or art.get('title') or ''
                                    
                                except Exception as scrape_err:
                                    self._logger.error(f"Failed to scrape article content for {url}: {scrape_err}")
                                    # Ensure we never use the original content field
                                    if 'content' in art:
                                        del art['content']
                                    art['content'] = art.get('description') or art.get('title') or ''
                                    logger.info(f"Full text is taken from Exception Block ")
                                
                            else:
                                # Ensure we never use the original content field
                                if 'content' in art:
                                    del art['content']
                                art['content'] = art.get('description') or art.get('title') or ''
                           
                        articles.extend(news_response['articles'])
                        logger.info(f"Collected {len(news_response['articles'])} articles for keyword: {keyword}")
                except Exception as e:
                    self._logger.error(f"Error collecting news for keyword {keyword}: {str(e)}")
            
            # Collect from Twitter if available
            if self._twitter_api:
                try:
                    max_tweets = self._twitter_settings.get('max_tweets', 100)
                    languages = self._twitter_settings.get('languages', ['en'])
                    
                    for keyword in keywords:
                        try:
                            tweets = self._twitter_api.search_tweets(
                                q=keyword,
                                lang=languages[0],
                                count=max_tweets,
                                tweet_mode='extended'
                            )
                            for tweet in tweets:
                                articles.append({
                                    'source': {'name': 'Twitter'},
                                    'title': f"Tweet from {tweet.user.name}",
                                    'description': tweet.full_text,
                                    'content': tweet.full_text,
                                    'url': f"https://twitter.com/i/web/status/{tweet.id}",
                                    'publishedAt': tweet.created_at.isoformat()
                                })
                            logger.info(f"Collected {len(tweets)} tweets for keyword: {keyword}")
                        except Exception as e:
                            self._logger.error(f"Error collecting tweets for keyword {keyword}: {str(e)}")
                except Exception as e:
                    self._logger.error(f"Error in Twitter collection: {str(e)}")
            
            # Collect from Facebook if available
            if self._facebook_api:
                try:
                    max_posts = self._facebook_settings.get('max_posts', 50)
                    logger.info(f"Collecting {max_posts} posts from Facebook")
                    
                    # Amgen's official Facebook page ID
                    amgen_page_id = '180797088632343'  # This is Amgen's public page ID
                    
                    try:
                        # Get posts directly from Amgen's page
                        logger.info(f"Fetching posts from Amgen's Facebook page")
                        posts = self._facebook_api.get_connections(
                            amgen_page_id,
                            'feed',  # Using feed instead of published_posts
                            fields='message,created_time,permalink_url,shares',
                            limit=max_posts
                        )
                        
                        for post in posts.get('data', []):
                            if post.get('message'):  # Only add posts with content
                                # Check if the post content is relevant to our keywords
                                message = post.get('message', '').lower()
                                if any(kw.lower() in message for kw in keywords):
                                    articles.append({
                                        'source': {'name': 'Facebook'},
                                        'title': 'Facebook Post from Amgen',
                                        'description': post.get('message', ''),
                                        'content': post.get('message', ''),
                                        'url': post.get('permalink_url', ''),
                                        'publishedAt': post.get('created_time', datetime.now().isoformat()),
                                        'shares': post.get('shares', {}).get('count', 0)
                                    })
                        
                        logger.info(f"Collected {len(posts.get('data', []))} Facebook posts from Amgen's page")
                            
                    except Exception as e:
                        self._logger.error(f"Error collecting posts from Amgen's Facebook page: {str(e)}")
                        
                except Exception as e:
                    self._logger.error(f"Error in Facebook collection: {str(e)}")
        
            # Deduplicate articles
            seen_urls = set()
            unique_articles = []
            for article in articles:
                if article['url'] not in seen_urls:
                    seen_urls.add(article['url'])
                    unique_articles.append(article)
            
            # Limit to max articles
            unique_articles = unique_articles[:max_articles]
            logger.info(f"Collected total of {len(unique_articles)} unique articles")
            
            return unique_articles
            
        except Exception as e:
            self._logger.error(f"Error in news collection: {str(e)}")
            return []

    def preprocess_articles(self, articles: List[Dict]) -> List[Dict]:
        """Clean and standardize collected articles."""
        import hashlib
        processed = []
        for i, article in enumerate(articles):
            # Create a unique ID for the article based on URL or title+source
            url = article.get('url', '')
            title = article.get('title', '')
            source = article.get('source', {}).get('name', 'Unknown')
            
            if url:
                # Use URL as the primary identifier (most reliable)
                article_id = hashlib.md5(url.encode()).hexdigest()[:10]
            else:
                # Fallback to title+source+index
                id_string = f"{title}_{source}_{i}"
                article_id = hashlib.md5(id_string.encode()).hexdigest()[:10]
            
            processed.append({
                'id': article_id,  # Add unique ID
                'source': source,
                'title': title,
                'content': article.get('content', article.get('description', '')),  # Now using full content
                'published_date': article.get('publishedAt'),
                'url': url,
                'processed_date': datetime.now().isoformat()
            })
        return processed
