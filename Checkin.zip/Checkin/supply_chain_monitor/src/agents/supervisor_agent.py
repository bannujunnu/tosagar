from crewai import Agent
from pydantic import PrivateAttr
from .news_collector_agent import NewsCollectorAgent
from .analyzer_agent import AnalyzerAgent
from .location_mapper_agent import LocationMapperAgent
from .risk_calculator_agent import RiskCalculatorAgent
from .plan_generator_agent import PlanGeneratorAgent
import yaml
import logging
import os
from langsmith import Client

class SupervisorAgent(Agent):
    _news_collector: NewsCollectorAgent = PrivateAttr(default=None)
    _analyzer: AnalyzerAgent = PrivateAttr(default=None)
    _location_mapper: LocationMapperAgent = PrivateAttr(default=None)
    _risk_calculator: RiskCalculatorAgent = PrivateAttr(default=None)
    _plan_generator: PlanGeneratorAgent = PrivateAttr(default=None)
    _logger = PrivateAttr(default=None)
    _langsmith_client = PrivateAttr(default=None)
    
    def __init__(self, **kwargs):
        agent_config = {
            'role': 'Amgen Supply Chain Supervisor',
            'goal': 'Coordinate and oversee the entire Amgen supply chain monitoring system and assign the tasks to agents',
            'backstory': 'You are an expert central coordinator who manages all specialized agents to provide a comprehensive supply chain risk monitoring solution.'
        }
        agent_config.update(kwargs)
        super().__init__(**agent_config)
        # Setup logging
        self._logger = logging.getLogger(self.__class__.__name__)
        # Load config before using it
        with open('C:/Users/RajKotha/Projects/supply_chain_monitor/supply_chain_monitor/src/config/settings.yaml', 'r') as f:
            config = yaml.safe_load(f)
        # Setup LangSmith tracing if enabled
        if 'langsmith' in kwargs or ('langsmith' in config and config['langsmith'].get('enable_tracing', False)):
            langsmith_cfg = kwargs.get('langsmith', config.get('langsmith', {}))
            os.environ["LANGCHAIN_TRACING_V2"] = "true"
            os.environ["LANGCHAIN_API_KEY"] = langsmith_cfg.get('api_key', '')
            os.environ["LANGCHAIN_PROJECT"] = langsmith_cfg.get('project_name', '')
            self._langsmith_client = Client()
            self._logger.info("LangSmith tracing enabled for SupervisorAgent")
        self._news_collector = NewsCollectorAgent(config=config)
        self._analyzer = AnalyzerAgent(config=config)
        self._location_mapper = LocationMapperAgent(config=config)
        self._risk_calculator = RiskCalculatorAgent(config=config)
        self._plan_generator = PlanGeneratorAgent(config=config)
    def run(self, **kwargs):
        # Extract keywords and days_back if present
        keywords = kwargs.pop('keywords', None)
        self._logger.info(f"Keywords in supervisor agent are: {keywords}")
        days_back = kwargs.pop('days_back', None)
        self._logger.info(f"Days back: {days_back}")
        news = self._news_collector.run(keywords=keywords, days_back=days_back, **kwargs)
        articles = news.get('news', []) if isinstance(news, dict) else []
        self._logger.info(f"Collected articles: {articles}")
        analysis = self._analyzer.run(news_data=articles, **kwargs)
        self._logger.info(f"Analysis: {analysis}")
        locations = self._location_mapper.run(analysis_data=analysis, **kwargs)
        self._logger.info(f"Locations: {locations}")
        # Pass only the list of location dicts to risk calculator
        risk = self._risk_calculator.run(location_data=locations.get('locations', []), **kwargs)
        self._logger.info(f"Risk: {risk}")
        plan = self._plan_generator.run(risk_data=risk, **kwargs)
        self._logger.info(f"Plan: {plan}")
        return {
            'news': news,
            'analysis': analysis,
            'locations': locations,
            'risk': risk,
            'plan': plan
        }
