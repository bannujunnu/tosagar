# Supply Chain Risk Monitoring System

An AI-powered system for monitoring and analyzing supply chain risks from news and social media sources.

# Supply Chain Risk Monitoring System (Agentic Architecture)

This project implements a supply chain risk monitoring system using agentic architecture with CrewAI. Each core module is implemented as an agent, coordinated by a Supervisor agent, and integrated with a Streamlit webapp for user interaction.

## Architecture Overview
- **Agents:**
  - News Collector
  - Analyzer
  - Location Mapper
  - Risk Calculator
  - Plan Generator
  - Supervisor (workflow orchestrator)
- **Backend:** FastAPI
- **Frontend:** Streamlit
- **AI/ML:** LangChain, Hugging Face Transformers
- **DB:** MongoDB

## How to Run
1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
2. **Start FastAPI backend:**
   ```bash
   uvicorn src.backend.main:app --reload
   ```
3. **Start Streamlit frontend:**
   ```bash
   streamlit run src/frontend/streamlit_app.py
   ```

## Configuration
- Edit `src/config/settings.yaml` for API keys and settings.

## Features
- News and social media monitoring (News articles, X platform, Facebook)
- AI-powered impact analysis on supply chain components
- Geolocation-based risk mapping
- Severity assessment
- Automated action plan generation
- Historical analysis integration
- News monitoring from multiple sources
- Impact identification & geolocation mapping
- Severity assessment & action plan generation

## Agentic Workflow
1. News is collected
2. Impact is analyzed
3. Geolocation mapping
4. Severity calculated
5. Action plan generated

## Project Structure

```
supply_chain_monitor/
├── data/
│   ├── news/
│   ├── social_media/
│   └── historical_data/
├── src/
│   ├── data_preprocessing.py
│   ├── risk_analysis.py
│   ├── geolocation_mapping.py
│   ├── severity_assessment.py
│   ├── action_plan.py
│   ├── historical_analysis.py
│   ├── backend/
│   │   └── main.py
│   ├── frontend/
│   │   └── streamlit_app.py
│   ├── agents/
│   │   ├── news_collector.py
│   │   ├── analyzer.py
│   │   ├── location_mapper.py
│   │   ├── risk_calculator.py
│   │   ├── plan_generator.py
│   │   └── supervisor.py
│   └── config/
│       └── settings.yaml
├── README.md
└── requirements.txt
```

---

For more details, see the code in `src/agents/` and the workflow in `src/backend/main.py`.