"""
Azure OCR Processor Client

This script provides a client for the Azure OCR Processor API.
It allows users to upload PDF files, send them to the API for processing,
and display the OCR results in a user-friendly format.

Usage:
    python azure_ocr_client.py --file <pdf_path> --model <model_name> --url <api_url>

Example:
    python azure_ocr_client.py --file sample.pdf --model prebuilt-document
"""

import argparse
import json
import os
import sys
import requests
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.markdown import Markdown
from rich.progress import Progress
from rich.syntax import Syntax
from rich import print as rprint

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Client for Azure OCR Processor API')
    
    parser.add_argument('--file', '-f', required=True, help='Path to the PDF file to process')
    parser.add_argument('--model', '-m', default='prebuilt-document',
                        choices=['prebuilt-layout', 'prebuilt-document', 'prebuilt-read', 
                                'prebuilt-invoice', 'prebuilt-receipt', 'prebuilt-idDocument',
                                'prebuilt-tax.us.w2'],
                        help='Azure Document Intelligence model to use (default: prebuilt-document)')
    parser.add_argument('--url', '-u', default='http://localhost:8001/process-pdf',
                        help='URL of the OCR Processor API (default: http://localhost:8001/process-pdf)')
    parser.add_argument('--output', '-o', help='Path to save the JSON output (optional)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Display detailed output')
    
    return parser.parse_args()

def send_pdf_to_api(file_path, model, api_url, console):
    """Send PDF file to the OCR Processor API."""
    # Normalize file path (remove extra backslashes and handle spaces)
    file_path = os.path.normpath(file_path)
    console.print(f"[bold blue]Processing PDF:[/bold blue] {file_path}")
    console.print(f"[bold blue]Using model:[/bold blue] {model}")
    console.print(f"[bold blue]API URL:[/bold blue] {api_url}")
    
    # If file not found by exact name, try to find it by fuzzy matching
    if not os.path.exists(file_path):
        # Get the directory and filename
        dir_path = os.path.dirname(file_path)
        file_name = os.path.basename(file_path)
        
        # If directory doesn't exist, use current directory
        if not os.path.exists(dir_path):
            dir_path = os.getcwd()
            console.print(f"[yellow]Directory not found, using current directory: {dir_path}[/yellow]")
        
        # List all files in the directory
        console.print(f"[yellow]Looking for similar files in: {dir_path}[/yellow]")
        files_in_dir = os.listdir(dir_path)
        
        # Try to find a file with a similar name
        pdf_files = [f for f in files_in_dir if f.lower().endswith('.pdf')]
        
        if pdf_files:
            # Look for exact match without case sensitivity
            for pdf_file in pdf_files:
                if pdf_file.lower() == file_name.lower():
                    file_path = os.path.join(dir_path, pdf_file)
                    console.print(f"[green]Found matching file (case insensitive): {pdf_file}[/green]")
                    break
            
            # If still not found, look for partial matches
            if not os.path.exists(file_path):
                base_name = os.path.splitext(file_name)[0].lower()
                for pdf_file in pdf_files:
                    if base_name in pdf_file.lower():
                        file_path = os.path.join(dir_path, pdf_file)
                        console.print(f"[green]Found similar file: {pdf_file}[/green]")
                        break
                
                # If still not found, just use the first PDF
                if not os.path.exists(file_path):
                    file_path = os.path.join(dir_path, pdf_files[0])
                    console.print(f"[yellow]No matching file found. Using first PDF: {pdf_files[0]}[/yellow]")
        
        # If still no file found
        if not os.path.exists(file_path):
            console.print(f"[bold red]Error:[/bold red] No PDF files found in {dir_path}")
            sys.exit(1)
    
    console.print(f"[bold green]Using file:[/bold green] {file_path}")
    
    # Prepare the file for upload
    try:
        files = {'file': (os.path.basename(file_path), open(file_path, 'rb'), 'application/pdf')}
        data = {'model': model}
    except Exception as e:
        console.print(f"[bold red]Error opening file:[/bold red] {str(e)}")
        sys.exit(1)
    
    # Send request to API with progress bar
    with Progress() as progress:
        upload_task = progress.add_task("[green]Uploading and processing PDF...", total=100)
        
        try:
            # Set stream=True to get progress updates
            with requests.post(api_url, files=files, data=data, stream=True) as response:
                # Update progress based on response status
                progress.update(upload_task, completed=50)
                
                if response.status_code != 200:
                    progress.update(upload_task, completed=100)
                    console.print(f"[bold red]Error:[/bold red] API returned status code {response.status_code}")
                    try:
                        error_detail = response.json().get('detail', 'Unknown error')
                        console.print(f"[bold red]Error details:[/bold red] {error_detail}")
                    except:
                        console.print(f"[bold red]Error details:[/bold red] {response.text}")
                    sys.exit(1)
                
                # Complete progress
                progress.update(upload_task, completed=100)
                
                # Return the JSON response
                return response.json()
                
        except requests.exceptions.RequestException as e:
            progress.update(upload_task, completed=100)
            console.print(f"[bold red]Error:[/bold red] Failed to connect to API: {str(e)}")
            sys.exit(1)
        finally:
            # Close the file
            files['file'][1].close()

def display_document_metadata(result, console):
    """Display document metadata."""
    metadata = result.get('document_metadata', {})
    
    metadata_table = Table(title="Document Metadata", show_header=True, header_style="bold magenta")
    metadata_table.add_column("Property", style="dim")
    metadata_table.add_column("Value")
    
    metadata_table.add_row("Page Count", str(metadata.get('page_count', 'N/A')))
    metadata_table.add_row("Language", metadata.get('language', 'N/A'))
    
    console.print(metadata_table)
    console.print()

def display_content(result, console, verbose=False):
    """Display document content."""
    content = result.get('content', [])
    
    if not content:
        console.print("[yellow]No content extracted[/yellow]")
        return
    
    for page in content:
        page_number = page.get('page_number', 'Unknown')
        
        # Display page header
        console.print(Panel(f"[bold]Page {page_number}[/bold]", style="blue"))
        
        # Display text content
        if verbose:
            # In verbose mode, show all paragraphs
            for i, paragraph in enumerate(page.get('paragraphs', [])):
                console.print(f"[dim]Paragraph {i+1}:[/dim]")
                console.print(paragraph)
                console.print()
        else:
            # In non-verbose mode, show a summary
            text = page.get('text', '')
            if text:
                console.print(text[:500] + ("..." if len(text) > 500 else ""))
            elif page.get('paragraphs'):
                # If no text but paragraphs exist, show the first paragraph
                console.print(page['paragraphs'][0][:500] + ("..." if len(page['paragraphs'][0]) > 500 else ""))
            
            if len(page.get('paragraphs', [])) > 1:
                console.print(f"[dim]... and {len(page['paragraphs'])-1} more paragraphs (use --verbose to see all)[/dim]")
        
        console.print()

def display_tables(result, console, verbose=False):
    """Display tables extracted from the document."""
    tables = result.get('tables', [])
    
    if not tables:
        console.print("[yellow]No tables extracted[/yellow]")
        return
    
    console.print(Panel(f"[bold]Tables ({len(tables)})[/bold]", style="green"))
    
    for table_data in tables:
        table_id = table_data.get('table_id', 'Unknown')
        page_number = table_data.get('page_number', 'Unknown')
        row_count = table_data.get('row_count', 0)
        column_count = table_data.get('column_count', 0)
        
        console.print(f"[bold]Table {table_id}[/bold] (Page {page_number}, {row_count}x{column_count})")
        
        # Create a rich table
        table = Table(show_header=True, header_style="bold cyan")
        
        # Add columns
        for col in range(column_count):
            table.add_column(f"Column {col+1}")
        
        # Get cells
        cells = table_data.get('cells', [])
        
        # Organize cells by row and column
        grid = {}
        for cell in cells:
            row_idx = cell.get('row_index', 0)
            col_idx = cell.get('column_index', 0)
            content = cell.get('content', '')
            
            if row_idx not in grid:
                grid[row_idx] = {}
            
            grid[row_idx][col_idx] = content
        
        # Add rows to the table
        for row_idx in sorted(grid.keys()):
            row_data = []
            for col_idx in range(column_count):
                row_data.append(grid.get(row_idx, {}).get(col_idx, ''))
            
            table.add_row(*row_data)
        
        console.print(table)
        console.print()
        
        # Limit the number of tables shown in non-verbose mode
        if not verbose and len(tables) > 2 and table_id >= 2:
            console.print(f"[dim]... and {len(tables)-2} more tables (use --verbose to see all)[/dim]")
            break

def display_key_value_pairs(result, console):
    """Display key-value pairs extracted from the document."""
    key_value_pairs = result.get('key_value_pairs', [])
    
    if not key_value_pairs:
        console.print("[yellow]No key-value pairs extracted[/yellow]")
        return
    
    kv_table = Table(title="Key-Value Pairs", show_header=True, header_style="bold magenta")
    kv_table.add_column("Key", style="dim")
    kv_table.add_column("Value")
    
    for kv in key_value_pairs:
        key = kv.get('key', '')
        value = kv.get('value', '')
        kv_table.add_row(key, value)
    
    console.print(kv_table)
    console.print()

def display_entities(result, console, verbose=False):
    """Display entities extracted from the document."""
    entities = result.get('entities', [])
    
    if not entities:
        console.print("[yellow]No entities extracted[/yellow]")
        return
    
    entity_table = Table(title="Entities", show_header=True, header_style="bold magenta")
    entity_table.add_column("Category", style="dim")
    entity_table.add_column("Subcategory", style="dim")
    entity_table.add_column("Content")
    entity_table.add_column("Confidence")
    
    # Limit the number of entities shown in non-verbose mode
    display_entities = entities if verbose else entities[:10]
    
    for entity in display_entities:
        category = entity.get('category', '')
        subcategory = entity.get('subcategory', '')
        content = entity.get('content', '')
        confidence = f"{entity.get('confidence', 0):.2f}"
        
        entity_table.add_row(category, subcategory, content, confidence)
    
    console.print(entity_table)
    
    if not verbose and len(entities) > 10:
        console.print(f"[dim]... and {len(entities)-10} more entities (use --verbose to see all)[/dim]")
    
    console.print()

def save_json_output(result, output_path, console):
    """Save the JSON output to a file."""
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        console.print(f"[bold green]JSON output saved to:[/bold green] {output_path}")
    except Exception as e:
        console.print(f"[bold red]Error saving JSON output:[/bold red] {str(e)}")

def main():
    """Main function."""
    # Parse command line arguments
    args = parse_arguments()
    
    # Initialize rich console
    console = Console()
    
    # Send PDF to API
    result = send_pdf_to_api(args.file, args.model, args.url, console)
    
    # Display results
    console.print(Panel("[bold]OCR Results[/bold]", style="bold blue"))
    
    # Display document metadata
    display_document_metadata(result, console)
    
    # Display content
    console.print(Panel("[bold]Document Content[/bold]", style="bold green"))
    display_content(result, console, args.verbose)
    
    # Display tables
    console.print(Panel("[bold]Tables[/bold]", style="bold green"))
    display_tables(result, console, args.verbose)
    
    # Display key-value pairs
    console.print(Panel("[bold]Key-Value Pairs[/bold]", style="bold green"))
    display_key_value_pairs(result, console)
    
    # Display entities
    console.print(Panel("[bold]Entities[/bold]", style="bold green"))
    display_entities(result, console, args.verbose)
    
    # Save JSON output if requested
    if args.output:
        save_json_output(result, args.output, console)
    
    # Display raw JSON option
    console.print("[dim]To view the raw JSON output, use the --output option to save to a file.[/dim]")

if __name__ == "__main__":
    main()
