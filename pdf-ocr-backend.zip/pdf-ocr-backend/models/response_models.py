from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import date

class ChildDetail(BaseModel):
    """Model for child information"""
    last_name: Optional[str] = Field(None, description="Child's last name")
    first_name: Optional[str] = Field(None, description="Child's first name")
    ssn: Optional[str] = Field(None, description="Child's Social Security Number")
    dob: Optional[str] = Field(None, description="Child's date of birth (MM/DD/YYYY)")
    sex: Optional[str] = Field(None, description="Child's sex (M/F)")
    living_with_applicant: Optional[bool] = Field(None, description="Whether the child lives with the applicant")

class SpouseDetail(BaseModel):
    """Model for spouse/partner information"""
    last_name: Optional[str] = Field(None, description="Spouse's last name")
    first_name: Optional[str] = Field(None, description="Spouse's first name")
    ssn: Optional[str] = Field(None, description="Spouse's Social Security Number")
    dob: Optional[str] = Field(None, description="Spouse's date of birth (MM/DD/YYYY)")
    sex: Optional[str] = Field(None, description="Spouse's sex (M/F)")
    same_address: Optional[bool] = Field(None, description="Whether the spouse lives at the same address as the applicant")

class ApplicantDetail(BaseModel):
    """Model for applicant information"""
    last_name: str = Field(..., description="Applicant's last name")
    first_name: str = Field(..., description="Applicant's first name")
    ssn: Optional[str] = Field(None, description="Applicant's Social Security Number")
    dob: Optional[str] = Field(None, description="Applicant's date of birth (MM/DD/YYYY)")
    sex: Optional[str] = Field(None, description="Applicant's sex (M/F)")
    email: Optional[str] = Field(None, description="Applicant's email address")
    address: Optional[str] = Field(None, description="Applicant's street address")
    city: Optional[str] = Field(None, description="Applicant's city")
    state: Optional[str] = Field(None, description="Applicant's state")
    zip_code: Optional[str] = Field(None, description="Applicant's ZIP code")
    phone: Optional[str] = Field(None, description="Applicant's phone number")
    nj_resident: Optional[bool] = Field(None, description="Whether the applicant is a resident of New Jersey")

class EnrollmentDetail(BaseModel):
    """Model for enrollment information"""
    enrollment_type: Optional[str] = Field(None, description="Type of enrollment (e.g., New Enrollment)")
    enrollment_date: Optional[str] = Field(None, description="Date of enrollment (MM/DD/YYYY)")
    plan_options: Optional[Dict[str, Any]] = Field(None, description="Selected plan options")

class ExtractedDataResponse(BaseModel):
    """Response model for extracted data from PDF"""
    applicant: ApplicantDetail
    enrollment: Optional[EnrollmentDetail] = Field(None, description="Enrollment details")
    spouse: Optional[SpouseDetail] = Field(None, description="Spouse/partner details")
    children: List[ChildDetail] = Field(default_factory=list, description="List of child details")
    raw_text: Optional[str] = Field(None, description="Raw extracted text from the PDF (for debugging)")
