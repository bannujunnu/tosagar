"""
Azure Document Intelligence OCR API

This module provides a FastAPI application for processing PDF documents
using Azure AI Document Intelligence and returning the results in JSON format.

To run the API:
    uvicorn azure_ocr_api:app --host 0.0.0.0 --port 8001

Example curl request:
    curl -X POST -F "file=@sample.pdf" -F "model=prebuilt-document" http://localhost:8001/process-pdf
"""

import os
import tempfile
import logging
from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from services.azure_document_intelligence import AzureDocumentIntelligenceService
from services.azure_openai_processor import AzureOpenAIProcessor

from dotenv import load_dotenv

valid_models = [
        "prebuilt-layout", 
        "prebuilt-document", 
        "prebuilt-read", 
        "prebuilt-invoice", 
        "prebuilt-receipt", 
        "prebuilt-idDocument",
        "prebuilt-tax.us.w2"
    ]
# Load environment variables
load_dotenv()

# Ensure logs directory exists before configuring logging
os.makedirs('logs', exist_ok=True)

# Configure logging
log_file_path = os.path.join('logs', 'azure_ocr_api.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(log_file_path, mode='a')
    ]
)

# Get logger for this module
logger = logging.getLogger(__name__)
logger.info(f"Logging initialized. Log file: {os.path.abspath(log_file_path)}")

# Initialize the FastAPI app
app = FastAPI(
    title="Azure Document Intelligence OCR API",
    description="API for processing PDF documents using Azure AI Document Intelligence",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Initialize services
azure_service = None
openai_processor = None


@app.on_event("startup")
async def startup_event():
    """Initialize services on startup."""
    global azure_service, openai_processor, combined_processor
    try:
        # Initialize Azure Document Intelligence service
        azure_service = AzureDocumentIntelligenceService()
        logger.info("Azure Document Intelligence service initialized")
        
        # Initialize Azure OpenAI processor
        try:
            openai_processor = AzureOpenAIProcessor()
            logger.info("Azure OpenAI processor initialized")
            
        except Exception as openai_error:
            logger.warning(f"Failed to initialize Azure OpenAI processor: {openai_error}")
            logger.warning("Enhanced processing with OpenAI will not be available")
            
    except Exception as e:
        logger.error(f"Failed to initialize Azure Document Intelligence service: {e}")
        # We'll initialize services lazily when needed

@app.get("/")
async def root():
    """Root endpoint that returns a welcome message."""
    return {
        "message": "Azure Document Intelligence OCR API is running.",
        "endpoints": [
            {
                "path": "/process-pdf",
                "description": "Process PDF documents using Azure Document Intelligence"
            },
            
        ]
    }

@app.post("/process-pdf")
async def process_pdf(
    file: UploadFile = File(...),
    model: str = Form("prebuilt-document")
):
    """
    Process a PDF document using Azure AI Document Intelligence.
    
    Args:
        file: The PDF file to process
        model: The Azure Document Intelligence model to use
            Options include:
            - prebuilt-layout: General document layout analysis
            - prebuilt-document: General document analysis
            - prebuilt-read: Text reading
            - prebuilt-invoice: Invoice analysis
            - prebuilt-receipt: Receipt analysis
            - prebuilt-idDocument: ID document analysis
            - prebuilt-tax.us.w2: US W2 tax form analysis
    
    Returns:
        JSON response containing the extracted text and form fields
    """
    global azure_service
    
    # Validate file type
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")
    
    # Validate model    
    if model not in valid_models:
        raise HTTPException(
            status_code=400, 
            detail=f"Invalid model. Must be one of: {', '.join(valid_models)}"
        )
    
    try:
        # Initialize service if not already initialized
        if azure_service is None:
            azure_service = AzureDocumentIntelligenceService()
            logger.info("Azure Document Intelligence service initialized")
        
        # Save the uploaded file to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
            temp_file_path = temp_file.name
            content = await file.read()
            temp_file.write(content)
        
        # Process the PDF
        try:
            logger.info(f"Processing PDF: {file.filename} with model: {model}")
            result = azure_service.process_pdf(temp_file_path, model)
            
            # Clean up the temporary file
            os.unlink(temp_file_path)
            
            logger.info(f"Successfully processed PDF: {file.filename}")
            logger.info(f"Result provided to frontend is :{result}")
            
            # Convert the result to a JSON string before passing to OpenAI processor
            import json
            result_json_string = json.dumps(result)
            
            # Process with OpenAI
            openai_result = openai_processor.process_document_intelligence_result(result_json_string)
            logger.info(f"Open AI Result is: {openai_result}")
            
            # Ensure we're returning a valid JSON object
            if not openai_result or not isinstance(openai_result, dict):
                logger.error(f"Invalid OpenAI result format: {type(openai_result)}")
                return JSONResponse(content={"error": "Invalid result format from OpenAI processor"})
                
            # Ensure the result has the expected structure
            if "Applicant Enrollment Details" not in openai_result:
                logger.warning("Adding missing 'Applicant Enrollment Details' wrapper")
                openai_result = {"Applicant Enrollment Details": openai_result}
            
            # Add a debug field to help troubleshoot frontend issues
            openai_result["_debug"] = {
                "timestamp": str(datetime.now()),
                "resultType": str(type(openai_result)),
                "topLevelKeys": list(openai_result.keys()),
                "hasApplicantDetails": "Applicant Enrollment Details" in openai_result
            }
            
            # Log the exact response being sent to the frontend
            logger.info(f"Final response structure: {list(openai_result.keys())}")
            logger.info(f"Final JSON response: {json.dumps(openai_result)[:500]}...")
            
            # Return a properly formatted JSON response
            return JSONResponse(content=openai_result)
        except Exception as e:
            logger.error(f"Error processing PDF with Azure Document Intelligence: {str(e)}", exc_info=True)
            # Clean up temporary file if it exists
            if os.path.exists(temp_file_path):
                os.unlink(temp_file_path)
            
            # Return a more detailed error message
            error_message = f"Error processing PDF with Azure Document Intelligence: {str(e)}"
            error_type = type(e).__name__
            
            return JSONResponse(
                status_code=500,
                content={
                    "error": error_type,
                    "detail": error_message,
                    "suggestion": "Please check Azure Document Intelligence credentials and API access."
                }
            )
        
    except Exception as e:
        logger.error(f"Error processing PDF: {e}", exc_info=True)
        # Clean up temporary file if it exists
        if 'temp_file_path' in locals() and os.path.exists(temp_file_path):
            os.unlink(temp_file_path)
        
        raise HTTPException(status_code=500, detail=f"Error processing PDF: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
