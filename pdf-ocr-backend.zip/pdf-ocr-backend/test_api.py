import requests
import json
import os
import argparse
from typing import Optional

# Parse command-line arguments
def parse_args():
    parser = argparse.ArgumentParser(description='Test the PDF OCR API with different OCR methods')
    parser.add_argument('--file', type=str, default=r"C:\Users\RajKotha\Desktop\New folder\HorizonTestData\Enrollment.pdf",
                        help='Path to the PDF file to process')
    parser.add_argument('--method', type=str, choices=['legacy', 'donut', 'layout', 'combined'], default='donut',
                        help='OCR method to use (legacy, donut, layout, combined)')
    parser.add_argument('--url', type=str, default='http://localhost:8000/extract',
                        help='API endpoint URL')
    return parser.parse_args()

# Get arguments
args = parse_args()

# Define the API endpoint
url = args.url

# Path to the PDF file
pdf_path = args.file

# OCR method to use
ocr_method = args.method

# Check if the file exists
if not os.path.exists(pdf_path):
    print(f"Error: File not found at {pdf_path}")
    exit(1)

# Prepare the files for the request
files = {
    'file': (os.path.basename(pdf_path), open(pdf_path, 'rb'), 'application/pdf')
}

# Prepare parameters
params = {
    'ocr_method': ocr_method
}

# Send the POST request
try:
    print(f"Sending request to {url}?ocr_method={ocr_method} with file {pdf_path}")
    response = requests.post(url, files=files, params=params)
    
    # Check if the request was successful
    if response.status_code == 200:
        # Parse the JSON response
        result = response.json()
        
        # Pretty print the JSON response
        print(f"Successfully extracted information using OCR method: {ocr_method}")
        print(json.dumps(result, indent=2))
        
        # Check if we got meaningful data
        applicant = result.get('applicant', {})
        if applicant and any(applicant.values()):
            print("\nApplicant information successfully extracted!")
        else:
            print("\nWarning: Applicant information is empty or incomplete.")
            
        # Check for spouse information
        spouse = result.get('spouse', {})
        if spouse and any(spouse.values()):
            print("Spouse information successfully extracted!")
            
        # Check for children information
        children = result.get('children', [])
        if children:
            print(f"Successfully extracted information for {len(children)} children!")
            
        # Check for enrollment information
        enrollment = result.get('enrollment', {})
        if enrollment and any(enrollment.values()):
            print("Enrollment information successfully extracted!")
    else:
        print(f"Error: API returned status code {response.status_code}")
        print(f"Response: {response.text}")
except Exception as e:
    print(f"Error: {str(e)}")
finally:
    # Close the file
    files['file'][1].close()
