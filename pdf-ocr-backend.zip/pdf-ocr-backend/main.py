from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
import os
from dotenv import load_dotenv
from typing import Optional
from enum import Enum

# Import our custom modules
from services.pdf_processor import PDFProcessor
from services.enhanced_pdf_processor import EnhancedPDFProcessor
from services.advanced_ocr_service import OCRMethod
from services.llm_service import LLMService
from models.response_models import ExtractedDataResponse
from utils.logging_utils import setup_logging
from utils.langsmith_utils import get_langsmith_callback_manager

# Load environment variables
load_dotenv()

# Configure logging
log_level = os.getenv("LOG_LEVEL", "INFO")
logger = setup_logging(log_level=log_level, app_name="pdf-ocr-backend")

# Initialize LangSmith tracing
langsmith_enabled = os.getenv("LANGCHAIN_API_KEY") is not None
if langsmith_enabled:
    project_name = os.getenv("LANGCHAIN_PROJECT", "pdf-ocr-backend")
    logger.info(f"LangSmith tracing enabled for project: {project_name}")
else:
    logger.info("LangSmith tracing disabled. Set LANGCHAIN_API_KEY to enable.")

# Initialize FastAPI app
app = FastAPI(
    title="PDF OCR and Information Extraction API",
    description="API for extracting information from PDF documents using OCR and Mistral LLM",
    version="1.0.0",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins in development
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Dependency to get LLM service
def get_llm_service():
    return LLMService()

# Dependency to get PDF processor
def get_pdf_processor(llm_service: LLMService = Depends(get_llm_service)):
    return PDFProcessor(llm_service)

# Dependency to get Enhanced PDF processor
def get_enhanced_pdf_processor(llm_service: LLMService = Depends(get_llm_service)):
    return EnhancedPDFProcessor(llm_service)

@app.get("/")
async def root():
    return {"message": "PDF OCR and Information Extraction API is running"}

class OCRMethodEnum(str, Enum):
    """Available OCR methods for the API"""
    LEGACY = "legacy"  # Original OCR implementation
    DONUT = "donut"    # Donut transformer model
    LAYOUT = "layout"  # LayoutParser
    COMBINED = "combined"  # Both Donut and LayoutParser

@app.post("/extract", response_model=ExtractedDataResponse)
async def extract_information(
    file: UploadFile = File(...),
    ocr_method: OCRMethodEnum = Query(OCRMethodEnum.COMBINED, description="OCR method to use"),
    pdf_processor: PDFProcessor = Depends(get_pdf_processor),
    enhanced_pdf_processor: EnhancedPDFProcessor = Depends(get_enhanced_pdf_processor)
):
    """
    Extract information from a PDF file.
    
    - **file**: PDF file to process
    - **ocr_method**: OCR method to use (legacy, donut, layout, combined)
    
    Returns:
    - Extracted applicant and child information from the dental and vision enrollment form
    """
    try:
        # Check if the file is a PDF
        if not file.filename.lower().endswith('.pdf'):
            logger.error("File is not a PDF")
            raise HTTPException(status_code=400, detail="Only PDF files are accepted")
        
        # Read the file content
        contents = await file.read()
        
        # Process the PDF based on the selected OCR method
        logger.info(f"Processing PDF: {file.filename} using OCR method: {ocr_method}")
        
        if ocr_method == OCRMethodEnum.LEGACY:
            # Use the original PDF processor
            extracted_data = await pdf_processor.process_pdf(contents)
        else:
            # Map API enum to internal OCR method
            method_mapping = {
                OCRMethodEnum.DONUT: OCRMethod.DONUT,
                OCRMethodEnum.LAYOUT: OCRMethod.LAYOUT,
                OCRMethodEnum.COMBINED: OCRMethod.COMBINED
            }
            internal_method = method_mapping[ocr_method]
            
            # Use the enhanced PDF processor with the selected method
            extracted_data = await enhanced_pdf_processor.process_pdf(contents, ocr_method=internal_method)
        
        # Log the extracted data for debugging
        logger.info(f"Extracted data from process pdf: {extracted_data}")
        
        return extracted_data
    
    except Exception as e:
        logger.error(f"Error processing PDF: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing PDF: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    langsmith_status = "enabled" if os.getenv("LANGCHAIN_API_KEY") else "disabled"
    return {
        "status": "healthy",
        "langsmith_tracing": langsmith_status,
        "project": os.getenv("LANGCHAIN_PROJECT", "pdf-ocr-backend")
    }

if __name__ == "__main__":
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", 8000))
    
    logger.info(f"Starting server on {host}:{port}")
    uvicorn.run("main:app", host=host, port=port, reload=True)
