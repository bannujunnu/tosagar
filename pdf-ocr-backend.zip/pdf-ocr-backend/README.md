# PDF OCR Backend Service

A FastAPI backend service that processes PDF files, performs OCR, and extracts information using Mistral LLM via Groq and LangChain.

## Features

- PDF file upload and processing
- Text extraction using direct PDF parsing and OCR
- Information extraction using Mistral LLM via Groq
- RESTful API with FastAPI
- CORS support for integration with frontend applications

## Prerequisites

- Python 3.8 or higher
- Tesseract OCR installed on your system
- Groq API key for accessing Mistral LLM

### Installing Tesseract OCR

#### Windows
1. Download the installer from [UB Mannheim](https://github.com/UB-Mannheim/tesseract/wiki)
2. Install and add the installation directory to your PATH environment variable

#### macOS
```bash
brew install tesseract
```

#### Linux
```bash
sudo apt update
sudo apt install tesseract-ocr
```

## Installation

1. Clone the repository or navigate to the project directory
2. Create a virtual environment:
   ```bash
   python -m venv venv
   ```
3. Activate the virtual environment:
   - Windows: `venv\Scripts\activate`
   - macOS/Linux: `source venv/bin/activate`
4. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Configuration

Create a `.env` file in the root directory with the following variables:

```
# API Keys
GROQ_API_KEY=your_groq_api_key_here

# Model Configuration
MISTRAL_MODEL_NAME=mistral-7b-instruct

# Server Configuration
HOST=0.0.0.0
PORT=8000
```

## Running the Application

Start the FastAPI server:

```bash
python main.py
```

Or using uvicorn directly:

```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

## API Endpoints

### Health Check
```
GET /health
```
Returns the health status of the API.

### Extract Information from PDF
```
POST /extract
```
Upload a PDF file and extract applicant and child information.

**Request:**
- Content-Type: multipart/form-data
- Body: file (PDF file)

**Response:**
```json
{
  "applicant_first_name": "string",
  "applicant_last_name": "string",
  "child_details": [
    {
      "name": "string",
      "age": "string",
      "dob": "string",
      "additional_info": "string"
    }
  ],
  "raw_text": "string"
}
```

## Integration with Frontend

This backend service is designed to work with the React frontend application. To integrate:

1. Ensure CORS is properly configured (already done in the code)
2. In your React application, make a POST request to the `/extract` endpoint with the PDF file
3. Process the JSON response to display the extracted information

Example frontend code:
```javascript
const handleFileUpload = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  
  try {
    const response = await fetch('http://localhost:8000/extract', {
      method: 'POST',
      body: formData,
    });
    
    const data = await response.json();
    // Process the extracted data
    console.log(data);
  } catch (error) {
    console.error('Error uploading file:', error);
  }
};
```

## License

MIT
