import re
import logging
from typing import Dict, Any, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

class FormFieldExtractor:
    """Utility class to help extract common form fields from OCR text"""
    
    @staticmethod
    def extract_name(text: str, prefix: str = "") -> Tuple[Optional[str], Optional[str]]:
        """
        Extract first and last name from text
        
        Args:
            text (str): OCR text
            prefix (str): Optional prefix to search for (e.g., "APPLICANT'S")
            
        Returns:
            Tuple[Optional[str], Optional[str]]: (last_name, first_name)
        """
        # Pattern for "LAST NAME: X, FIRST NAME: Y"
        pattern1 = rf"{prefix}\s*(?:LAST|LAST NAME)[:\s]+([A-Za-z\-']+)(?:.*?)(?:FIRST|FIRST NAME)[:\s]+([A-Za-z\-']+)"
        # Pattern for "NAME: X Y" (assuming last name first)
        pattern2 = rf"{prefix}\s*NAME[:\s]+([A-Za-z\-']+)\s+([A-Za-z\-']+)"
        
        match = re.search(pattern1, text, re.IGNORECASE)
        if match:
            return match.group(1).strip(), match.group(2).strip()
        
        match = re.search(pattern2, text, re.IGNORECASE)
        if match:
            return match.group(1).strip(), match.group(2).strip()
        
        return None, None
    
    @staticmethod
    def extract_ssn(text: str, context: str = "") -> Optional[str]:
        """
        Extract Social Security Number
        
        Args:
            text (str): OCR text
            context (str): Optional context to narrow search (e.g., "APPLICANT")
            
        Returns:
            Optional[str]: SSN if found, None otherwise
        """
        # Look for SSN pattern near the context
        if context:
            # Search within 200 chars of the context mention
            context_pos = text.upper().find(context.upper())
            if context_pos >= 0:
                search_text = text[max(0, context_pos - 100):min(len(text), context_pos + 300)]
            else:
                search_text = text
        else:
            search_text = text
        
        # Pattern for SSN: XXX-XX-XXXX or XXXXXXXXX
        patterns = [
            r"(?:SSN|SOCIAL SECURITY|SOCIAL SECURITY NUMBER)[:\s]+(\d{3}[\s\-]?\d{2}[\s\-]?\d{4})",
            r"(\d{3}[\s\-]\d{2}[\s\-]\d{4})"
        ]
        
        for pattern in patterns:
            match = re.search(pattern, search_text, re.IGNORECASE)
            if match:
                # Clean up the SSN format
                ssn = match.group(1).replace(" ", "").replace("-", "")
                if len(ssn) == 9 and ssn.isdigit():
                    return f"{ssn[:3]}-{ssn[3:5]}-{ssn[5:]}"
        
        return None
    
    @staticmethod
    def extract_date(text: str, context: str = "") -> Optional[str]:
        """
        Extract date in MM/DD/YYYY format
        
        Args:
            text (str): OCR text
            context (str): Optional context to narrow search (e.g., "DATE OF BIRTH")
            
        Returns:
            Optional[str]: Date in MM/DD/YYYY format if found, None otherwise
        """
        if context:
            # Search within 100 chars of the context mention
            context_pos = text.upper().find(context.upper())
            if context_pos >= 0:
                search_text = text[max(0, context_pos - 50):min(len(text), context_pos + 150)]
            else:
                search_text = text
        else:
            search_text = text
        
        # Pattern for dates: MM/DD/YYYY or MM-DD-YYYY
        patterns = [
            r"(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})",  # MM/DD/YYYY or MM-DD-YYYY
            r"(\d{1,2})\s+(\d{1,2})\s+(\d{2,4})"  # MM DD YYYY
        ]
        
        for pattern in patterns:
            matches = re.finditer(pattern, search_text)
            for match in matches:
                month, day, year = match.groups()
                
                # Validate month and day
                try:
                    month_int = int(month)
                    day_int = int(day)
                    year_int = int(year)
                    
                    if 1 <= month_int <= 12 and 1 <= day_int <= 31:
                        # Format year correctly
                        if year_int < 100:  # Two-digit year
                            if year_int < 50:  # Assume 20xx for years < 50
                                year_int += 2000
                            else:  # Assume 19xx for years >= 50
                                year_int += 1900
                        
                        # Return formatted date
                        return f"{month_int:02d}/{day_int:02d}/{year_int:04d}"
                except ValueError:
                    continue
        
        return None
    
    @staticmethod
    def extract_checkbox_value(text: str, option_text: str, proximity_chars: int = 100) -> bool:
        """
        Determine if a checkbox is checked based on OCR text
        
        Args:
            text (str): OCR text
            option_text (str): Text label of the checkbox option
            proximity_chars (int): Number of characters to search around the option text
            
        Returns:
            bool: True if checkbox appears to be checked, False otherwise
        """
        # Find the position of the option text
        option_pos = text.upper().find(option_text.upper())
        if option_pos < 0:
            return False
        
        # Search around the option text for indicators of a checked box
        search_text = text[max(0, option_pos - proximity_chars):min(len(text), option_pos + proximity_chars)]
        
        # Patterns that might indicate a checked box
        check_patterns = [
            r"[\[\(]X[\]\)]",  # [X] or (X)
            r"[\[\(]✓[\]\)]",  # [✓] or (✓)
            r"[\[\(]✗[\]\)]",  # [✗] or (✗)
            r"☑",  # Checked box Unicode
            r"☒",  # Checked box Unicode
            r"■",  # Filled square Unicode
            r"checked",  # Text indicating checked
            r"selected"  # Text indicating selected
        ]
        
        for pattern in check_patterns:
            if re.search(pattern, search_text, re.IGNORECASE):
                return True
        
        return False
    
    @staticmethod
    def extract_email(text: str) -> Optional[str]:
        """
        Extract email address from text
        
        Args:
            text (str): OCR text
            
        Returns:
            Optional[str]: Email address if found, None otherwise
        """
        # Pattern for email addresses
        email_pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
        
        match = re.search(email_pattern, text)
        if match:
            return match.group(0).lower()
        
        return None
    
    @staticmethod
    def extract_phone(text: str) -> Optional[str]:
        """
        Extract phone number from text
        
        Args:
            text (str): OCR text
            
        Returns:
            Optional[str]: Phone number if found, None otherwise
        """
        # Pattern for phone numbers
        phone_patterns = [
            r"(?:PHONE|TEL|TELEPHONE)[:\s]+(\d{3}[\s\-\.]?\d{3}[\s\-\.]?\d{4})",
            r"(\d{3}[\s\-\.]?\d{3}[\s\-\.]?\d{4})"
        ]
        
        for pattern in phone_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                # Clean up the phone format
                phone = re.sub(r"[^\d]", "", match.group(1))
                if len(phone) == 10:
                    return f"({phone[:3]}) {phone[3:6]}-{phone[6:]}"
        
        return None
    
    @staticmethod
    def extract_address(text: str) -> Dict[str, Optional[str]]:
        """
        Extract address components from text
        
        Args:
            text (str): OCR text
            
        Returns:
            Dict[str, Optional[str]]: Dictionary with address, city, state, zip_code
        """
        address_info = {
            "address": None,
            "city": None,
            "state": None,
            "zip_code": None
        }
        
        # Look for address section
        address_section_pattern = r"(?:ADDRESS|STREET)[:\s]+(.+?)(?:CITY|STATE|ZIP|$)"
        match = re.search(address_section_pattern, text, re.IGNORECASE | re.DOTALL)
        if match:
            address_info["address"] = match.group(1).strip()
        
        # Look for city
        city_pattern = r"CITY[:\s]+([A-Za-z\s\.]+)(?:,|STATE|ZIP|$)"
        match = re.search(city_pattern, text, re.IGNORECASE)
        if match:
            address_info["city"] = match.group(1).strip()
        
        # Look for state
        state_pattern = r"STATE[:\s]+([A-Z]{2})"
        match = re.search(state_pattern, text, re.IGNORECASE)
        if match:
            address_info["state"] = match.group(1).upper()
        
        # Look for ZIP code
        zip_pattern = r"ZIP(?:\s+CODE)?[:\s]+(\d{5}(?:-\d{4})?)"
        match = re.search(zip_pattern, text, re.IGNORECASE)
        if match:
            address_info["zip_code"] = match.group(1)
        
        return address_info
    
    @staticmethod
    def extract_enrollment_info(text: str) -> Dict[str, Any]:
        """
        Extract enrollment information from text
        
        Args:
            text (str): OCR text
            
        Returns:
            Dict[str, Any]: Dictionary with enrollment type, date, and plan options
        """
        enrollment_info = {
            "enrollment_type": None,
            "enrollment_date": None,
            "plan_options": {
                "dental": None,
                "vision": None,
                "unit": None
            }
        }
        
        # Extract enrollment type
        enrollment_patterns = [
            r"NEW\s+ENROLLMENT",
            r"CHANGE\s+REQUEST",
            r"ADD\s+DEPENDENT",
            r"REMOVE\s+DEPENDENT"
        ]
        
        for pattern in enrollment_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                enrollment_info["enrollment_type"] = re.search(pattern, text, re.IGNORECASE).group(0)
                break
        
        # Extract enrollment date
        date_pattern = r"DATE\s+OF\s+EVENT[:\s]+(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})"
        match = re.search(date_pattern, text, re.IGNORECASE)
        if match:
            month, day, year = match.groups()
            # Format year correctly
            year_int = int(year)
            if year_int < 100:  # Two-digit year
                if year_int < 50:  # Assume 20xx for years < 50
                    year_int += 2000
                else:  # Assume 19xx for years >= 50
                    year_int += 1900
            
            enrollment_info["enrollment_date"] = f"{int(month):02d}/{int(day):02d}/{year_int:04d}"
        
        # Extract dental plan options
        dental_plans = [
            "Horizon Family Grins",
            "Horizon Young Grins",
            "Horizon Family Grins Plus",
            "Horizon Healthy Smiles"
        ]
        
        for plan in dental_plans:
            if FormFieldExtractor.extract_checkbox_value(text, plan):
                enrollment_info["plan_options"]["dental"] = plan
                break
        
        # Extract vision plan options
        vision_plans = [
            "Horizon Panorama V",
            "Horizon Vista V"
        ]
        
        for plan in vision_plans:
            if FormFieldExtractor.extract_checkbox_value(text, plan):
                enrollment_info["plan_options"]["vision"] = plan
                break
        
        # Extract unit type
        unit_types = ["Single", "Family", "Two Adults", "Adult & Child(ren)"]
        
        for unit in unit_types:
            if FormFieldExtractor.extract_checkbox_value(text, unit):
                enrollment_info["plan_options"]["unit"] = unit
                break
        
        return enrollment_info
    
    @staticmethod
    def extract_children_info(text: str) -> List[Dict[str, Any]]:
        """
        Extract information about children from text
        
        Args:
            text (str): OCR text
            
        Returns:
            List[Dict[str, Any]]: List of dictionaries with child information
        """
        children = []
        
        # Look for child sections
        child_section_pattern = r"(?:CHILD|DEPENDENT\s+CHILD)(?:\s+\d+)?(?:[:\s]+|$)(.*?)(?:CHILD|DEPENDENT\s+CHILD|SPOUSE|PAYMENT|SIGNATURE|$)"
        child_sections = re.finditer(child_section_pattern, text, re.IGNORECASE | re.DOTALL)
        
        for match in child_sections:
            child_text = match.group(1)
            if not child_text or len(child_text.strip()) < 10:
                continue
            
            child_info = {}
            
            # Extract name
            last_name, first_name = FormFieldExtractor.extract_name(child_text)
            child_info["last_name"] = last_name
            child_info["first_name"] = first_name
            
            # Extract SSN
            child_info["ssn"] = FormFieldExtractor.extract_ssn(child_text)
            
            # Extract DOB
            child_info["dob"] = FormFieldExtractor.extract_date(child_text, "DATE OF BIRTH")
            
            # Extract sex
            if re.search(r"(?:SEX|GENDER)[:\s]+M", child_text, re.IGNORECASE) or re.search(r"\bM\b", child_text):
                child_info["sex"] = "M"
            elif re.search(r"(?:SEX|GENDER)[:\s]+F", child_text, re.IGNORECASE) or re.search(r"\bF\b", child_text):
                child_info["sex"] = "F"
            else:
                child_info["sex"] = None
            
            # Extract living with applicant
            child_info["living_with_applicant"] = FormFieldExtractor.extract_checkbox_value(child_text, "LIVING WITH APPLICANT") or FormFieldExtractor.extract_checkbox_value(child_text, "YES")
            
            # Only add if we have at least some valid information
            if child_info["first_name"] or child_info["last_name"] or child_info["dob"]:
                children.append(child_info)
        
        return children
    
    @staticmethod
    def extract_spouse_info(text: str) -> Dict[str, Any]:
        """
        Extract information about spouse/partner from text
        
        Args:
            text (str): OCR text
            
        Returns:
            Dict[str, Any]: Dictionary with spouse information
        """
        spouse_info = {
            "last_name": None,
            "first_name": None,
            "ssn": None,
            "dob": None,
            "sex": None,
            "same_address": None
        }
        
        # Look for spouse section
        spouse_section_pattern = r"(?:SPOUSE|CIVIL\s+UNION\s+PARTNER|DOMESTIC\s+PARTNER)(?:[:\s]+|$)(.*?)(?:CHILD|DEPENDENT\s+CHILD|PAYMENT|SIGNATURE|$)"
        match = re.search(spouse_section_pattern, text, re.IGNORECASE | re.DOTALL)
        
        if match:
            spouse_text = match.group(1)
            
            # Extract name
            last_name, first_name = FormFieldExtractor.extract_name(spouse_text)
            spouse_info["last_name"] = last_name
            spouse_info["first_name"] = first_name
            
            # Extract SSN
            spouse_info["ssn"] = FormFieldExtractor.extract_ssn(spouse_text)
            
            # Extract DOB
            spouse_info["dob"] = FormFieldExtractor.extract_date(spouse_text, "DATE OF BIRTH")
            
            # Extract sex
            if re.search(r"(?:SEX|GENDER)[:\s]+M", spouse_text, re.IGNORECASE) or re.search(r"\bM\b", spouse_text):
                spouse_info["sex"] = "M"
            elif re.search(r"(?:SEX|GENDER)[:\s]+F", spouse_text, re.IGNORECASE) or re.search(r"\bF\b", spouse_text):
                spouse_info["sex"] = "F"
            else:
                spouse_info["sex"] = None
            
            # Extract same address
            spouse_info["same_address"] = FormFieldExtractor.extract_checkbox_value(spouse_text, "SAME ADDRESS") or FormFieldExtractor.extract_checkbox_value(spouse_text, "YES")
        
        return spouse_info
    
    @staticmethod
    def extract_all_form_data(text: str) -> Dict[str, Any]:
        """
        Extract all form data from OCR text
        
        Args:
            text (str): OCR text
            
        Returns:
            Dict[str, Any]: Dictionary with all extracted form data
        """
        result = {
            "applicant": {},
            "enrollment": {},
            "spouse": {},
            "children": []
        }
        
        # Extract applicant information
        last_name, first_name = FormFieldExtractor.extract_name(text, "APPLICANT")
        result["applicant"]["last_name"] = last_name
        result["applicant"]["first_name"] = first_name
        result["applicant"]["ssn"] = FormFieldExtractor.extract_ssn(text, "APPLICANT")
        result["applicant"]["dob"] = FormFieldExtractor.extract_date(text, "DATE OF BIRTH")
        
        # Extract sex
        if re.search(r"(?:SEX|GENDER)[:\s]+M", text, re.IGNORECASE) or re.search(r"\bM\b", text):
            result["applicant"]["sex"] = "M"
        elif re.search(r"(?:SEX|GENDER)[:\s]+F", text, re.IGNORECASE) or re.search(r"\bF\b", text):
            result["applicant"]["sex"] = "F"
        else:
            result["applicant"]["sex"] = None
        
        # Extract email
        result["applicant"]["email"] = FormFieldExtractor.extract_email(text)
        
        # Extract address
        address_info = FormFieldExtractor.extract_address(text)
        result["applicant"].update(address_info)
        
        # Extract phone
        result["applicant"]["phone"] = FormFieldExtractor.extract_phone(text)
        
        # Extract NJ resident status
        result["applicant"]["nj_resident"] = FormFieldExtractor.extract_checkbox_value(text, "RESIDENT OF NEW JERSEY") or FormFieldExtractor.extract_checkbox_value(text, "YES")
        
        # Extract enrollment information
        result["enrollment"] = FormFieldExtractor.extract_enrollment_info(text)
        
        # Extract spouse information
        result["spouse"] = FormFieldExtractor.extract_spouse_info(text)
        
        # Extract children information
        result["children"] = FormFieldExtractor.extract_children_info(text)
        
        return result
