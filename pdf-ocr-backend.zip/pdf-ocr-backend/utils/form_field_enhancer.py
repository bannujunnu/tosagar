"""
Form field enhancement utilities for better OCR on structured forms.
"""
import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import pytesseract
from typing import List, Dict, Any, Tuple, Optional
import os
import logging

# Configure logging
logger = logging.getLogger(__name__)

class FormFieldEnhancer:
    """Utility class for enhancing form fields for better OCR extraction"""
    
    @staticmethod
    def preprocess_form_image(image: Image.Image) -> np.ndarray:
        """
        Preprocess the form image to improve form field detection
        
        Args:
            image: PIL Image object
            
        Returns:
            numpy array: Preprocessed image
        """
        # Convert PIL image to OpenCV format
        img = np.array(image)
        if len(img.shape) == 3 and img.shape[2] == 3:
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        
        # Convert to grayscale if not already
        if len(img.shape) == 3:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        else:
            gray = img
            
        # Apply bilateral filter to reduce noise while preserving edges
        filtered = cv2.bilateralFilter(gray, 11, 17, 17)
        
        # Apply CLAHE (Contrast Limited Adaptive Histogram Equalization) to improve contrast
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        clahe_img = clahe.apply(filtered)
        
        # Apply adaptive thresholding to better separate text from background
        # This is especially helpful for handwritten content
        thresh = cv2.adaptiveThreshold(
            clahe_img, 
            255, 
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
            cv2.THRESH_BINARY_INV, 
            11, 
            2
        )
        
        # Apply morphological operations to enhance text
        # Perform morphological operations to clean up the image
        kernel = np.ones((2, 2), np.uint8)
        morph = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
        
        # Dilate to make handwritten text more prominent
        dilation_kernel = np.ones((2, 2), np.uint8)
        dilated = cv2.dilate(morph, dilation_kernel, iterations=1)
        
        # Invert back to get black text on white background
        morph = cv2.bitwise_not(dilated)
        
        # Convert back to PIL image
        enhanced_img = Image.fromarray(cv2.cvtColor(morph, cv2.COLOR_GRAY2RGB))
        
        # Apply additional PIL enhancements
        enhancer = ImageEnhance.Contrast(enhanced_img)
        enhanced_img = enhancer.enhance(2.5)  # Increased contrast for handwritten text
        
        # Apply sharpening
        enhanced_img = enhanced_img.filter(ImageFilter.SHARPEN)
        
        return enhanced_img
    
    @staticmethod
    def detect_form_fields(image: Image.Image) -> List[Dict[str, Any]]:
        """
        Detect form fields (boxes, tables, etc.) in the image
        
        Args:
            image: PIL Image object
            
        Returns:
            List of detected form fields with coordinates
        """
        # Convert PIL image to OpenCV format
        img_cv = np.array(image.convert('RGB'))
        img_cv = cv2.cvtColor(img_cv, cv2.COLOR_RGB2BGR)
        
        # Convert to grayscale
        gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)
        
        # Apply bilateral filter to reduce noise while preserving edges
        filtered = cv2.bilateralFilter(gray, 11, 17, 17)
        
        # Apply CLAHE for better contrast
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        clahe_img = clahe.apply(filtered)
        
        # Apply Canny edge detection
        edges = cv2.Canny(clahe_img, 50, 150)
        
        # Dilate edges to connect nearby edges
        dilated_edges = cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=1)
        
        # Find contours using different methods to maximize field detection
        contours1, _ = cv2.findContours(dilated_edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Also try adaptive thresholding for better form field detection
        adaptive_thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                              cv2.THRESH_BINARY_INV, 11, 2)
        contours2, _ = cv2.findContours(adaptive_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Combine contours from both methods
        all_contours = list(contours1) + list(contours2)
        
        form_fields = []
        for contour in all_contours:
            # Get bounding rectangle
            x, y, w, h = cv2.boundingRect(contour)
            
            # Filter out very small contours (noise) and very large contours (entire page)
            if w > 20 and h > 10 and w < img_cv.shape[1] * 0.9 and h < img_cv.shape[0] * 0.9:
                # Check if it's likely a form field (box)
                # Form fields typically have a certain aspect ratio
                aspect_ratio = float(w) / h
                if 0.5 < aspect_ratio < 20:  # Expanded range for form field aspect ratios
                    # Check if this is a new field or overlaps with existing fields
                    new_field = True
                    for field in form_fields:
                        # Check for significant overlap
                        overlap_x = max(0, min(field['x'] + field['width'], x + w) - max(field['x'], x))
                        overlap_y = max(0, min(field['y'] + field['height'], y + h) - max(field['y'], y))
                        overlap_area = overlap_x * overlap_y
                        min_area = min(field['area'], w * h)
                        
                        if overlap_area > 0.7 * min_area:  # If 70% overlap, consider it the same field
                            new_field = False
                            break
                    
                    if new_field:
                        form_fields.append({
                            'x': x,
                            'y': y,
                            'width': w,
                            'height': h,
                            'area': w * h
                        })
        
        # Special handling for form fields arranged in a grid (like checkboxes or text boxes)
        # Sort fields by y-coordinate to group rows
        form_fields.sort(key=lambda f: f['y'])
        
        # Group fields that are likely in the same row (similar y-coordinate)
        row_groups = []
        current_row = [form_fields[0]] if form_fields else []
        
        for i in range(1, len(form_fields)):
            current_field = form_fields[i]
            prev_field = form_fields[i-1]
            
            # If y-coordinate is close to previous field, add to current row
            if abs(current_field['y'] - prev_field['y']) < 20:  # Adjust threshold as needed
                current_row.append(current_field)
            else:
                # Start a new row
                if current_row:
                    row_groups.append(current_row)
                current_row = [current_field]
        
        # Add the last row if not empty
        if current_row:
            row_groups.append(current_row)
        
        # For each row, sort fields by x-coordinate to get left-to-right order
        for row in row_groups:
            row.sort(key=lambda f: f['x'])
        
        # Flatten the grouped fields back into a single list
        form_fields = [field for row in row_groups for field in row]
        
        return form_fields
    
    @staticmethod
    def extract_text_from_form_fields(
        image: Image.Image, 
        form_fields: List[Dict[str, Any]]
    ) -> Dict[str, str]:
        """
        Extract text from detected form fields with specialized settings for handwritten text
        
        Args:
            image: PIL Image object
            form_fields: List of form field coordinates
            
        Returns:
            Dictionary mapping field positions to extracted text
        """
        results = {}
        
        # Sort form fields by position (top to bottom, left to right)
        sorted_fields = sorted(form_fields, key=lambda f: (f['y'], f['x']))
        
        for i, field in enumerate(sorted_fields):
            # Extract the region of interest
            x, y, w, h = field['x'], field['y'], field['width'], field['height']
            field_img = image.crop((x, y, x + w, y + h))
            
            # Enhance the field image
            field_img = FormFieldEnhancer.enhance_field_image(field_img)
            
            # Try multiple OCR configurations and combine results
            # Configuration 1: Optimized for handwritten text with relaxed constraints
            handwritten_config = '--oem 3 --psm 6 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789/\-@.,:;()&# -c preserve_interword_spaces=1 -c textord_min_linesize=2.5'
            text1 = pytesseract.image_to_string(field_img, config=handwritten_config).strip()
            
            # Configuration 2: Single character mode (for fields with individual characters)
            single_char_config = '--oem 3 --psm 10 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789/\-@.,:;()&#'
            text2 = "".join([c for c in pytesseract.image_to_string(field_img, config=single_char_config) if c.isalnum() or c in "/\-@.,:;()&# "])
            
            # Configuration 3: Single word mode with relaxed constraints
            single_word_config = '--oem 3 --psm 8 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789/\-@.,:;()&# -c textord_min_linesize=2.5'
            text3 = pytesseract.image_to_string(field_img, config=single_word_config).strip()
            
            # Configuration 4: Sparse text with OSD (orientation and script detection)
            sparse_text_config = '--oem 3 --psm 11 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789/\-@.,:;()&#'
            text4 = pytesseract.image_to_string(field_img, config=sparse_text_config).strip()
            
            # Choose the best result based on length and content
            candidates = [text1, text2, text3, text4]
            # Prefer non-empty results
            non_empty = [t for t in candidates if t]
            
            if non_empty:
                # Choose the result with the most alphanumeric characters
                text = max(non_empty, key=lambda t: sum(c.isalnum() for c in t))
            else:
                text = ""
            
            # Store the result
            field_key = f"field_{i}_{x}_{y}"
            results[field_key] = text
            
            # Add special handling for fields that might contain names, dates, or SSNs
            # Check if the field might contain a date (MM/DD/YYYY format)
            if w > 50 and 20 < h < 50:  # Typical size for date fields
                date_config = '--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789/'
                date_text = pytesseract.image_to_string(field_img, config=date_config).strip()
                if date_text and '/' in date_text:
                    results[f"{field_key}_date"] = date_text
            
            # Check if the field might contain a name (wider fields)
            if w > 100 and 20 < h < 50:  # Typical size for name fields
                name_config = '--oem 3 --psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz '
                name_text = pytesseract.image_to_string(field_img, config=name_config).strip()
                if name_text and len(name_text) > 2:
                    results[f"{field_key}_name"] = name_text
        
        return results
    
    @staticmethod
    def enhance_field_image(field_img: Image.Image) -> Image.Image:
        """
        Apply specific enhancements for form field images with handwritten text
        
        Args:
            field_img: PIL Image of a form field
            
        Returns:
            Enhanced PIL Image
        """
        # Resize for better OCR if the field is small
        width, height = field_img.size
        if width < 150 or height < 40:  # Increased minimum size for better handwriting recognition
            scale_factor = max(150 / width, 40 / height)
            new_size = (int(width * scale_factor), int(height * scale_factor))
            field_img = field_img.resize(new_size, Image.Resampling.LANCZOS)
        
        # Convert to numpy array for OpenCV processing
        img_np = np.array(field_img)
        
        # Check if image is already grayscale
        if len(img_np.shape) == 3 and img_np.shape[2] == 3:
            # Convert to grayscale
            img_gray = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)
        else:
            img_gray = img_np
        
        # Apply CLAHE for better contrast
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        img_clahe = clahe.apply(img_gray)
        
        # Apply bilateral filter to reduce noise while preserving edges
        img_filtered = cv2.bilateralFilter(img_clahe, 9, 75, 75)
        
        # Apply adaptive thresholding optimized for handwritten text
        img_thresh = cv2.adaptiveThreshold(
            img_filtered, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV, 15, 8
        )
        
        # Dilate to make handwritten text more prominent
        kernel = np.ones((2, 2), np.uint8)
        img_dilated = cv2.dilate(img_thresh, kernel, iterations=1)
        
        # Invert back to get black text on white background
        img_inverted = cv2.bitwise_not(img_dilated)
        
        # Convert back to PIL image
        enhanced_img = Image.fromarray(img_inverted)
        
        return enhanced_img
    
    @staticmethod
    def process_form_image(image_path: str) -> Tuple[str, Dict[str, str]]:
        """
        Process a form image to extract text with enhanced form field detection
        
        Args:
            image_path: Path to the form image
            
        Returns:
            Tuple of (general OCR text, form field specific text)
        """
        try:
            # Open the image
            with Image.open(image_path) as img:
                # Make a copy to avoid modifying the original
                image = img.copy()
                
                # Get general OCR text
                general_text = pytesseract.image_to_string(image)
                
                # Preprocess the image for form field detection
                enhanced_img = FormFieldEnhancer.preprocess_form_image(image)
                
                # Detect form fields
                form_fields = FormFieldEnhancer.detect_form_fields(enhanced_img)
                
                # Extract text from form fields
                field_text = FormFieldEnhancer.extract_text_from_form_fields(enhanced_img, form_fields)
                
                return general_text, field_text
                
        except Exception as e:
            logger.error(f"Error processing form image: {str(e)}")
            return "", {}
