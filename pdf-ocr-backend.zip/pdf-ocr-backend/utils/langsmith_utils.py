"""
LangSmith utilities for tracing and monitoring LangChain runs.
"""
import os
from typing import Optional
from langsmith import Client
from langchain.callbacks.tracers.langchain import LangChainTracer
from langchain.callbacks.manager import CallbackManager
from utils.logging_utils import get_logger

# Configure logging
logger = get_logger(__name__)

def get_langsmith_callback_manager(
    project_name: Optional[str] = None,
    tags: Optional[list] = None
) -> CallbackManager:
    """
    Create a callback manager with LangSmith tracing enabled.
    
    Args:
        project_name: Optional name for the LangSmith project
        tags: Optional list of tags to apply to the trace
        
    Returns:
        CallbackManager with LangSmith tracing
    """
    try:
        # Check if LangSmith is configured
        api_key = os.getenv("LANGSMITH_API_KEY")
        api_url = os.getenv("LANGCHAIN_ENDPOINT", "https://api.smith.langchain.com")
        
        if not api_key:
            logger.warning("LANGSMITH_API_KEY not found in environment. LangSmith tracing disabled.")
            return None
        
        # Set default project name if not provided
        if not project_name:
            project_name = os.getenv("LANGSMITH_PROJECT", "pdf-ocr-backend")
        
        # Create LangSmith client
        client = Client(
            api_key=api_key,
            api_url=api_url
        )
        
        # Create tracer
        tracer = LangChainTracer(
            project_name=project_name,
            client=client,
            tags=tags or []
        )
        
        # Create callback manager
        callback_manager = CallbackManager([tracer])
        
        logger.info(f"LangSmith tracing enabled for project: {project_name}")
        return callback_manager
    
    except Exception as e:
        logger.error(f"Failed to initialize LangSmith tracing: {str(e)}")
        return None
