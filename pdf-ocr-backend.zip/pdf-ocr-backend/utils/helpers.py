import logging
import json
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

def format_json_response(data: Dict[str, Any]) -> str:
    """
    Format dictionary as a pretty-printed JSON string
    
    Args:
        data (Dict[str, Any]): Data to format
        
    Returns:
        str: Pretty-printed JSON string
    """
    try:
        return json.dumps(data, indent=2)
    except Exception as e:
        logger.error(f"Error formatting JSON: {str(e)}")
        return "{}"

def parse_json_string(json_str: str) -> Optional[Dict[str, Any]]:
    """
    Parse a JSON string into a dictionary
    
    Args:
        json_str (str): JSON string to parse
        
    Returns:
        Optional[Dict[str, Any]]: Parsed dictionary or None if parsing fails
    """
    try:
        # Handle the case where the JSON might be wrapped in markdown code blocks
        if "```json" in json_str:
            json_str = json_str.split("```json")[1].split("```")[0].strip()
        elif "```" in json_str:
            json_str = json_str.split("```")[1].split("```")[0].strip()
        
        return json.loads(json_str)
    except Exception as e:
        logger.error(f"Error parsing JSON string: {str(e)}")
        return None
