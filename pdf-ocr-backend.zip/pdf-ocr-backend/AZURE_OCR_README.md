# Azure AI Document Intelligence OCR Processor

This component provides OCR processing for PDF documents using Azure AI Document Intelligence. It extracts text, tables, key-value pairs, and entities from PDF documents and returns the results in a structured JSON format.

## Setup

1. Update the `.env` file with your Azure Document Intelligence credentials:
   ```
   AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=your_document_intelligence_endpoint
   AZURE_DOCUMENT_INTELLIGENCE_KEY=your_document_intelligence_key
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Components

### 1. Azure Document Intelligence Service

The core service that interacts with Azure AI Document Intelligence API.

- File: `services/azure_document_intelligence.py`
- Features:
  - PDF document processing
  - Text extraction
  - Table extraction
  - Key-value pair extraction
  - Entity extraction

### 2. Command-line Processor

A command-line tool for processing PDF documents.

- File: `azure_ocr_processor.py`
- Usage:
  ```
  python azure_ocr_processor.py --input sample.pdf --output result.json --model prebuilt-document
  ```
- Options:
  - `--input, -i`: Path to the input PDF file (required)
  - `--output, -o`: Path to the output JSON file (optional)
  - `--model, -m`: Azure Document Intelligence model to use (default: prebuilt-document)

### 3. REST API

A FastAPI-based web service for processing PDF documents.

- File: `azure_ocr_api.py`
- Start the server:
  ```
  uvicorn azure_ocr_api:app --host 0.0.0.0 --port 8001
  ```
- Endpoints:
  - `POST /process-pdf`: Process a PDF document
  - `POST /analyze-form`: Analyze a form document (optimized for form field extraction)

### 4. Client Application

A client application for interacting with the OCR API.

- File: `azure_ocr_client.py`
- Usage:
  ```
  python azure_ocr_client.py --file sample.pdf --model prebuilt-document
  ```
- Options:
  - `--file, -f`: Path to the PDF file to process (required)
  - `--model, -m`: Azure Document Intelligence model to use (default: prebuilt-document)
  - `--url, -u`: URL of the OCR Processor API (default: http://localhost:8001/process-pdf)
  - `--output, -o`: Path to save the JSON output (optional)
  - `--verbose, -v`: Display detailed output

## Available Models

Azure Document Intelligence provides several pre-built models:

- `prebuilt-layout`: General document layout analysis
- `prebuilt-document`: General document analysis
- `prebuilt-read`: Text reading
- `prebuilt-invoice`: Invoice analysis
- `prebuilt-receipt`: Receipt analysis
- `prebuilt-idDocument`: ID document analysis
- `prebuilt-tax.us.w2`: US W2 tax form analysis

Choose the appropriate model based on your document type for best results.

## Example Workflow

1. Start the API server:
   ```
   uvicorn azure_ocr_api:app --host 0.0.0.0 --port 8001
   ```

2. Process a PDF using the client:
   ```
   python azure_ocr_client.py --file sample.pdf --model prebuilt-document
   ```

3. View the results in the console or save them to a JSON file:
   ```
   python azure_ocr_client.py --file sample.pdf --output result.json
   ```

## Integration with Existing Systems

This OCR processor can be integrated with existing systems by:

1. Using the REST API to process documents
2. Using the Azure Document Intelligence service directly in your code
3. Using the command-line processor in your scripts
