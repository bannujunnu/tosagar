"""
Azure Document Intelligence OCR Processor

This script processes PDF documents using Azure AI Document Intelligence,
extracts text and form fields, and outputs the results in JSON format.

Usage:
    python azure_ocr_processor.py --input <pdf_path> --output <output_path> --model <model_name>

Example:
    python azure_ocr_processor.py --input sample.pdf --output result.json --model prebuilt-document
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path

from services.azure_document_intelligence import AzureDocumentIntelligenceService
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(os.path.join('logs', 'azure_ocr.log'), mode='a')
    ]
)
logger = logging.getLogger(__name__)

# Ensure logs directory exists
os.makedirs('logs', exist_ok=True)

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Process PDF documents using Azure AI Document Intelligence')
    
    parser.add_argument('--input', '-i', required=True, help='Path to the input PDF file')
    parser.add_argument('--output', '-o', help='Path to the output JSON file (default: <input_filename>.json)')
    parser.add_argument('--model', '-m', default='prebuilt-document',
                        choices=['prebuilt-layout', 'prebuilt-document', 'prebuilt-read', 
                                'prebuilt-invoice', 'prebuilt-receipt', 'prebuilt-idDocument',
                                'prebuilt-tax.us.w2'],
                        help='Azure Document Intelligence model to use (default: prebuilt-document)')
    
    return parser.parse_args()

def main():
    """Main function to process PDF documents."""
    # Load environment variables
    load_dotenv()
    
    # Parse command line arguments
    args = parse_arguments()
    
    # Validate input file
    input_path = Path(args.input)
    if not input_path.exists():
        logger.error(f"Input file not found: {input_path}")
        sys.exit(1)
    
    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        output_path = input_path.with_suffix('.json')
    
    # Create output directory if it doesn't exist
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    try:
        # Initialize the Azure Document Intelligence service
        logger.info("Initializing Azure Document Intelligence service")
        azure_service = AzureDocumentIntelligenceService()
        
        # Process the PDF
        logger.info(f"Processing PDF: {input_path} with model: {args.model}")
        result = azure_service.process_pdf(str(input_path), args.model)
        
        # Write the results to the output file
        logger.info(f"Writing results to: {output_path}")
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        
        logger.info("Processing completed successfully")
        print(f"Results saved to: {output_path}")
        
        # Print a sample of the results
        print("\nSample of extracted content:")
        if result['content'] and len(result['content']) > 0:
            first_page = result['content'][0]
            print(f"Page 1 text: {first_page['text'][:200]}...")
        
        print("\nExtracted key-value pairs:")
        for kv in result['key_value_pairs'][:5]:  # Show first 5 key-value pairs
            print(f"{kv['key']}: {kv['value']}")
        
    except Exception as e:
        logger.error(f"Error processing PDF: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
