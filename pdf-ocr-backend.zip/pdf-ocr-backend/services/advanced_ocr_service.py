import io
import os
import time
import asyncio
from typing import Dict, Any, List, Optional, Tuple, Union
import json
import re
from enum import Enum
from utils.logging_utils import get_logger

# Import our OCR implementations
from services.donut_ocr import DonutOCR
from services.layout_parser_ocr import LayoutParserOCR

# Configure logging
logger = get_logger(__name__)

class OCRMethod(str, Enum):
    """Enum for available OCR methods"""
    DONUT = "donut"
    LAYOUT_PARSER = "layout_parser"
    COMBINED = "combined"  # Uses both methods and combines results

class AdvancedOCRService:
    """
    Advanced OCR service that combines multiple OCR approaches.
    This service can use Donut, LayoutParser, or both to extract text and structured data from documents.
    """
    
    def __init__(self, default_method: OCRMethod = OCRMethod.COMBINED):
        """
        Initialize the Advanced OCR service.
        
        Args:
            default_method (OCRMethod): Default OCR method to use
        """
        self.default_method = default_method
        self._donut_ocr = None  # Lazy initialization
        self._layout_parser_ocr = None  # Lazy initialization
        logger.info(f"Advanced OCR Service initialized with default method: {default_method}")
    
    @property
    def donut_ocr(self) -> DonutOCR:
        """Lazy initialization of Donut OCR"""
        if self._donut_ocr is None:
            logger.info("Initializing Donut OCR on first use")
            self._donut_ocr = DonutOCR()
        return self._donut_ocr
    
    @property
    def layout_parser_ocr(self) -> LayoutParserOCR:
        """Lazy initialization of LayoutParser OCR"""
        if self._layout_parser_ocr is None:
            logger.info("Initializing LayoutParser OCR on first use")
            self._layout_parser_ocr = LayoutParserOCR()
        return self._layout_parser_ocr
    
    async def extract_text(self, pdf_bytes: bytes, method: Optional[OCRMethod] = None) -> str:
        """
        Extract text from a PDF document using the specified OCR method.
        
        Args:
            pdf_bytes (bytes): PDF file content
            method (Optional[OCRMethod]): OCR method to use, defaults to self.default_method
            
        Returns:
            str: Extracted text
        """
        method = method or self.default_method
        start_time = time.time()
        logger.info(f"Starting text extraction using method: {method}")
        
        try:
            if method == OCRMethod.DONUT:
                text = await self.donut_ocr.process_document(pdf_bytes)
            elif method == OCRMethod.LAYOUT_PARSER:
                text = await self.layout_parser_ocr.process_document(pdf_bytes)
            elif method == OCRMethod.COMBINED:
                # Run both methods concurrently
                donut_task = asyncio.create_task(self.donut_ocr.process_document(pdf_bytes))
                layout_task = asyncio.create_task(self.layout_parser_ocr.process_document(pdf_bytes))
                
                # Wait for both to complete
                donut_text, layout_text = await asyncio.gather(donut_task, layout_task)
                
                # Combine results
                text = self._combine_text_results(donut_text, layout_text)
            else:
                raise ValueError(f"Unknown OCR method: {method}")
            
            extraction_time = time.time() - start_time
            logger.info(f"Text extraction completed in {extraction_time:.2f} seconds")
            
            return text
        
        except Exception as e:
            logger.error(f"Error in text extraction: {str(e)}")
            return f"ERROR IN TEXT EXTRACTION: {str(e)}"
    
    def _combine_text_results(self, donut_text: str, layout_text: str) -> str:
        """
        Combine text results from multiple OCR methods.
        
        Args:
            donut_text (str): Text extracted by Donut
            layout_text (str): Text extracted by LayoutParser
            
        Returns:
            str: Combined text
        """
        # This is a simple combination strategy - in practice, you might want something more sophisticated
        combined = "COMBINED OCR RESULTS\n\n"
        
        # Add Donut results
        combined += "=== DONUT OCR RESULTS ===\n"
        combined += donut_text
        combined += "\n\n"
        
        # Add LayoutParser results
        combined += "=== LAYOUT PARSER OCR RESULTS ===\n"
        combined += layout_text
        
        return combined
    
    async def extract_form_fields(self, pdf_bytes: bytes, method: Optional[OCRMethod] = None) -> Dict[str, Any]:
        """
        Extract structured form fields from a PDF document.
        
        Args:
            pdf_bytes (bytes): PDF file content
            method (Optional[OCRMethod]): OCR method to use, defaults to self.default_method
            
        Returns:
            Dict[str, Any]: Structured form data
        """
        method = method or self.default_method
        start_time = time.time()
        logger.info(f"Starting form field extraction using method: {method}")
        
        try:
            if method == OCRMethod.DONUT:
                form_data = await self.donut_ocr.extract_form_fields(pdf_bytes)
            elif method == OCRMethod.LAYOUT_PARSER:
                form_data = await self.layout_parser_ocr.extract_form_fields(pdf_bytes)
            elif method == OCRMethod.COMBINED:
                # Run both methods concurrently
                donut_task = asyncio.create_task(self.donut_ocr.extract_form_fields(pdf_bytes))
                layout_task = asyncio.create_task(self.layout_parser_ocr.extract_form_fields(pdf_bytes))
                
                # Wait for both to complete
                donut_data, layout_data = await asyncio.gather(donut_task, layout_task)
                
                # Merge the results
                form_data = self._merge_form_data(donut_data, layout_data)
            else:
                raise ValueError(f"Unknown OCR method: {method}")
            
            extraction_time = time.time() - start_time
            logger.info(f"Form field extraction completed in {extraction_time:.2f} seconds using {method}")
            
            return form_data
        
        except Exception as e:
            logger.error(f"Error in form field extraction: {str(e)}")
            # Return empty structure on error
            return {
                "applicant": {},
                "enrollment": {},
                "spouse": {},
                "children": []
            }
    
    def _merge_form_data(self, donut_data: Dict[str, Any], layout_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge form data from multiple OCR methods.
        
        Args:
            donut_data (Dict[str, Any]): Form data extracted by Donut
            layout_data (Dict[str, Any]): Form data extracted by LayoutParser
            
        Returns:
            Dict[str, Any]: Merged form data
        """
        # Initialize merged data structure
        merged = {
            "applicant": {},
            "enrollment": {},
            "spouse": {},
            "children": []
        }
        
        # Helper function to merge dictionaries
        def merge_dicts(dict1, dict2):
            result = {}
            # Get all keys from both dictionaries
            all_keys = set(dict1.keys()) | set(dict2.keys())
            
            for key in all_keys:
                # Get values from both dictionaries (None if key doesn't exist)
                val1 = dict1.get(key)
                val2 = dict2.get(key)
                
                # If both values exist
                if val1 is not None and val2 is not None:
                    # For nested dictionaries, recursively merge
                    if isinstance(val1, dict) and isinstance(val2, dict):
                        result[key] = merge_dicts(val1, val2)
                    else:
                        # Prefer non-None values
                        result[key] = val1 if val1 is not None else val2
                elif val1 is not None:
                    result[key] = val1
                elif val2 is not None:
                    result[key] = val2
                else:
                    result[key] = None
            
            return result
        
        # Merge applicant information
        merged["applicant"] = merge_dicts(
            donut_data.get("applicant", {}),
            layout_data.get("applicant", {})
        )
        
        # Merge enrollment information
        merged["enrollment"] = merge_dicts(
            donut_data.get("enrollment", {}),
            layout_data.get("enrollment", {})
        )
        
        # Merge spouse information
        merged["spouse"] = merge_dicts(
            donut_data.get("spouse", {}),
            layout_data.get("spouse", {})
        )
        
        # Merge children information
        donut_children = donut_data.get("children", [])
        layout_children = layout_data.get("children", [])
        
        # Add all children from both sources (deduplication would be more complex)
        merged["children"] = donut_children + layout_children
        
        return merged
    
    async def process_pdf(self, pdf_bytes: bytes, method: Optional[OCRMethod] = None) -> Dict[str, Any]:
        """
        Process a PDF document: extract text and structured form data.
        
        Args:
            pdf_bytes (bytes): PDF file content
            method (Optional[OCRMethod]): OCR method to use, defaults to self.default_method
            
        Returns:
            Dict[str, Any]: Processing results with extracted text and form data
        """
        method = method or self.default_method
        start_time = time.time()
        logger.info(f"Starting PDF processing using method: {method}")
        
        try:
            # Extract text and form fields concurrently
            text_task = asyncio.create_task(self.extract_text(pdf_bytes, method))
            form_task = asyncio.create_task(self.extract_form_fields(pdf_bytes, method))
            
            # Wait for both to complete
            text, form_data = await asyncio.gather(text_task, form_task)
            
            # Prepare result
            result = {
                "text": text,
                "form_data": form_data,
                "processing_time": time.time() - start_time
            }
            
            logger.info(f"PDF processing completed in {result['processing_time']:.2f} seconds")
            
            return result
        
        except Exception as e:
            logger.error(f"Error in PDF processing: {str(e)}")
            return {
                "text": f"ERROR IN PDF PROCESSING: {str(e)}",
                "form_data": {
                    "applicant": {},
                    "enrollment": {},
                    "spouse": {},
                    "children": []
                },
                "processing_time": time.time() - start_time
            }
