import io
import os
import time
from typing import Dict, Any, List, Optional, Tuple
import tempfile
from pathlib import Path
import numpy as np
import cv2
from PIL import Image
import layoutparser as lp
import pytesseract
import camelot
import pandas as pd
from utils.logging_utils import get_logger

# Configure logging
logger = get_logger(__name__)

class LayoutParserOCR:
    """
    LayoutParser OCR implementation for document understanding.
    Uses a combination of layout detection and OCR to extract text and structure from documents.
    """
    
    def __init__(self, model_path: Optional[str] = None):
        """
        Initialize the LayoutParser OCR processor.
        
        Args:
            model_path (Optional[str]): Path to a custom layout detection model
        """
        logger.info("Initializing LayoutParser OCR")
        
        try:
            # Initialize the layout detection model
            if model_path and os.path.exists(model_path):
                logger.info(f"Loading custom layout model from {model_path}")
                self.model = lp.Detectron2LayoutModel(model_path=model_path)
            else:
                logger.info("Loading pre-trained PubLayNet model")
                self.model = lp.Detectron2LayoutModel(
                    'lp://PubLayNet/mask_rcnn_X_101_32x8d_FPN_3x/config',
                    extra_config=["MODEL.ROI_HEADS.SCORE_THRESH_TEST", 0.8],
                    label_map={
                        0: "Text",
                        1: "Title",
                        2: "List",
                        3: "Table",
                        4: "Figure"
                    }
                )
            
            # Initialize OCR engine
            logger.info("OCR engine initialized")
            
        except Exception as e:
            logger.error(f"Error initializing LayoutParser: {str(e)}")
            raise
    
    async def process_document(self, pdf_bytes: bytes) -> str:
        """
        Process a PDF document using LayoutParser and OCR.
        
        Args:
            pdf_bytes (bytes): PDF file content
            
        Returns:
            str: Extracted text with layout information
        """
        start_time = time.time()
        logger.info("Starting LayoutParser document processing")
        
        try:
            # Convert PDF to images
            images = self._convert_pdf_to_images(pdf_bytes)
            if not images:
                logger.error("Failed to convert PDF to images")
                return "FAILED TO EXTRACT IMAGES FROM PDF"
            
            # Process each image with LayoutParser
            results = []
            for i, image in enumerate(images):
                logger.info(f"Processing page {i+1} with LayoutParser")
                page_result = self._process_image(image)
                results.append(f"PAGE {i+1}:\n{page_result}\n")
            
            # Extract tables using Camelot
            table_results = self._extract_tables(pdf_bytes)
            if table_results:
                results.append("\nTABLES:\n" + table_results)
            
            # Combine results
            combined_result = "\n".join(results)
            
            processing_time = time.time() - start_time
            logger.info(f"LayoutParser processing completed in {processing_time:.2f} seconds")
            
            return combined_result
        
        except Exception as e:
            logger.error(f"Error in LayoutParser document processing: {str(e)}")
            return f"ERROR IN LAYOUTPARSER PROCESSING: {str(e)}"
    
    def _convert_pdf_to_images(self, pdf_bytes: bytes) -> List[np.ndarray]:
        """
        Convert PDF bytes to a list of images.
        
        Args:
            pdf_bytes (bytes): PDF file content
            
        Returns:
            List[np.ndarray]: List of images as numpy arrays, one per page
        """
        try:
            # Use pdf2image or PyMuPDF for conversion
            import fitz  # PyMuPDF
            
            images = []
            with fitz.open(stream=pdf_bytes, filetype="pdf") as doc:
                for page_num, page in enumerate(doc):
                    logger.info(f"Converting page {page_num+1} to image")
                    # Render page to an image with higher resolution
                    pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
                    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
                    # Convert to RGB if needed
                    if pix.n == 4:  # RGBA
                        img = cv2.cvtColor(img, cv2.COLOR_RGBA2RGB)
                    images.append(img)
            
            return images
        
        except ImportError:
            logger.warning("PyMuPDF not available, falling back to pdf2image")
            try:
                from pdf2image import convert_from_bytes
                
                pil_images = convert_from_bytes(
                    pdf_bytes,
                    dpi=300,
                    fmt="png",
                )
                
                # Convert PIL images to numpy arrays
                images = [np.array(img) for img in pil_images]
                return images
            
            except Exception as e:
                logger.error(f"Error converting PDF to images: {str(e)}")
                return []
    
    def _process_image(self, image: np.ndarray) -> str:
        """
        Process a single image with LayoutParser.
        
        Args:
            image (np.ndarray): Image as numpy array
            
        Returns:
            str: Extracted text with layout information
        """
        try:
            # Detect layout
            layout = self.model.detect(image)
            
            # Sort layout elements by their position (top to bottom, left to right)
            sorted_blocks = sorted(layout, key=lambda b: (b.block.y_1, b.block.x_1))
            
            # Process each layout element
            results = []
            for block in sorted_blocks:
                # Extract the image region
                segment_image = (block
                                .pad(left=5, right=5, top=5, bottom=5)
                                .crop_image(image))
                
                # Determine the block type
                block_type = block.type if hasattr(block, 'type') else "Unknown"
                
                # Apply OCR based on block type
                if block_type in ["Text", "Title", "List"]:
                    # Use Tesseract for text blocks
                    text = pytesseract.image_to_string(
                        Image.fromarray(segment_image),
                        config='--psm 6'  # Assume a single uniform block of text
                    )
                    if text.strip():
                        results.append(f"[{block_type}] {text.strip()}")
                
                elif block_type == "Table":
                    # Tables are handled separately by Camelot
                    results.append(f"[TABLE DETECTED AT {block.block}]")
                
                elif block_type == "Figure":
                    results.append(f"[FIGURE DETECTED AT {block.block}]")
            
            return "\n".join(results)
        
        except Exception as e:
            logger.error(f"Error processing image with LayoutParser: {str(e)}")
            return f"ERROR PROCESSING IMAGE: {str(e)}"
    
    def _extract_tables(self, pdf_bytes: bytes) -> str:
        """
        Extract tables from PDF using Camelot.
        
        Args:
            pdf_bytes (bytes): PDF file content
            
        Returns:
            str: Extracted tables as formatted text
        """
        try:
            # Save PDF to a temporary file for Camelot
            with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as temp_file:
                temp_file.write(pdf_bytes)
                temp_path = temp_file.name
            
            # Extract tables using Camelot
            logger.info("Extracting tables with Camelot")
            tables = camelot.read_pdf(temp_path, pages='all', flavor='lattice')
            
            if len(tables) == 0:
                # Try stream flavor if lattice didn't find any tables
                tables = camelot.read_pdf(temp_path, pages='all', flavor='stream')
            
            # Clean up temporary file
            os.unlink(temp_path)
            
            if len(tables) == 0:
                logger.info("No tables found in the document")
                return ""
            
            # Format tables as text
            table_texts = []
            for i, table in enumerate(tables):
                df = table.df
                table_texts.append(f"Table {i+1}:\n{df.to_string(index=False)}\n")
            
            return "\n".join(table_texts)
        
        except Exception as e:
            logger.error(f"Error extracting tables with Camelot: {str(e)}")
            return f"ERROR EXTRACTING TABLES: {str(e)}"
    
    async def extract_form_fields(self, pdf_bytes: bytes) -> Dict[str, Any]:
        """
        Extract form fields from a PDF using LayoutParser and OCR.
        
        Args:
            pdf_bytes (bytes): PDF file content
            
        Returns:
            Dict[str, Any]: Structured data extracted from the form
        """
        # Process the document
        extracted_text = await self.process_document(pdf_bytes)
        
        # Parse the extracted text into structured data
        structured_data = self._parse_form_fields(extracted_text)
        
        return structured_data
    
    def _parse_form_fields(self, extracted_text: str) -> Dict[str, Any]:
        """
        Parse extracted text into structured form data.
        
        Args:
            extracted_text (str): Text extracted by LayoutParser
            
        Returns:
            Dict[str, Any]: Structured form data
        """
        # Initialize the structure based on your form schema
        structured_data = {
            "applicant": {
                "first_name": None,
                "last_name": None,
                "dob": None,
                "gender": None,
                "ssn": None,
                "address": None,
                "city": None,
                "state": None,
                "zip": None,
                "phone": None,
                "email": None
            },
            "enrollment": {
                "effective_date": None,
                "plan_type": None,
                "coverage_level": None,
                "group_number": None,
                "employer": None
            },
            "spouse": {
                "first_name": None,
                "last_name": None,
                "dob": None,
                "gender": None,
                "ssn": None
            },
            "children": []
        }
        
        # In a real implementation, you would parse the extracted_text
        # and populate the structured_data dictionary
        # This could involve regex, NER, or other text processing techniques
        
        # For demonstration, we'll use a simple line-by-line approach with layout context
        lines = extracted_text.split('\n')
        current_section = None
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Check if this is a section header
            if line.startswith("[Title]"):
                title_text = line.replace("[Title]", "").strip()
                if "APPLICANT" in title_text.upper() or "EMPLOYEE" in title_text.upper():
                    current_section = "applicant"
                elif "SPOUSE" in title_text.upper():
                    current_section = "spouse"
                elif "CHILD" in title_text.upper() or "DEPENDENT" in title_text.upper():
                    current_section = "children"
                elif "ENROLLMENT" in title_text.upper() or "COVERAGE" in title_text.upper():
                    current_section = "enrollment"
                continue
            
            # Process text blocks
            if line.startswith("[Text]"):
                text = line.replace("[Text]", "").strip()
                
                # Process fields based on current section
                if current_section == "applicant":
                    if "NAME:" in text.upper() or "NAME " in text.upper():
                        name_parts = text.split(":")[-1].strip().split()
                        if len(name_parts) >= 2:
                            structured_data["applicant"]["first_name"] = name_parts[0]
                            structured_data["applicant"]["last_name"] = name_parts[-1]
                    elif "DOB:" in text.upper() or "BIRTH" in text.upper():
                        structured_data["applicant"]["dob"] = text.split(":")[-1].strip()
                    elif "SSN:" in text.upper() or "SOCIAL" in text.upper():
                        structured_data["applicant"]["ssn"] = text.split(":")[-1].strip()
                    # Add more field extractions as needed
                
                # Similar processing for other sections
                elif current_section == "spouse":
                    if "NAME:" in text.upper() or "NAME " in text.upper():
                        name_parts = text.split(":")[-1].strip().split()
                        if len(name_parts) >= 2:
                            structured_data["spouse"]["first_name"] = name_parts[0]
                            structured_data["spouse"]["last_name"] = name_parts[-1]
                    # Add more spouse field extractions
                
                elif current_section == "children":
                    # Process child information
                    if "NAME:" in text.upper() or "NAME " in text.upper():
                        # Start a new child entry
                        child = {
                            "first_name": None,
                            "last_name": None,
                            "dob": None,
                            "gender": None
                        }
                        name_parts = text.split(":")[-1].strip().split()
                        if len(name_parts) >= 2:
                            child["first_name"] = name_parts[0]
                            child["last_name"] = name_parts[-1]
                        structured_data["children"].append(child)
                    # Add more child field extractions
        
        return structured_data
