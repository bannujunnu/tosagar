"""
Azure OpenAI Processor for Document Intelligence Results

This service uses Azure OpenAI's GPT-4o model to process and enhance the results
from Azure Document Intelligence, extracting structured information from documents.
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional
import time

from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI
from dotenv import load_dotenv
import langsmith
from langsmith import traceable
from langchain_core.prompts import PromptTemplate
from pydantic import PrivateAttr

# Ensure logs directory exists
os.makedirs('logs', exist_ok=True)

# Configure logging
log_file_path = os.path.join('logs', 'azure_ocr_api.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(log_file_path, mode='a')
    ]
)
logger = logging.getLogger(__name__)


# Load environment variables
load_dotenv()
logger.info(f"Azure OpenAI Processor logging initialized. Log file: {os.path.abspath(log_file_path)}")


class AzureOpenAIProcessor:
    """
    Service for processing Azure Document Intelligence results using Azure OpenAI GPT-4o.
    This class enhances document extraction by applying LLM reasoning to the OCR results.
    """
    _impact_template = PrivateAttr(default=None)
    _impact_prompt = PrivateAttr(default=None)
    _impact_chain = PrivateAttr(default=None)
    
    # Define the prompt template as a class attribute - without formatting
    prompt_template = """
You are a document processing assistant that extracts structured data from a dental and vision enrollment/change form.

Given the OCR-extracted JSON from a layout-aware model (e.g., Azure Form Recognizer or Azure Document Intelligence), extract and summarize the key information in a clear, structured format for downstream processing.

Focus on the following fields:

1. Applicant Information
   - Full Name
   - SSN (if present)
   - Sex (if present)
   - Date of Birth
   - Address
   - Email and Phone (if available)

2. Enrollment Action
   - Type of activity: Add / Remove / Change / Waive
   - Effective Date
   - Reason for change (e.g., Marriage, Birth, Termination)

3. Covered Individuals
   - Spouse: Name and DOB and SSN and Sex
   - Children: Names and DOBs and SSNs and Sex

4. Plan Selections
   - Dental Plan selected (include number of units if mentioned)
   - Vision Plan selected (include number of units if mentioned)

5. Payment & Authorization
   - Acknowledgment of payroll deduction (Yes/No)
   - Account (Account Number if mentioned)
   - Routing (Routing number If mentioned)
   - Credit or Debit card Type (Visa/MasterCard if mentioned)
   - Expiry Date (if mentioned)
   - Card Holder Name (if mentioned)
   - Signature provided: Yes/No
   - Name of person who signed
   - Signature date
   
6. Broker/General Agent Details
   - Agent Name
   - NPN#
   - General Agent/Broker (General Agent/Broker name if mentioned)
   - Agent/Vendor ID# (Agent/Vendor ID If mentioned)
   - Broking date
   

Format the output as structured bullet points or a compact JSON-like summary suitable for automation. If any information is missing, mark it as "Not provided."

Input:
{0}
"""
    
    def __init__(self):
        """Initialize the Azure OpenAI processor with credentials from environment variables."""
        # Load Azure OpenAI credentials from environment variables
        self.api_key = os.getenv("AZURE_OPENAI_API_KEY")
        self.api_version = os.getenv("AZURE_OPENAI_API_VERSION")
        self.azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.deployment_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
        
        # Load LangTrace configuration
        self.langtrace_enabled = os.getenv("LANGSMITH_TRACING")
        self.langsmith_api_key = os.getenv("LANGSMITH_API_KEY")
        self.langsmith_project = os.getenv("LANGSMITH_PROJECT")
        self.langsmith_endpoint = os.getenv("LANGSMITH_ENDPOINT")
        
        # Validate required configurations
        if not all([self.api_key, self.api_version, self.azure_endpoint, self.deployment_name]):
            raise ValueError("Azure OpenAI credentials not found in environment variables. "
                            "Please set AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_VERSION, "
                            "AZURE_OPENAI_ENDPOINT, and AZURE_OPENAI_DEPLOYMENT_NAME.")
        
        # Initialize the Azure OpenAI client
        self.client = AzureOpenAI(
            api_key=self.api_key,
            api_version=self.api_version,
            azure_endpoint=self.azure_endpoint
        )
        
        # Configure LangTrace if enabled
        if self.langtrace_enabled and self.langsmith_api_key and self.langsmith_project:
            os.environ["LANGCHAIN_TRACING_V2"] = "true"
            os.environ["LANGCHAIN_ENDPOINT"] = self.langsmith_endpoint or "https://api.smith.langchain.com"
            os.environ["LANGCHAIN_API_KEY"] = self.langsmith_api_key
            os.environ["LANGCHAIN_PROJECT"] = self.langsmith_project
            logger.info(f"LangTrace enabled for project: {self.langsmith_project}")
        
        logger.info("Azure OpenAI processor initialized")
        
        
    
    @traceable(run_type="llm")
    def process_document_intelligence_result(self, json_input_text: str) -> Dict[str, Any]:
        """
        Process the Azure Document Intelligence result using Azure OpenAI GPT-4o.
        
        Args:
            json_input_text: The JSON string result from Azure Document Intelligence
            
        Returns:
            A dictionary containing the enhanced extraction results in JSON format
        """
        try:
            # Format the prompt template with the input JSON
            prompt = self.prompt_template.format(json_input_text)
            
            # Log the prompt for debugging
            logger.info(f"Sending prompt to Azure OpenAI: {prompt[:200]}...")
            
            # Start timing the API call
            start_time = time.time()
            
            # Call the Azure OpenAI API
            response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {"role": "system", "content": "You are an AI assistant specialized in document analysis. "
                                                "Extract structured information from document OCR results "
                                                "and return it in a clean JSON format."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.1,
                max_tokens=12000,
                response_format={"type": "json_object"}
            )
            
            # Calculate and log the API call duration
            duration = time.time() - start_time
            logger.info(f"Azure OpenAI API call completed in {duration:.2f} seconds")
            
            # Extract the JSON response
            response_content = response.choices[0].message.content
            
            # Parse the JSON response
            try:
                json_response = json.loads(response_content)
                logger.info("Successfully parsed JSON response from Azure OpenAI")
                
                # Ensure the response is in the expected format for the frontend
                # If the JSON response already has the expected structure, use it directly
                if isinstance(json_response, dict) and any(key in json_response for key in [
                    'ApplicantInformation', 'EnrollmentAction', 'CoveredIndividuals',
                    'PlanSelections', 'PaymentAuthorization', 'BrokerGeneralAgentDetails'
                ]):
                    result = {"Applicant Enrollment Details": json_response}
                # If the response has a different structure, try to adapt it
                elif isinstance(json_response, dict) and 'extracted_data' in json_response:
                    if isinstance(json_response['extracted_data'], dict):
                        result = {"Applicant Enrollment Details": json_response['extracted_data']}
                    else:
                        result = {"Applicant Enrollment Details": json_response}
                else:
                    # Wrap whatever we got in the expected structure
                    result = {"Applicant Enrollment Details": json_response}
                
                logger.info(f"Returning structured result: {json.dumps(result)[:200]}...")
                return result
            
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse JSON response: {e}")
                logger.error(f"Raw response: {response_content}")
                
                # Return a structured error response
                return {
                    "error": "json_parse_error",
                    "message": f"Failed to parse JSON response: {str(e)}",
                    "raw_response": response_content
                }
                
        except Exception as e:
            logger.error(f"Error processing document with Azure OpenAI: {e}")
            
            # Return a structured error response
            return {
                "error": str(type(e).__name__),
                "message": str(e),
                
            }

    
    

    


