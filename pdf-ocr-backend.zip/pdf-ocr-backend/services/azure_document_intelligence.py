"""
Azure AI Document Intelligence Service for OCR processing of PDF documents.
This service uses Azure's Document Intelligence API to extract text and form fields from PDF documents.
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional
from pathlib import Path
import tempfile

from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeResult
from dotenv import load_dotenv

# Ensure logs directory exists
os.makedirs('logs', exist_ok=True)

# Configure logging
log_file_path = os.path.join('logs', 'azure_document_intelligence.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(log_file_path, mode='a')
    ]
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()
logger.info(f"Azure Document Intelligence service logging initialized. Log file: {os.path.abspath(log_file_path)}")

class AzureDocumentIntelligenceService:
    """
    Service for processing PDF documents using Azure AI Document Intelligence.
    """
    
    def __init__(self):
        """Initialize the Azure Document Intelligence service with credentials from environment variables."""
        # Load credentials from environment variables
        endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
        key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
        
        if not endpoint or not key:
            raise ValueError("Azure Document Intelligence credentials not found in environment variables.")
        
        # Initialize the Document Intelligence client
        self.client = DocumentIntelligenceClient(
            endpoint=endpoint, 
            credential=AzureKeyCredential(key)
        )
        logger.info("Azure Document Intelligence service initialized")
    
    def process_pdf(self, pdf_path: str, model: str = "prebuilt-layout") -> Dict[str, Any]:
        """
        Process a PDF document using Azure Document Intelligence.
        
        Args:
            pdf_path: Path to the PDF file
            model: The model to use for document analysis (default: prebuilt-layout)
                   Options include:
                   - prebuilt-layout: General document layout analysis
                   - prebuilt-document: General document analysis
                   - prebuilt-read: Text reading
                   - prebuilt-invoice: Invoice analysis
                   - prebuilt-receipt: Receipt analysis
                   - prebuilt-idDocument: ID document analysis
                   - prebuilt-tax.us.w2: US W2 tax form analysis
        
        Returns:
            A dictionary containing the extracted text and form fields
        """
        try:
            # Check if file exists
            if not os.path.exists(pdf_path):
                raise FileNotFoundError(f"PDF file not found: {pdf_path}")
            
            logger.info(f"Processing PDF: {pdf_path} with model: {model}")
            
            # Open the PDF file
            with open(pdf_path, "rb") as f:
                file_content = f.read()
                
                # Try with the model name as is first
                try:
                    poller = self.client.begin_analyze_document(
                        model_id=model,
                        body=file_content
                    )
                except Exception as model_error:
                    if "ModelNotFound" in str(model_error):
                        # Try with 'prebuilt-layout' as a fallback
                        logger.warning(f"Model '{model}' not found. Falling back to 'prebuilt-layout'.")
                        poller = self.client.begin_analyze_document(
                            model_id="prebuilt-layout",
                            body=file_content
                        )
                    else:
                        # Re-raise if it's not a ModelNotFound error
                        raise
            
            # Get the result of the operation
            result = poller.result()
            
            logger.info("Printing the response form DocIntelligence as is :")
            logger.info(result)
            
            
            # Process and format the results
            formatted_result = self._format_result(result)
            
            logger.info(f"formatted_result is: {formatted_result}")
            
            logger.info(f"Successfully processed PDF: {pdf_path}")
            return formatted_result
            
        except Exception as e:
            logger.error(f"Error processing PDF: {e}")
            raise
    
    def _format_result(self, result: AnalyzeResult) -> Dict[str, Any]:
        """
        Format the Azure Document Intelligence result into a structured JSON format.
        
        Args:
            result: The AnalyzeResult from Azure Document Intelligence
            
        Returns:
            A dictionary containing the formatted results
        """
        try:
            logger.info(f"Result is: {result}")
            logger.info("Result is : {result}")
            formatted_result = {
                "model_id": result.model_id if hasattr(result, "model_id") else "unknown",
                "api_version": result.api_version if hasattr(result, "api_version") else "unknown",
                "document_metadata": {
                    "page_count": len(result.pages) if hasattr(result, "pages") else 0,
                    "language": result.locale if hasattr(result, "locale") else None,
                },
                "content": self._extract_content(result),
                "tables": self._extract_tables(result),
                "key_value_pairs": self._extract_key_value_pairs(result),
                "entities": self._extract_entities(result)
            }
            
            # Add model-specific information if available
            if hasattr(result, "document_type") and result.document_type is not None:
                formatted_result["document_type"] = result.document_type
                
            if hasattr(result, "confidence") and result.confidence is not None:
                formatted_result["confidence"] = result.confidence
                
            return formatted_result
        except Exception as e:
            logger.error(f"Error formatting result: {e}")
            # Return a minimal result with error information
            return {
                "error": str(e),
                "document_metadata": {
                    "page_count": 0,
                    "language": None,
                },
                "content": [],
                "tables": [],
                "key_value_pairs": [],
                "entities": []
            }
    
    def _extract_content(self, result: AnalyzeResult) -> List[Dict[str, Any]]:
        """Extract and format the text content from the result."""
        content = []
        
        if hasattr(result, "pages") and result.pages is not None:
            for page_idx, page in enumerate(result.pages):
                page_content = {
                    "page_number": page_idx + 1,
                    "text": "",
                    "paragraphs": []
                }
                
                # Check if page has lines attribute and it's not None
                if hasattr(page, "lines") and page.lines is not None and len(page.lines) > 0:
                    # Set the page text to the first line if available
                    page_content["text"] = page.lines[0].content if hasattr(page.lines[0], "content") else ""
                    
                    # Group lines into paragraphs based on their position
                    current_paragraph = ""
                    for line in page.lines:
                        if hasattr(line, "content") and line.content is not None:
                            current_paragraph += line.content + " "
                            
                            # Simple heuristic: if line ends with period, question mark, or exclamation mark,
                            # consider it the end of a paragraph
                            if line.content.rstrip().endswith((".", "?", "!")):
                                page_content["paragraphs"].append(current_paragraph.strip())
                                current_paragraph = ""
                    
                    # Add any remaining text as a paragraph
                    if current_paragraph.strip():
                        page_content["paragraphs"].append(current_paragraph.strip())
                
                # Handle case where there's content but no lines attribute
                elif hasattr(page, "content") and page.content is not None:
                    page_content["text"] = page.content
                    page_content["paragraphs"].append(page.content)
                
                content.append(page_content)
        
        return content
    
    def _extract_tables(self, result: AnalyzeResult) -> List[Dict[str, Any]]:
        """Extract and format tables from the result."""
        tables = []
        
        if hasattr(result, "tables") and result.tables is not None:
            for table_idx, table in enumerate(result.tables):
                table_data = {
                    "table_id": table_idx + 1,
                    "page_number": table.bounding_regions[0].page_number if hasattr(table, "bounding_regions") and table.bounding_regions else None,
                    "row_count": table.row_count if hasattr(table, "row_count") else 0,
                    "column_count": table.column_count if hasattr(table, "column_count") else 0,
                    "cells": []
                }
                
                if hasattr(table, "cells") and table.cells is not None:
                    for cell in table.cells:
                        cell_data = {
                            "row_index": cell.row_index if hasattr(cell, "row_index") else 0,
                            "column_index": cell.column_index if hasattr(cell, "column_index") else 0,
                            "row_span": cell.row_span if hasattr(cell, "row_span") else 1,
                            "column_span": cell.column_span if hasattr(cell, "column_span") else 1,
                            "content": cell.content if hasattr(cell, "content") else "",
                            "is_header": cell.kind == "columnHeader" if hasattr(cell, "kind") else False
                        }
                        table_data["cells"].append(cell_data)
                
                tables.append(table_data)
        
        return tables
    
    def _extract_key_value_pairs(self, result: AnalyzeResult) -> List[Dict[str, str]]:
        """Extract and format key-value pairs from the result."""
        key_value_pairs = []
        
        if hasattr(result, "key_value_pairs") and result.key_value_pairs is not None:
            for kv in result.key_value_pairs:
                key = kv.key.content if kv.key else None
                value = kv.value.content if kv.value else None
                
                if key:
                    key_value_pairs.append({
                        "key": key,
                        "value": value or ""
                    })
                len(key_value_pairs)
        
        return key_value_pairs
    
    def _extract_entities(self, result: AnalyzeResult) -> List[Dict[str, Any]]:
        """Extract and format entities from the result."""
        entities = []
        
        if hasattr(result, "entities") and result.entities is not None:
            for entity in result.entities:
                entity_data = {
                    "category": entity.category if hasattr(entity, "category") else "unknown",
                    "subcategory": entity.subcategory if hasattr(entity, "subcategory") else None,
                    "content": entity.content if hasattr(entity, "content") else "",
                    "confidence": entity.confidence if hasattr(entity, "confidence") else 0.0
                }
                entities.append(entity_data)
        
        return entities
    
    def analyze_form(self, pdf_path: str, model: str = "prebuilt-document") -> Dict[str, Any]:
        """
        Analyze a form document using Azure Document Intelligence.
        This method is optimized for form field extraction.
        
        Args:
            pdf_path: Path to the PDF file
            model: The model to use for form analysis
            
        Returns:
            A dictionary containing the extracted form fields
        """
        return self.process_pdf(pdf_path, model)
