import io
import tempfile
import os
from typing import Dict, Any, List, Optional, Tuple
import asyncio
import json
import time
import base64
import copy
from pathlib import Path

# PDF processing libraries
from pypdf import PdfReader
import pytesseract
from PIL import Image
import cv2
import numpy as np

# Import our custom modules
from services.llm_service import LLMService
from models.response_models import ExtractedDataResponse, ChildDetail, SpouseDetail, ApplicantDetail, EnrollmentDetail
from utils.form_extractor import FormFieldExtractor
from utils.form_field_enhancer import FormFieldEnhancer
from utils.logging_utils import get_logger

# Configure logging
logger = get_logger(__name__)

class PDFProcessor:
    """Service for processing PDF files, performing OCR, and extracting information"""
    
    def __init__(self, llm_service: LLMService):
        """
        Initialize the PDF processor
        
        Args:
            llm_service (LLMService): LLM service for information extraction
        """
        self.llm_service = llm_service
        logger.info("PDF Processor initialized")
    
    async def extract_text_from_pdf(self, pdf_bytes: bytes) -> str:
        """
        Extract text from PDF using a combination of direct extraction and OCR
        
        Args:
            pdf_bytes (bytes): PDF file content
            
        Returns:
            str: Extracted text
        """
        start_time = time.time()
        try:
            # First try direct extraction to see if the PDF has embedded text
            logger.info("Trying direct text extraction from PDF")
            pdf_reader = PdfReader(io.BytesIO(pdf_bytes))
            text_content = ""
            has_substantial_text = False
            
            # Extract text from each page
            for i, page in enumerate(pdf_reader.pages):
                page_text = page.extract_text() or ""
                if page_text.strip():
                    text_content += f"PAGE {i+1}:\n{page_text}\n\n"
                    if len(page_text.strip()) > 100:  # Consider this page has substantial text
                        has_substantial_text = True
            
            # If direct extraction yielded substantial text, return it
            if has_substantial_text:
                logger.info("Successfully extracted text directly from PDF")
                extraction_time = time.time() - start_time
                logger.info(f"Direct text extraction took {extraction_time:.2f} seconds")
                return text_content
            
            # If direct extraction didn't yield much, try OCR
            logger.info("Direct extraction yielded insufficient text, trying OCR")
            ocr_text = await self._perform_ocr(pdf_bytes)
            extraction_time = time.time() - start_time
            logger.info(f"Total text extraction process took {extraction_time:.2f} seconds")
            
            # If OCR yielded text, return it
            if ocr_text and ocr_text != "OCR FAILED TO EXTRACT TEXT":
                logger.info("Successfully extracted text using OCR")
                return ocr_text
            
            # If both methods failed to yield substantial text, return whatever we got
            if text_content.strip():
                logger.warning("OCR failed, returning limited text from direct extraction")
                return text_content
            else:
                logger.warning("Both direct extraction and OCR failed to yield text")
                return "FAILED TO EXTRACT TEXT FROM PDF"
            
        except Exception as e:
            logger.error(f"Error in text extraction process: {str(e)}")
            # Try direct text extraction if everything else fails
            try:
                logger.info("Attempting direct extraction as emergency fallback")
                pdf_reader = PdfReader(io.BytesIO(pdf_bytes))
                text_content = ""
                
                for i, page in enumerate(pdf_reader.pages):
                    page_text = page.extract_text() or ""
                    if page_text.strip():
                        text_content += f"PAGE {i+1}:\n{page_text}\n\n"
                
                return text_content or "FAILED TO EXTRACT TEXT FROM PDF"
            except Exception as inner_e:
                logger.error(f"Emergency fallback also failed: {str(inner_e)}")
                return "FAILED TO EXTRACT TEXT FROM PDF"
    
    async def _perform_ocr(self, pdf_bytes: bytes) -> str:
        """
        Perform OCR on PDF file using PyPDF and Tesseract with enhanced form field detection
        
        Args:
            pdf_bytes (bytes): PDF file content
            
        Returns:
            str: OCR extracted text
        """
        ocr_start_time = time.time()
        
        # This function can be CPU-intensive, so we run it in a thread pool
        def _ocr_task():
            try:
                # Create PDF reader object
                pdf_reader = PdfReader(io.BytesIO(pdf_bytes))
                full_text = ""
                form_field_data = {}
                
                with tempfile.TemporaryDirectory() as temp_dir:
                    # Process each page
                    for i, page in enumerate(pdf_reader.pages):
                        page_text = ""
                        page_form_fields = {}
                        
                        # First try to extract text directly
                        direct_text = page.extract_text()
                        if direct_text and len(direct_text.strip()) > 50:  # If we have substantial text
                            page_text = direct_text
                        
                        # Process images for OCR regardless of direct text extraction
                        # This helps with forms where text might be in boxes/tables
                        page_images = self._extract_images_from_page(page, i, temp_dir)
                        
                        if page_images:
                            # If we found images, perform OCR on them
                            for img_path in page_images:
                                try:
                                    with Image.open(img_path) as img:
                                        # Resize if image is very small
                                        if img.width < 1000 or img.height < 1000:
                                            scale_factor = max(1000 / img.width, 1000 / img.height)
                                            new_size = (int(img.width * scale_factor), int(img.height * scale_factor))
                                            img = img.resize(new_size, Image.Resampling.LANCZOS)
                                        
                                        # Convert to RGB if needed (Tesseract works better with RGB)
                                        if img.mode != 'RGB':
                                            img = img.convert('RGB')
                                        
                                        # Standard OCR
                                        standard_config = r'--oem 3 --psm 3'
                                        img_text = pytesseract.image_to_string(img, lang='eng', config=standard_config)
                                        
                                        # Enhanced form field detection and OCR
                                        try:
                                            # Process the image using the form field enhancer
                                            enhanced_img = FormFieldEnhancer.preprocess_form_image(img)
                                            
                                            # Detect form fields
                                            form_fields = FormFieldEnhancer.detect_form_fields(enhanced_img)
                                            
                                            # Extract text from form fields with specialized settings
                                            field_text = FormFieldEnhancer.extract_text_from_form_fields(enhanced_img, form_fields)
                                            
                                            # Add form field data to the page text
                                            if field_text:
                                                logger.info(f"Extracted {len(field_text)} form fields from page {i+1}")
                                                page_form_fields.update(field_text)
                                                
                                                # Add form field structured data to the page text
                                                try:
                                                    # First, add the raw form field data for debugging
                                                    form_field_text = "\n--- FORM FIELD DATA ---\n"
                                                    for field_key, text in field_text.items():
                                                        if text.strip():
                                                            form_field_text += f"{field_key}: {text}\n"
                                                    form_field_text += "--- END FORM FIELD DATA ---\n"
                                                    
                                                    # Then, add structured JSON data for better extraction
                                                    # Organize field data into a structured format
                                                    structured_data = {
                                                        "applicant": {},
                                                        "enrollment": {},
                                                        "spouse": {},
                                                        "children": []
                                                    }
                                                    
                                                    # Process fields and categorize them
                                                    for field_key, text in field_text.items():
                                                        if not text.strip():
                                                            continue
                                                            
                                                        # Check for name fields
                                                        if "_name" in field_key and text.strip():
                                                            # Try to determine if it's applicant, spouse, or child
                                                            if "applicant" in field_key.lower() or "subscriber" in field_key.lower():
                                                                # Split into first/last name if possible
                                                                name_parts = text.strip().split()
                                                                if len(name_parts) > 1:
                                                                    structured_data["applicant"]["last_name"] = name_parts[-1]
                                                                    structured_data["applicant"]["first_name"] = " ".join(name_parts[:-1])
                                                                else:
                                                                    structured_data["applicant"]["last_name"] = text.strip()
                                                            elif "spouse" in field_key.lower() or "partner" in field_key.lower():
                                                                name_parts = text.strip().split()
                                                                if len(name_parts) > 1:
                                                                    structured_data["spouse"]["last_name"] = name_parts[-1]
                                                                    structured_data["spouse"]["first_name"] = " ".join(name_parts[:-1])
                                                                else:
                                                                    structured_data["spouse"]["last_name"] = text.strip()
                                                            elif "child" in field_key.lower() or "dependent" in field_key.lower():
                                                                name_parts = text.strip().split()
                                                                child_data = {}
                                                                if len(name_parts) > 1:
                                                                    child_data["last_name"] = name_parts[-1]
                                                                    child_data["first_name"] = " ".join(name_parts[:-1])
                                                                else:
                                                                    child_data["last_name"] = text.strip()
                                                                structured_data["children"].append(child_data)
                                                        
                                                        # Check for date fields
                                                        if "_date" in field_key and text.strip() and "/" in text:
                                                            if "birth" in field_key.lower() or "dob" in field_key.lower():
                                                                if "applicant" in field_key.lower() or "subscriber" in field_key.lower():
                                                                    structured_data["applicant"]["dob"] = text.strip()
                                                                elif "spouse" in field_key.lower() or "partner" in field_key.lower():
                                                                    structured_data["spouse"]["dob"] = text.strip()
                                                                elif "child" in field_key.lower() or "dependent" in field_key.lower():
                                                                    # Find the child or create a new one
                                                                    child_index = -1
                                                                    field_id = field_key.split("_")[2] if len(field_key.split("_")) > 2 else ""
                                                                    for i, child in enumerate(structured_data["children"]):
                                                                        # Try to match based on the field ID in the key
                                                                        if field_id and field_id in field_key:
                                                                            child_index = i
                                                                            break
                                                                    
                                                                    if child_index >= 0:
                                                                        structured_data["children"][child_index]["dob"] = text.strip()
                                                                    else:
                                                                        structured_data["children"].append({"dob": text.strip()})
                                                            elif "enroll" in field_key.lower():
                                                                structured_data["enrollment"]["enrollment_date"] = text.strip()
                                                    
                                                    # Add the structured data as JSON
                                                    form_field_text += "\nFORM_FIELD_STRUCTURED_DATA:\n"
                                                    form_field_text += json.dumps(structured_data, indent=2)
                                                    form_field_text += "\nEND_FORM_FIELD_STRUCTURED_DATA\n"
                                                except Exception as json_e:
                                                    logger.error(f"Error creating structured form field data: {str(json_e)}")
                                                    # Continue with the raw form field data only
                                                
                                                img_text += "\n" + form_field_text
                                        except Exception as form_e:
                                            logger.error(f"Error in form field enhancement: {str(form_e)}")
                                        
                                        # Add the extracted text
                                        if img_text.strip():
                                            page_text += img_text + "\n"
                                except Exception as img_e:
                                    logger.error(f"Error processing image {img_path}: {str(img_e)}")
                        else:
                            # If no images found, try to render the page as an image
                            img_path = os.path.join(temp_dir, f"page_{i}.png")
                            page_image = self._render_page_as_image(page, img_path)
                            
                            if page_image:
                                try:
                                    # Standard OCR
                                    img_text = pytesseract.image_to_string(page_image, lang='eng')
                                    
                                    # Enhanced form field detection
                                    try:
                                        enhanced_img = FormFieldEnhancer.preprocess_form_image(page_image)
                                        form_fields = FormFieldEnhancer.detect_form_fields(enhanced_img)
                                        field_text = FormFieldEnhancer.extract_text_from_form_fields(enhanced_img, form_fields)
                                        
                                        if field_text:
                                            logger.info(f"Extracted {len(field_text)} form fields from rendered page {i+1}")
                                            page_form_fields.update(field_text)
                                            
                                            # Add form field text to the page text
                                            form_field_text = "\n--- FORM FIELD DATA ---\n"
                                            for field_key, text in field_text.items():
                                                if text.strip():
                                                    form_field_text += f"{field_key}: {text}\n"
                                            form_field_text += "--- END FORM FIELD DATA ---\n"
                                            
                                            img_text += "\n" + form_field_text
                                    except Exception as form_e:
                                        logger.error(f"Error in form field enhancement for rendered page: {str(form_e)}")
                                    
                                    if img_text.strip():
                                        page_text += img_text
                                except Exception as render_e:
                                    logger.error(f"Error OCR on rendered page: {str(render_e)}")
                        
                        # Store form field data for this page
                        if page_form_fields:
                            form_field_data[f"page_{i+1}"] = page_form_fields
                        
                        # Add the page text to the full text
                        if page_text.strip():
                            full_text += f"PAGE {i+1}:\n{page_text}\n\n"
                        else:
                            logger.warning(f"No text extracted from page {i+1}")
                
                # Add form field data as structured information at the end
                if form_field_data:
                    full_text += "\n\nFORM_FIELD_STRUCTURED_DATA:\n"
                    full_text += json.dumps(form_field_data, indent=2)
                    full_text += "\nEND_FORM_FIELD_STRUCTURED_DATA\n"
                
                return full_text
            except Exception as e:
                logger.error(f"Error in OCR process: {str(e)}")
                return ""
        
        # Run OCR in a thread pool
        loop = asyncio.get_event_loop()
        ocr_text = await loop.run_in_executor(None, _ocr_task)
        ocr_time = time.time() - ocr_start_time
        logger.info(f"OCR operation took {ocr_time:.2f} seconds")
        
        if not ocr_text:
            logger.warning("OCR failed to extract any text")
            return "OCR FAILED TO EXTRACT TEXT"
        
        logger.info(f"OCR extracted {len(ocr_text)} characters of text")
        return ocr_text
        
    def _extract_images_from_page(self, page, page_num: int, output_dir: str) -> List[str]:
        """
        Extract images from a PDF page and save them to disk
        
        Args:
            page: PDF page object from PyPDF
            page_num: Page number (for naming)
            output_dir: Directory to save images
            
        Returns:
            List[str]: List of paths to saved images
        """
        image_paths = []
        try:
            # Get XObject resources from the page
            resources = page.get("/Resources", {})
            xobject = resources.get("/XObject", {})
            
            # Extract each image
            for i, (name, image) in enumerate(xobject.items()):
                try:
                    if name.startswith("/Im") or "/Subtype" in image and image["/Subtype"] == "/Image":
                        # Get image data
                        data = image.get_data()
                        if not data:
                            continue
                            
                        # Determine file extension based on filter
                        filters = image.get("/Filter", [])
                        if isinstance(filters, list):
                            filter_name = filters[0] if filters else None
                        else:
                            filter_name = filters
                            
                        ext = ".png"  # Default extension
                        if filter_name == "/DCTDecode":
                            ext = ".jpg"
                        elif filter_name == "/JPXDecode":
                            ext = ".jp2"
                        elif filter_name == "/FlateDecode":
                            ext = ".png"
                            
                        # Save the image
                        img_path = os.path.join(output_dir, f"page_{page_num}_img_{i}{ext}")
                        
                        # Handle different color spaces
                        color_space = image.get("/ColorSpace", "/DeviceRGB")
                        width = image.get("/Width", 0)
                        height = image.get("/Height", 0)
                        
                        if width > 0 and height > 0:
                            try:
                                # Try to create an image from the raw data
                                if color_space == "/DeviceRGB":
                                    mode = "RGB"
                                elif color_space == "/DeviceCMYK":
                                    mode = "CMYK"
                                elif color_space == "/DeviceGray":
                                    mode = "L"
                                else:
                                    mode = "RGB"  # Default
                                    
                                # For JPEG images, we can write directly
                                if ext == ".jpg":
                                    with open(img_path, "wb") as img_file:
                                        img_file.write(data)
                                else:
                                    # For other formats, use PIL to convert and save
                                    try:
                                        img = Image.frombytes(mode, (width, height), data)
                                        img.save(img_path)
                                    except Exception as pil_e:
                                        # Fallback: save raw data
                                        with open(img_path, "wb") as img_file:
                                            img_file.write(data)
                                            
                                image_paths.append(img_path)
                            except Exception as img_e:
                                logger.error(f"Error saving image: {str(img_e)}")
                except Exception as xobj_e:
                    logger.error(f"Error processing XObject: {str(xobj_e)}")
                    continue
        except Exception as e:
            logger.error(f"Error extracting images from page {page_num}: {str(e)}")
            
        return image_paths
        
    def _render_page_as_image(self, page, output_path: str) -> Optional[Image.Image]:
        """
        Attempt to render a PDF page as an image using PyPDF and PIL
        This is a fallback method with limited capabilities
        
        Args:
            page: PDF page object from PyPDF
            output_path: Path to save the rendered image
            
        Returns:
            Optional[Image.Image]: PIL Image object if successful, None otherwise
        """
        try:
            # This is a simplified approach - PyPDF doesn't have robust rendering capabilities
            # Create a blank white image
            width, height = int(page.mediabox.width), int(page.mediabox.height)
            if width <= 0 or height <= 0:
                width, height = 612, 792  # Default to US Letter size
                
            # Scale up for better OCR results (600 DPI equivalent for forms)
            scale = 600 / 72  # PDF points to pixels at 600 DPI for better form field detection
            width, height = int(width * scale), int(height * scale)
            
            # Create a white background image
            img = Image.new('RGB', (width, height), (255, 255, 255))
            
            # Save the image
            img.save(output_path)
            return img
        except Exception as e:
            logger.error(f"Error rendering page as image: {str(e)}")
            return None
    
    def _extract_from_form_fields(self, ocr_text: str) -> Dict[str, Any]:
        """
        Extract structured data from the FORM_FIELD_STRUCTURED_DATA section in OCR text.
        
        Args:
            ocr_text (str): OCR text that may contain form field structured data
            
        Returns:
            Dict[str, Any]: Extracted form field data
        """
        form_field_data = {}
        
        # Check if the OCR text contains form field structured data
        if "FORM_FIELD_STRUCTURED_DATA" not in ocr_text:
            return form_field_data
            
        try:
            # Extract the JSON data between the FORM_FIELD_STRUCTURED_DATA markers
            start_marker = "FORM_FIELD_STRUCTURED_DATA:"
            end_marker = "END_FORM_FIELD_STRUCTURED_DATA"
            
            start_idx = ocr_text.find(start_marker)
            end_idx = ocr_text.find(end_marker)
            
            if start_idx != -1 and end_idx != -1:
                json_str = ocr_text[start_idx + len(start_marker):end_idx].strip()
                form_field_data = json.loads(json_str)
                logger.info(f"Successfully parsed form field structured data: {json_str[:100]}...")
            else:
                logger.warning("Could not find form field structured data markers in OCR text")
        except Exception as e:
            logger.error(f"Error parsing form field structured data: {str(e)}")
            
        return form_field_data
        
    def _merge_form_field_data(self, rule_based_data: Dict[str, Any], form_field_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge rule-based extraction with form field data, giving preference to form field data.
        
        Args:
            rule_based_data (Dict[str, Any]): Results from rule-based extraction
            form_field_data (Dict[str, Any]): Results from form field extraction
            
        Returns:
            Dict[str, Any]: Merged results
        """
        merged_data = copy.deepcopy(rule_based_data)
        
        # If we have form field data, use it to override rule-based data
        if not form_field_data:
            return merged_data
            
        # Applicant information
        if 'applicant' in merged_data and form_field_data.get('applicant'):
            for key, value in form_field_data['applicant'].items():
                if value:  # Only override if the form field value is not None/empty
                    merged_data['applicant'][key] = value
        
        # Enrollment information
        if 'enrollment' in merged_data and form_field_data.get('enrollment'):
            for key, value in form_field_data['enrollment'].items():
                if value:  # Only override if the form field value is not None/empty
                    merged_data['enrollment'][key] = value
        
        # Spouse information
        if 'spouse' in merged_data and form_field_data.get('spouse'):
            for key, value in form_field_data['spouse'].items():
                if value:  # Only override if the form field value is not None/empty
                    merged_data['spouse'][key] = value
        
        # Children information
        if 'children' in merged_data and form_field_data.get('children'):
            # This is more complex as we need to match children
            # For simplicity, we'll just append any form field children not in the rule-based data
            rule_children = merged_data.get('children', [])
            form_children = form_field_data.get('children', [])
            
            # Create a merged list of children
            if not rule_children and form_children:
                merged_data['children'] = form_children
            elif rule_children and form_children:
                # Try to merge children by matching on name or DOB
                merged_children = rule_children.copy()
                for form_child in form_children:
                    # Check if this child is already in the rule-based data
                    child_exists = False
                    for i, rule_child in enumerate(rule_children):
                        if (form_child.get('first_name') and rule_child.get('first_name') and 
                            form_child['first_name'] == rule_child['first_name']) or \
                           (form_child.get('dob') and rule_child.get('dob') and 
                            form_child['dob'] == rule_child['dob']):
                            # Update the existing child with form field data
                            for key, value in form_child.items():
                                if value:  # Only override if the form field value is not None/empty
                                    merged_children[i][key] = value
                            child_exists = True
                            break
                    
                    if not child_exists:
                        # Add this child to the merged list
                        merged_children.append(form_child)
                        
                merged_data['children'] = merged_children
        
        return merged_data
        
    async def process_pdf(self, pdf_bytes: bytes) -> ExtractedDataResponse:
        """
        Process PDF file: extract text and use LLM to extract information
        
        Args:
            pdf_bytes (bytes): PDF file content
            
        Returns:
            ExtractedDataResponse: Extracted information
        """
        try:
            # Extract text from PDF
            logger.info("Extracting text from PDF")
            extracted_text = await self.extract_text_from_pdf(pdf_bytes)
            
            if not extracted_text or extracted_text == "OCR FAILED TO EXTRACT TEXT":
                logger.error("Failed to extract text from PDF")
                # Create a minimal valid response with empty fields
                return ExtractedDataResponse(
                    applicant=ApplicantDetail(
                        last_name="Unknown",  # Required field
                        first_name="Unknown"  # Required field
                    ),
                    children=[],
                    raw_text="Failed to extract text from PDF"
                )
            
            # First, use our rule-based form field extractor to get initial data
            logger.info("Using rule-based extraction for form fields")            
            rule_based_data = FormFieldExtractor.extract_all_form_data(extracted_text)
            logger.info("Extracted Rulebased Data")
            
            # Extract known values from the form fields section
            form_field_data = self._extract_from_form_fields(extracted_text)
            if form_field_data:
                logger.info("Successfully extracted data from form fields")
                # Merge form field data with rule-based data
                rule_based_data = self._merge_form_field_data(rule_based_data, form_field_data)
            
            # Then use LLM to extract information and enhance the rule-based extraction
            logger.info("Extracting information using LLM")
            llm_extracted_info = await self.llm_service.extract_information(extracted_text)
            
            # Check if LLM extraction returned None or empty dict
            if llm_extracted_info is None:
                logger.warning("LLM extraction returned None, using only rule-based data")
                llm_extracted_info = {
                    "applicant": {
                        "first_name": None,
                        "last_name": None
                    },
                    "enrollment": None,
                    "spouse": None,
                    "children": []
                }
            
            # Merge the results, preferring rule-based extraction for structured fields
            # and LLM extraction for more complex fields
            merged_data = self._merge_extraction_results(rule_based_data, llm_extracted_info)
            
            # Ensure we have the required applicant fields
            applicant_info = merged_data.get("applicant", {})
            if not applicant_info.get("last_name") and not applicant_info.get("first_name"):
                # If we couldn't extract the required fields, set default values
                logger.warning("Could not extract applicant name, setting default values")
                applicant_info["last_name"] = "Unknown"
                applicant_info["first_name"] = "Unknown"
            
            # Process applicant information
            applicant = ApplicantDetail(
                last_name=applicant_info.get("last_name"),
                first_name=applicant_info.get("first_name"),
                ssn=applicant_info.get("ssn"),
                dob=applicant_info.get("dob"),
                sex=applicant_info.get("sex"),
                email=applicant_info.get("email"),
                address=applicant_info.get("address"),
                city=applicant_info.get("city"),
                state=applicant_info.get("state"),
                zip_code=applicant_info.get("zip_code"),
                phone=applicant_info.get("phone"),
                nj_resident=applicant_info.get("nj_resident")
            )
            
            # Process enrollment information
            enrollment_info = merged_data.get("enrollment", {})
            enrollment = EnrollmentDetail(
                enrollment_type=enrollment_info.get("enrollment_type"),
                enrollment_date=enrollment_info.get("enrollment_date"),
                plan_options=enrollment_info.get("plan_options")
            ) if enrollment_info else None
            
            # Process spouse information
            spouse_info = merged_data.get("spouse", {})
            spouse = SpouseDetail(
                last_name=spouse_info.get("last_name"),
                first_name=spouse_info.get("first_name"),
                ssn=spouse_info.get("ssn"),
                dob=spouse_info.get("dob"),
                sex=spouse_info.get("sex"),
                same_address=spouse_info.get("same_address")
            ) if spouse_info and (spouse_info.get("first_name") or spouse_info.get("last_name")) else None
            
            # Process children information
            children = []
            for child_info in merged_data.get("children", []):
                if child_info.get("first_name") or child_info.get("last_name") or child_info.get("dob"):
                    children.append(ChildDetail(
                        last_name=child_info.get("last_name"),
                        first_name=child_info.get("first_name"),
                        ssn=child_info.get("ssn"),
                        dob=child_info.get("dob"),
                        sex=child_info.get("sex"),
                        living_with_applicant=child_info.get("living_with_applicant")
                    ))
            
            # Create the response
            response = ExtractedDataResponse(
                applicant=applicant,
                enrollment=enrollment,
                spouse=spouse,
                children=children,
                raw_text=extracted_text[:1000] if len(extracted_text) > 1000 else extracted_text  # Limit raw text size
            )
            
            logger.info("Successfully processed PDF and extracted information")
            return response
            
        except Exception as e:
            logger.error(f"Error processing PDF: {str(e)}")
            # Instead of raising the exception, return a minimal valid response
            return ExtractedDataResponse(
                applicant=ApplicantDetail(
                    last_name="Error",
                    first_name="Processing"
                ),
                children=[],
                raw_text=f"Error processing PDF: {str(e)}"
            )
    
    def _merge_extraction_results(self, rule_based: Dict[str, Any], llm_based: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge results from rule-based extraction and LLM extraction
        
        Args:
            rule_based (Dict[str, Any]): Results from rule-based extraction
            llm_based (Dict[str, Any]): Results from LLM extraction
            
        Returns:
            Dict[str, Any]: Merged results
        """
        merged = {
            "applicant": {},
            "enrollment": {},
            "spouse": {},
            "children": []
        }
        
        # Helper function to merge dictionaries with preference for non-None values
        def merge_dicts(dict1, dict2):
            # Ensure both inputs are dictionaries
            if not isinstance(dict1, dict):
                dict1 = {}
            if not isinstance(dict2, dict):
                dict2 = {}
                
            result = {}
            # Start with all keys from both dictionaries
            try:
                all_keys = set(dict1.keys()).union(set(dict2.keys()))
            except Exception as e:
                logger.error(f"Error getting keys from dictionaries: {e}")
                logger.error(f"dict1: {type(dict1)}, dict2: {type(dict2)}")
                # Fallback to empty set if there's an error
                all_keys = set()
            
            for key in all_keys:
                try:
                    val1 = dict1.get(key)
                    val2 = dict2.get(key)
                    
                    # Prefer non-None values
                    if val1 is not None and val2 is not None:
                        # For nested dictionaries, recursively merge
                        if isinstance(val1, dict) and isinstance(val2, dict):
                            result[key] = merge_dicts(val1, val2)
                        else:
                            # Prefer rule-based for structured fields, LLM for more complex fields
                            result[key] = val1  # Default to rule-based
                    elif val1 is not None:
                        result[key] = val1
                    elif val2 is not None:
                        result[key] = val2
                    else:
                        result[key] = None
                except Exception as e:
                    logger.error(f"Error merging key {key}: {e}")
                    result[key] = None
            
            return result
        
        # Merge applicant information
        merged["applicant"] = merge_dicts(
            rule_based.get("applicant", {}),
            llm_based.get("applicant", {})
        )
        
        # Merge enrollment information
        merged["enrollment"] = merge_dicts(
            rule_based.get("enrollment", {}),
            llm_based.get("enrollment", {})
        )
        
        # Merge spouse information
        merged["spouse"] = merge_dicts(
            rule_based.get("spouse", {}),
            llm_based.get("spouse", {})
        )
        
        # Merge children information - this is more complex as we need to match children
        rule_children = rule_based.get("children", [])
        llm_children = llm_based.get("children", [])
        
        # If we have children from both sources, try to match them
        if rule_children and llm_children:
            # For each rule-based child, find a matching LLM-based child
            for rule_child in rule_children:
                matched = False
                for llm_child in llm_children:
                    # Check if they might be the same child based on name or DOB
                    if (rule_child.get("first_name") and llm_child.get("first_name") and 
                        rule_child["first_name"].lower() == llm_child["first_name"].lower()) or \
                       (rule_child.get("last_name") and llm_child.get("last_name") and 
                        rule_child["last_name"].lower() == llm_child["last_name"].lower()) or \
                       (rule_child.get("dob") and llm_child.get("dob") and 
                        rule_child["dob"] == llm_child["dob"]):
                        # Merge the child information
                        merged_child = merge_dicts(rule_child, llm_child)
                        merged["children"].append(merged_child)
                        matched = True
                        break
                
                # If no match found, add the rule-based child
                if not matched:
                    merged["children"].append(rule_child)
            
            # Add any LLM-based children that weren't matched
            for llm_child in llm_children:
                matched = False
                for rule_child in rule_children:
                    if (rule_child.get("first_name") and llm_child.get("first_name") and 
                        rule_child["first_name"].lower() == llm_child["first_name"].lower()) or \
                       (rule_child.get("last_name") and llm_child.get("last_name") and 
                        rule_child["last_name"].lower() == llm_child["last_name"].lower()) or \
                       (rule_child.get("dob") and llm_child.get("dob") and 
                        rule_child["dob"] == llm_child["dob"]):
                        matched = True
                        break
                
                if not matched:
                    merged["children"].append(llm_child)
        else:
            # If we only have children from one source, use those
            merged["children"] = rule_children or llm_children
        
        return merged
