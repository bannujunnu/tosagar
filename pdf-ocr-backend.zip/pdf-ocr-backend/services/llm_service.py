import os
import json
from typing import Dict, Any, Optional
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain.schema import HumanMessage, SystemMessage
from langchain.prompts import ChatPromptTemplate
from langchain.callbacks.tracers import LangChainTracer
from langchain.callbacks.manager import CallbackManager
from utils.logging_utils import get_logger
from utils.langsmith_utils import get_langsmith_callback_manager

# Load environment variables
load_dotenv()

# Configure logging
logger = get_logger(__name__)

class LLMService:
    """Service for interacting with Mistral LLM via Groq"""
    
    def __init__(self):
        """Initialize the LLM service with Groq client"""
        self.api_key = os.getenv("GROQ_API_KEY")
        self.model_name = os.getenv("MISTRAL_MODEL_NAME", "mistral-7b-instruct")
        
        if not self.api_key:
            logger.warning("GROQ_API_KEY not found in environment variables")
            raise ValueError("GROQ_API_KEY is required")
        
        # Get LangSmith callback manager for tracing
        self.callback_manager = get_langsmith_callback_manager()
        
        # Initialize the Groq LLM
        self.llm = ChatGroq(
            groq_api_key=self.api_key,
            model_name=self.model_name,
            temperature=0.1,  # Low temperature for more deterministic outputs
            callbacks=self.callback_manager.handlers if self.callback_manager else None,
        )
        
        logger.info(f"LLM service initialized with model: {self.model_name}")
        if self.callback_manager:
            logger.info("LangSmith tracing enabled for LLM service")
    
    async def extract_information(self, text: str) -> Dict[str, Any]:
        """
        Extract applicant and child information from OCR text using LLM
        
        Args:
            text (str): OCR text extracted from PDF
            
        Returns:
            Dict[str, Any]: Extracted information
        """
        try:
            # Create system prompt for information extraction
            system_prompt = """
            You are a document processing assistant that extracts structured data from a dental and vision enrollment/change form.

Given the OCR-extracted JSON from a layout-aware model (e.g., Azure Form Recognizer), extract and summarize the key information in a clear, structured format for downstream processing.

Focus on the following fields:
1. **Employee Information**
   - Full Name
   - SSN (if present)
   - Date of Birth (in MM/DD/YYYY format)
   - Address
   - Email and Phone (if available)

2. **Enrollment Action**
   - Type of activity: Add / Remove / Change / Waive
   - Effective Date
   - Reason for change (e.g., Marriage, Birth, Termination)

3. **Covered Individuals**
   - Spouse: Name,SSN and DOB(in MM/DD/YYYY format)
   - Children: Names,SSNs and DOBs(in MM/DD/YYYY format)

4. **Plan Selections**
   - Dental Plan selected (include number of units if mentioned)
   - Vision Plan selected (include number of units if mentioned)

5. **Payment & Authorization**
   - Acknowledgment of payroll deduction (Yes/No)
   - Signature captured (Yes/No)
   - Date of signature
   - Name of the person who signed

IMPORTANT : Format the output as structured bullet points or a compact JSON-like summary suitable for automation. If any information is missing, mark it as "Not provided."
            """
            
            # Create prompt template
            prompt = ChatPromptTemplate.from_messages([
                ("system", system_prompt),
                ("human", "Extract information from the OCR text below. Focus on the FORM_FIELD_STRUCTURED_DATA section which contains text from individual form fields. Return ONLY a valid JSON object with no additional text, markdown formatting, or explanations.\n\n{text}")
            ])
            
            # Format the prompt with the OCR text
            formatted_prompt = prompt.format_messages(text=text)
            
            # Get response from LLM
            logger.info("Sending request to LLM for information extraction")
            # Create run metadata for LangSmith tracing
            metadata = {
                "task": "information_extraction",
                "document_type": "dental_vision_form",
                "model": self.model_name
            }
            
            # Use tracing with metadata if callback manager is available
            if self.callback_manager:
                with self.callback_manager.get_tracker("extract_information", metadata=metadata):
                    response = await self.llm.ainvoke(formatted_prompt)
            else:
                response = await self.llm.ainvoke(formatted_prompt)
            
            # Extract content from response
            content = response.content
            
            # Parse the JSON response
            import json
            import re
            try:
                # The LLM might wrap the JSON in markdown code blocks, so we need to extract it
                if "```json" in content:
                    content = content.split("```json")[1].split("```")[0].strip()
                elif "```" in content:
                    content = content.split("```")[1].split("```")[0].strip()
                
                # Clean up the content to ensure it's valid JSON
                # Remove any leading/trailing non-JSON characters
                content = content.strip()
                
                # Try to find a valid JSON object using regex
                json_pattern = r'\{[\s\S]*\}'
                json_match = re.search(json_pattern, content)
                if json_match:
                    content = json_match.group(0)
                
                # Additional cleanup for common JSON formatting issues
                # Replace single quotes with double quotes
                content = content.replace("'", "\"")
                
                # Try to parse the JSON
                try:
                    extracted_data = json.loads(content)
                    logger.info("Successfully extracted information from OCR text")
                except json.JSONDecodeError:
                    # If parsing fails, try a more aggressive approach to fix common JSON issues
                    logger.warning("Initial JSON parsing failed, attempting to fix JSON format")
                    
                    # Try to fix unquoted keys
                    content = re.sub(r'([{,])\s*(\w+)\s*:', r'\1"\2":', content)
                    
                    # Try to fix trailing commas in arrays/objects
                    content = re.sub(r',\s*([\]}])', r'\1', content)
                    
                    # Try parsing again
                    extracted_data = json.loads(content)
                    logger.info("Successfully extracted information after fixing JSON format")
                
                # Ensure the response has the required structure
                if "applicant" not in extracted_data:
                    logger.warning("Applicant information missing in LLM response, creating default structure")
                    # If the LLM didn't follow the expected format, try to adapt the response
                    if "applicant_first_name" in extracted_data and "applicant_last_name" in extracted_data:
                        extracted_data["applicant"] = {
                            "first_name": extracted_data.pop("applicant_first_name", None),
                            "last_name": extracted_data.pop("applicant_last_name", None)
                        }
                    else:
                        # Create a minimal structure
                        extracted_data["applicant"] = {
                            "first_name": None,
                            "last_name": None
                        }
                
                # Ensure children array exists
                if "children" not in extracted_data:
                    if "child_details" in extracted_data:
                        extracted_data["children"] = extracted_data.pop("child_details", [])
                    else:
                        extracted_data["children"] = []
                
                return extracted_data
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse JSON response: {e}")
                logger.error(f"Raw response content length: {len(content)}")
                # Log a truncated version of the content for debugging
                truncated_content = content[:500] + "..." if len(content) > 500 else content
                logger.error(f"Truncated content: {truncated_content}")
                
                # Try to extract any useful information from the response
                # Look for applicant information patterns
                applicant_info = {}
                
                # Try to extract name
                name_match = re.search(r'["\']?first_name["\']?\s*:\s*["\']([^"\']*)["\'](,|\})', content)
                if name_match:
                    applicant_info["first_name"] = name_match.group(1)
                
                last_name_match = re.search(r'["\']?last_name["\']?\s*:\s*["\']([^"\']*)["\'](,|\})', content)
                if last_name_match:
                    applicant_info["last_name"] = last_name_match.group(1)
                
                # Return a structure with any extracted information
                return {
                    "applicant": applicant_info if applicant_info else {
                        "first_name": None,
                        "last_name": None
                    },
                    "enrollment": None,
                    "spouse": None,
                    "children": []
                }
                
        except Exception as e:
            logger.error(f"Error in LLM information extraction: {str(e)}")
            # Return a basic structure instead of raising the exception
            return {
                "applicant": {
                    "first_name": None,
                    "last_name": None
                },
                "enrollment": None,
                "spouse": None,
                "children": []
            }
