import io
import time
from typing import Dict, Any, Optional
import asyncio
import json
from enum import Enum

# Import our OCR services
from services.advanced_ocr_service import AdvancedOCRService, OCRMethod
from services.llm_service import LLMService
from models.response_models import ExtractedDataResponse, ChildDetail, SpouseDetail, ApplicantDetail, EnrollmentDetail
from utils.logging_utils import get_logger

# Configure logging
logger = get_logger(__name__)

class EnhancedPDFProcessor:
    """
    Enhanced service for processing PDF files using advanced OCR techniques and LLM extraction.
    Integrates Donut and LayoutParser OCR methods for improved accuracy.
    """
    
    def __init__(self, llm_service: LLMService, default_ocr_method: OCRMethod = OCRMethod.COMBINED):
        """
        Initialize the Enhanced PDF processor
        
        Args:
            llm_service (LLMService): LLM service for information extraction
            default_ocr_method (OCRMethod): Default OCR method to use
        """
        self.llm_service = llm_service
        self.ocr_service = AdvancedOCRService(default_method=default_ocr_method)
        self.default_ocr_method = default_ocr_method
        logger.info(f"Enhanced PDF Processor initialized with default OCR method: {default_ocr_method}")
    
    async def extract_text_from_pdf(self, pdf_bytes: bytes, ocr_method: Optional[OCRMethod] = None) -> str:
        """
        Extract text from PDF using advanced OCR techniques
        
        Args:
            pdf_bytes (bytes): PDF file content
            ocr_method (Optional[OCRMethod]): OCR method to use, defaults to self.default_ocr_method
            
        Returns:
            str: Extracted text
        """
        ocr_method = ocr_method or self.default_ocr_method
        start_time = time.time()
        
        try:
            # Extract text using the specified OCR method
            logger.info(f"Extracting text using OCR method: {ocr_method}")
            extracted_text = await self.ocr_service.extract_text(pdf_bytes, method=ocr_method)
            
            extraction_time = time.time() - start_time
            logger.info(f"Text extraction completed in {extraction_time:.2f} seconds")
            
            return extracted_text
        
        except Exception as e:
            logger.error(f"Error in text extraction process: {str(e)}")
            return "FAILED TO EXTRACT TEXT FROM PDF"
    
    async def extract_form_fields(self, pdf_bytes: bytes, ocr_method: Optional[OCRMethod] = None) -> Dict[str, Any]:
        """
        Extract form fields from PDF using advanced OCR techniques
        
        Args:
            pdf_bytes (bytes): PDF file content
            ocr_method (Optional[OCRMethod]): OCR method to use, defaults to self.default_ocr_method
            
        Returns:
            Dict[str, Any]: Extracted form field data
        """
        ocr_method = ocr_method or self.default_ocr_method
        start_time = time.time()
        
        try:
            # Extract form fields using the specified OCR method
            logger.info(f"Extracting form fields using OCR method: {ocr_method}")
            form_data = await self.ocr_service.extract_form_fields(pdf_bytes, method=ocr_method)
            
            extraction_time = time.time() - start_time
            logger.info(f"Form field extraction completed in {extraction_time:.2f} seconds")
            
            return form_data
        
        except Exception as e:
            logger.error(f"Error in form field extraction: {str(e)}")
            return {
                "applicant": {},
                "enrollment": {},
                "spouse": {},
                "children": []
            }
    
    async def process_pdf(self, pdf_bytes: bytes, ocr_method: Optional[OCRMethod] = None) -> ExtractedDataResponse:
        """
        Process PDF file: extract text and structured data using advanced OCR and LLM
        
        Args:
            pdf_bytes (bytes): PDF file content
            ocr_method (Optional[OCRMethod]): OCR method to use, defaults to self.default_ocr_method
            
        Returns:
            ExtractedDataResponse: Extracted information
        """
        ocr_method = ocr_method or self.default_ocr_method
        start_time = time.time()
        logger.info(f"Starting PDF processing with OCR method: {ocr_method}")
        
        try:
            # Step 1: Extract text using advanced OCR
            extracted_text = await self.extract_text_from_pdf(pdf_bytes, ocr_method)
            
            # Step 2: Extract form fields using OCR
            ocr_form_data = await self.extract_form_fields(pdf_bytes, ocr_method)
            logger.info(f"OCR-based form field extraction result: {json.dumps(ocr_form_data)}")
            
            # Step 3: Use LLM to extract structured information from the text
            llm_extraction_result = await self.llm_service.extract_information(extracted_text)
            logger.info(f"LLM-based extraction result: {json.dumps(llm_extraction_result)}")
            
            # Step 4: Merge results from OCR and LLM
            merged_result = self._merge_extraction_results(ocr_form_data, llm_extraction_result)
            logger.info(f"Merged extraction result: {json.dumps(merged_result)}")
            
            # Step 5: Convert to response model
            response = self._create_response_model(merged_result)
            
            processing_time = time.time() - start_time
            logger.info(f"PDF processing completed in {processing_time:.2f} seconds")
            
            return response
        
        except Exception as e:
            logger.error(f"Error in PDF processing: {str(e)}")
            # Return empty response on error
            return ExtractedDataResponse(
                applicant=ApplicantDetail(last_name="Unknown"),
                spouse=None,
                children=[],
                enrollment=None
            )
    
    def _merge_extraction_results(self, ocr_based: Dict[str, Any], llm_based: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge results from OCR-based extraction and LLM extraction
        
        Args:
            ocr_based (Dict[str, Any]): Results from OCR-based extraction
            llm_based (Dict[str, Any]): Results from LLM extraction
            
        Returns:
            Dict[str, Any]: Merged results
        """
        # Initialize merged result
        merged = {
            "applicant": {},
            "enrollment": {},
            "spouse": {},
            "children": []
        }
        
        # Helper function to merge dictionaries
        def merge_dicts(dict1, dict2):
            result = {}
            # Get all keys from both dictionaries
            all_keys = set(dict1.keys()) | set(dict2.keys())
            
            for key in all_keys:
                try:
                    # Get values from both dictionaries (None if key doesn't exist)
                    val1 = dict1.get(key)
                    val2 = dict2.get(key)
                    
                    # If both values exist
                    if val1 is not None and val2 is not None:
                        # For nested dictionaries, recursively merge
                        if isinstance(val1, dict) and isinstance(val2, dict):
                            result[key] = merge_dicts(val1, val2)
                        else:
                            # Prefer LLM for text fields, OCR for structured fields
                            # This is a simplified heuristic - in practice, you might want something more sophisticated
                            result[key] = val2 if val2 else val1  # Prefer LLM (val2) if it has a value
                    elif val1 is not None:
                        result[key] = val1
                    elif val2 is not None:
                        result[key] = val2
                    else:
                        result[key] = None
                except Exception as e:
                    logger.error(f"Error merging key {key}: {e}")
                    result[key] = None
            
            return result
        
        # Merge applicant information
        merged["applicant"] = merge_dicts(
            ocr_based.get("applicant", {}),
            llm_based.get("applicant", {})
        )
        
        # Merge enrollment information
        merged["enrollment"] = merge_dicts(
            ocr_based.get("enrollment", {}),
            llm_based.get("enrollment", {})
        )
        
        # Merge spouse information
        merged["spouse"] = merge_dicts(
            ocr_based.get("spouse", {}),
            llm_based.get("spouse", {})
        )
        
        # Merge children information
        ocr_children = ocr_based.get("children", [])
        llm_children = llm_based.get("children", [])
        
        # If we have children from both sources, try to match them
        if ocr_children and llm_children:
            # For each OCR-based child, find a matching LLM-based child
            for ocr_child in ocr_children:
                matched = False
                for llm_child in llm_children:
                    # Check if they might be the same child based on name or DOB
                    if (ocr_child.get("first_name") and llm_child.get("first_name") and 
                        ocr_child["first_name"].lower() == llm_child["first_name"].lower()) or \
                       (ocr_child.get("last_name") and llm_child.get("last_name") and 
                        ocr_child["last_name"].lower() == llm_child["last_name"].lower()) or \
                       (ocr_child.get("dob") and llm_child.get("dob") and 
                        ocr_child["dob"] == llm_child["dob"]):
                        # Merge the child information
                        merged_child = merge_dicts(ocr_child, llm_child)
                        merged["children"].append(merged_child)
                        matched = True
                        break
                
                # If no match found, add the OCR-based child
                if not matched:
                    merged["children"].append(ocr_child)
            
            # Add any LLM-based children that weren't matched
            for llm_child in llm_children:
                matched = False
                for ocr_child in ocr_children:
                    if (ocr_child.get("first_name") and llm_child.get("first_name") and 
                        ocr_child["first_name"].lower() == llm_child["first_name"].lower()) or \
                       (ocr_child.get("last_name") and llm_child.get("last_name") and 
                        ocr_child["last_name"].lower() == llm_child["last_name"].lower()) or \
                       (ocr_child.get("dob") and llm_child.get("dob") and 
                        ocr_child["dob"] == llm_child["dob"]):
                        matched = True
                        break
                
                if not matched:
                    merged["children"].append(llm_child)
        else:
            # If we only have children from one source, use those
            merged["children"] = ocr_children or llm_children
        
        return merged
    
    def _create_response_model(self, extracted_data: Dict[str, Any]) -> ExtractedDataResponse:
        """
        Convert extracted data dictionary to response model
        
        Args:
            extracted_data (Dict[str, Any]): Extracted data
            
        Returns:
            ExtractedDataResponse: Response model
        """
        # Extract applicant data
        applicant_data = extracted_data.get("applicant", {})
        applicant = ApplicantDetail(
            first_name=applicant_data.get("first_name"),
            last_name=applicant_data.get("last_name") or "Unknown",  # Default to "Unknown" if missing
            dob=applicant_data.get("dob"),
            gender=applicant_data.get("gender"),
            ssn=applicant_data.get("ssn"),
            address=applicant_data.get("address"),
            city=applicant_data.get("city"),
            state=applicant_data.get("state"),
            zip=applicant_data.get("zip"),
            phone=applicant_data.get("phone"),
            email=applicant_data.get("email")
        )
        
        # Extract enrollment data
        enrollment_data = extracted_data.get("enrollment", {})
        enrollment = None
        if any(enrollment_data.values()):  # If any enrollment field has a value
            enrollment = EnrollmentDetail(
                effective_date=enrollment_data.get("effective_date"),
                plan_type=enrollment_data.get("plan_type"),
                coverage_level=enrollment_data.get("coverage_level"),
                group_number=enrollment_data.get("group_number"),
                employer=enrollment_data.get("employer")
            )
        
        # Extract spouse data
        spouse_data = extracted_data.get("spouse", {})
        spouse = None
        if any(spouse_data.values()):  # If any spouse field has a value
            spouse = SpouseDetail(
                first_name=spouse_data.get("first_name"),
                last_name=spouse_data.get("last_name"),
                dob=spouse_data.get("dob"),
                gender=spouse_data.get("gender"),
                ssn=spouse_data.get("ssn")
            )
        
        # Extract children data
        children_data = extracted_data.get("children", [])
        children = []
        for child_data in children_data:
            if any(child_data.values()):  # If any child field has a value
                child = ChildDetail(
                    first_name=child_data.get("first_name"),
                    last_name=child_data.get("last_name"),
                    dob=child_data.get("dob"),
                    gender=child_data.get("gender")
                )
                children.append(child)
        
        # Create response
        return ExtractedDataResponse(
            applicant=applicant,
            spouse=spouse,
            children=children,
            enrollment=enrollment
        )
