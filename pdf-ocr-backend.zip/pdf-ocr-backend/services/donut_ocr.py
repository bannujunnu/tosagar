import io
import os
import time
from typing import Dict, Any, List, Optional, Tuple
import tempfile
from pathlib import Path
import torch
from PIL import Image
import numpy as np
from transformers import DonutProcessor, VisionEncoderDecoderModel
from utils.logging_utils import get_logger

# Configure logging
logger = get_logger(__name__)

class DonutOCR:
    """
    Document Understanding Transformer (Donut) OCR implementation.
    Donut is a multimodal transformer model that can extract structured information from documents.
    """
    
    def __init__(self, model_name: str = "naver-clova-ix/donut-base-finetuned-docvqa"):
        """
        Initialize the Donut OCR processor.
        
        Args:
            model_name (str): The name of the pre-trained Donut model to use
        """
        self.model_name = model_name
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info(f"Initializing Donut OCR with model {model_name} on {self.device}")
        
        try:
            self.processor = DonutProcessor.from_pretrained(model_name)
            self.model = VisionEncoderDecoderModel.from_pretrained(model_name)
            self.model.to(self.device)
            logger.info("Donut OCR model loaded successfully")
        except Exception as e:
            logger.error(f"Error loading Donut model: {str(e)}")
            raise
    
    async def process_document(self, pdf_bytes: bytes, task_prompt: str = "<s_docvqa>") -> str:
        """
        Process a PDF document using Donut.
        
        Args:
            pdf_bytes (bytes): PDF file content
            task_prompt (str): The prompt to guide the model for the specific task
                               Default is document VQA, but can be customized for forms
        
        Returns:
            str: Extracted text and structured information
        """
        start_time = time.time()
        logger.info("Starting Donut document processing")
        
        try:
            # Convert PDF to images
            images = self._convert_pdf_to_images(pdf_bytes)
            if not images:
                logger.error("Failed to convert PDF to images")
                return "FAILED TO EXTRACT IMAGES FROM PDF"
            
            # Process each image with Donut
            results = []
            for i, image in enumerate(images):
                logger.info(f"Processing page {i+1} with Donut")
                page_result = self._process_image(image, task_prompt)
                results.append(f"PAGE {i+1}:\n{page_result}\n")
            
            # Combine results
            combined_result = "\n".join(results)
            
            processing_time = time.time() - start_time
            logger.info(f"Donut processing completed in {processing_time:.2f} seconds")
            
            return combined_result
        
        except Exception as e:
            logger.error(f"Error in Donut document processing: {str(e)}")
            return f"ERROR IN DONUT PROCESSING: {str(e)}"
    
    def _convert_pdf_to_images(self, pdf_bytes: bytes) -> List[Image.Image]:
        """
        Convert PDF bytes to a list of PIL Images.
        
        Args:
            pdf_bytes (bytes): PDF file content
            
        Returns:
            List[Image.Image]: List of PIL Images, one per page
        """
        try:
            # Use pdf2image or PyMuPDF for conversion
            import fitz  # PyMuPDF
            
            images = []
            with fitz.open(stream=pdf_bytes, filetype="pdf") as doc:
                for page_num, page in enumerate(doc):
                    logger.info(f"Converting page {page_num+1} to image")
                    # Render page to an image with higher resolution
                    pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
                    img_data = pix.tobytes("png")
                    img = Image.open(io.BytesIO(img_data))
                    images.append(img)
            
            return images
        
        except ImportError:
            logger.warning("PyMuPDF not available, falling back to pdf2image")
            try:
                from pdf2image import convert_from_bytes
                
                images = convert_from_bytes(
                    pdf_bytes,
                    dpi=300,
                    fmt="png",
                )
                return images
            
            except Exception as e:
                logger.error(f"Error converting PDF to images: {str(e)}")
                return []
    
    def _process_image(self, image: Image.Image, task_prompt: str) -> str:
        """
        Process a single image with Donut.
        
        Args:
            image (Image.Image): PIL Image to process
            task_prompt (str): The prompt to guide the model
            
        Returns:
            str: Extracted text and information
        """
        try:
            # Prepare the image for the model
            pixel_values = self.processor(image, return_tensors="pt").pixel_values.to(self.device)
            
            # Generate the document understanding output
            decoder_input_ids = self.processor.tokenizer(
                task_prompt, 
                add_special_tokens=False, 
                return_tensors="pt"
            ).input_ids.to(self.device)
            
            # Generate output
            outputs = self.model.generate(
                pixel_values,
                decoder_input_ids=decoder_input_ids,
                max_length=self.model.decoder.config.max_position_embeddings,
                early_stopping=True,
                pad_token_id=self.processor.tokenizer.pad_token_id,
                eos_token_id=self.processor.tokenizer.eos_token_id,
                use_cache=True,
                num_beams=4,
                bad_words_ids=[[self.processor.tokenizer.unk_token_id]],
                return_dict_in_generate=True,
            )
            
            # Decode the output
            sequence = self.processor.batch_decode(outputs.sequences)[0]
            sequence = sequence.replace(self.processor.tokenizer.eos_token, "").replace(self.processor.tokenizer.pad_token, "")
            sequence = sequence.replace(task_prompt, "")
            
            # Clean up the output
            cleaned_sequence = sequence.strip()
            
            return cleaned_sequence
        
        except Exception as e:
            logger.error(f"Error processing image with Donut: {str(e)}")
            return f"ERROR PROCESSING IMAGE: {str(e)}"
    
    async def extract_form_fields(self, pdf_bytes: bytes) -> Dict[str, Any]:
        """
        Extract form fields from a PDF using Donut.
        
        Args:
            pdf_bytes (bytes): PDF file content
            
        Returns:
            Dict[str, Any]: Structured data extracted from the form
        """
        # Custom task prompt for form field extraction
        task_prompt = "<s_form>"
        
        # Process the document
        extracted_text = await self.process_document(pdf_bytes, task_prompt)
        
        # Parse the extracted text into structured data
        # This is a simplified implementation - in practice, you'd need more sophisticated parsing
        structured_data = self._parse_form_fields(extracted_text)
        
        return structured_data
    
    def _parse_form_fields(self, extracted_text: str) -> Dict[str, Any]:
        """
        Parse extracted text into structured form data.
        
        Args:
            extracted_text (str): Text extracted by Donut
            
        Returns:
            Dict[str, Any]: Structured form data
        """
        # Initialize the structure based on your form schema
        structured_data = {
            "applicant": {
                "first_name": None,
                "last_name": None,
                "dob": None,
                "gender": None,
                "ssn": None,
                "address": None,
                "city": None,
                "state": None,
                "zip": None,
                "phone": None,
                "email": None
            },
            "enrollment": {
                "effective_date": None,
                "plan_type": None,
                "coverage_level": None,
                "group_number": None,
                "employer": None
            },
            "spouse": {
                "first_name": None,
                "last_name": None,
                "dob": None,
                "gender": None,
                "ssn": None
            },
            "children": []
        }
        
        # In a real implementation, you would parse the extracted_text
        # and populate the structured_data dictionary
        # This could involve regex, NER, or other text processing techniques
        
        # For demonstration, we'll use a simple line-by-line approach
        lines = extracted_text.split('\n')
        current_section = None
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            # Detect sections
            if "APPLICANT" in line.upper() or "EMPLOYEE" in line.upper():
                current_section = "applicant"
                continue
            elif "SPOUSE" in line.upper():
                current_section = "spouse"
                continue
            elif "CHILD" in line.upper() or "DEPENDENT" in line.upper():
                current_section = "children"
                continue
            elif "ENROLLMENT" in line.upper() or "COVERAGE" in line.upper():
                current_section = "enrollment"
                continue
                
            # Process fields based on current section
            if current_section == "applicant":
                if "NAME:" in line.upper() or "NAME " in line.upper():
                    name_parts = line.split(":")[-1].strip().split()
                    if len(name_parts) >= 2:
                        structured_data["applicant"]["first_name"] = name_parts[0]
                        structured_data["applicant"]["last_name"] = name_parts[-1]
                elif "DOB:" in line.upper() or "BIRTH" in line.upper():
                    structured_data["applicant"]["dob"] = line.split(":")[-1].strip()
                # Add more field extractions as needed
            
            # Similar processing for other sections
        
        return structured_data
